import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Enhanced mock data with Biology and unique questions
export const mockData = {
  users: [
    {
      id: "1",
      name: "John Doe",
      email: "john@example.com",
      plan: "free",
      xp: 1250,
      avatar: "/placeholder.svg?height=40&width=40&text=JD",
      role: "student",
      joinDate: "2024-01-15",
      lastActive: "2024-01-20",
      class: "12th",
      examTarget: "JEE Main",
      enrolledCourses: ["1", "3"],
    },
    {
      id: "2",
      name: "Jane Smith",
      email: "jane@example.com",
      plan: "premium",
      xp: 2100,
      avatar: "/placeholder.svg?height=40&width=40&text=JS",
      role: "student",
      joinDate: "2024-01-10",
      lastActive: "2024-01-20",
      class: "11th",
      examTarget: "NEET",
      enrolledCourses: ["2", "4", "5"],
    },
    {
      id: "admin",
      name: "Admin User",
      email: "admin@example.com",
      plan: "pro",
      xp: 5000,
      avatar: "/placeholder.svg?height=40&width=40&text=AD",
      role: "admin",
      joinDate: "2024-01-01",
      lastActive: "2024-01-20",
      class: "Graduate",
      examTarget: "Teaching",
      enrolledCourses: [],
    },
  ],
  courses: [
    {
      id: "1",
      title: "Advanced Physics - Mechanics",
      instructor: "Dr. Sarah Johnson",
      category: "Physics",
      level: "Advanced",
      price: "₹2,999",
      rating: 4.8,
      students: 1250,
      duration: "12 weeks",
      lessons: 45,
      progress: 65,
      thumbnail: "/physics-mechanics.png",
      description: "Master the fundamentals of classical mechanics with advanced problem-solving techniques.",
      isPurchased: false,
    },
    {
      id: "2",
      title: "Organic Chemistry Mastery",
      instructor: "Prof. Michael Chen",
      category: "Chemistry",
      level: "Intermediate",
      price: "₹2,499",
      rating: 4.7,
      students: 980,
      duration: "10 weeks",
      lessons: 38,
      progress: 40,
      thumbnail: "/organic-chemistry.png",
      description: "Comprehensive coverage of organic chemistry reactions and mechanisms.",
      isPurchased: false,
    },
    {
      id: "3",
      title: "Calculus & Differential Equations",
      instructor: "Dr. Emily Rodriguez",
      category: "Mathematics",
      level: "Advanced",
      price: "₹3,299",
      rating: 4.9,
      students: 1450,
      duration: "14 weeks",
      lessons: 52,
      progress: 25,
      thumbnail: "/calculus-math.png",
      description: "Advanced mathematical concepts for competitive exam preparation.",
      isPurchased: false,
    },
    {
      id: "4",
      title: "Cell Biology & Genetics",
      instructor: "Dr. Priya Sharma",
      category: "Biology",
      level: "Intermediate",
      price: "₹2,199",
      rating: 4.6,
      students: 850,
      duration: "8 weeks",
      lessons: 32,
      progress: 0,
      thumbnail: "/cell-biology.png",
      description: "Explore cellular processes and genetic principles in detail.",
      isPurchased: false,
    },
    {
      id: "5",
      title: "Human Physiology",
      instructor: "Dr. Rajesh Kumar",
      category: "Biology",
      level: "Advanced",
      price: "₹2,799",
      rating: 4.7,
      students: 720,
      duration: "12 weeks",
      lessons: 40,
      progress: 0,
      thumbnail: "/human-physiology.png",
      description: "Comprehensive study of human body systems and functions.",
      isPurchased: false,
    },
    {
      id: "6",
      title: "Thermodynamics & Statistical Mechanics",
      instructor: "Prof. David Wilson",
      category: "Physics",
      level: "Advanced",
      price: "₹3,499",
      rating: 4.8,
      students: 650,
      duration: "16 weeks",
      lessons: 48,
      progress: 0,
      thumbnail: "/thermodynamics.png",
      description: "Advanced concepts in thermal physics and statistical mechanics.",
      isPurchased: false,
    },
  ],
  tests: [
    {
      id: "1",
      title: "Physics Mock Test - Mechanics",
      subject: "Physics",
      type: "Mock Test",
      difficulty: "Medium",
      questions: 30,
      duration: 90,
      attempts: 3,
      bestScore: 85,
    },
    {
      id: "2",
      title: "Chemistry Practice Quiz",
      subject: "Chemistry",
      type: "Practice",
      difficulty: "Easy",
      questions: 20,
      duration: 45,
      attempts: 5,
      bestScore: 92,
    },
    {
      id: "3",
      title: "Mathematics Advanced Test",
      subject: "Mathematics",
      type: "Mock Test",
      difficulty: "Hard",
      questions: 40,
      duration: 120,
      attempts: 2,
      bestScore: 78,
    },
    {
      id: "4",
      title: "Biology Comprehensive Test",
      subject: "Biology",
      type: "Mock Test",
      difficulty: "Medium",
      questions: 35,
      duration: 100,
      attempts: 1,
      bestScore: null,
    },
  ],
  liveClasses: [
    {
      id: "1",
      title: "Advanced Calculus Problem Solving",
      instructor: "Dr. Sarah Johnson",
      subject: "Mathematics",
      date: "Today",
      time: "10:00 AM - 11:30 AM",
      status: "live",
      students: 245,
      meetingId: "MTH-2024-001",
    },
    {
      id: "2",
      title: "Organic Chemistry Reactions",
      instructor: "Prof. Michael Chen",
      subject: "Chemistry",
      date: "Today",
      time: "2:00 PM - 3:30 PM",
      status: "upcoming",
      students: 189,
      meetingId: "CHE-2024-002",
    },
    {
      id: "3",
      title: "Wave Motion and Optics",
      instructor: "Dr. Emily Rodriguez",
      subject: "Physics",
      date: "Tomorrow",
      time: "9:00 AM - 10:30 AM",
      status: "scheduled",
      students: 156,
      meetingId: "PHY-2024-003",
    },
    {
      id: "4",
      title: "Cell Division and Genetics",
      instructor: "Dr. Priya Sharma",
      subject: "Biology",
      date: "Tomorrow",
      time: "3:00 PM - 4:30 PM",
      status: "scheduled",
      students: 134,
      meetingId: "BIO-2024-004",
    },
  ],
  analytics: {
    totalUsers: 25420,
    activeUsers: 18750,
    totalCourses: 156,
    totalRevenue: 2450000,
    monthlyGrowth: 12.5,
    userRetention: 85.2,
    avgSessionTime: 45,
    completionRate: 78.5,
  },
}

// Enhanced question generation with better variety
export const generateQuestionsWithGemini = async (subject: string, difficulty: string, count: number) => {
  try {
    // For now, we'll use local generation with enhanced variety
    // In production, replace this with actual Gemini API call
    return generateEnhancedQuestions(subject, difficulty, count)
  } catch (error) {
    console.error("Error generating questions:", error)
    // Fallback to basic questions if everything fails
    return generateFallbackQuestions(subject, difficulty, count)
  }
}

// Enhanced question generation with more variety
const generateEnhancedQuestions = (subject: string, difficulty: string, count: number) => {
  const questionBanks = {
    Physics: {
      Easy: [
        {
          question: "What is the speed of light in vacuum?",
          options: ["3 × 10⁸ m/s", "3 × 10⁶ m/s", "3 × 10¹⁰ m/s", "3 × 10⁴ m/s"],
          correctAnswer: 0,
          explanation: "The speed of light in vacuum is approximately 3 × 10⁸ m/s, a fundamental constant.",
          topic: "Optics",
        },
        {
          question: "Which of the following is a vector quantity?",
          options: ["Speed", "Distance", "Velocity", "Time"],
          correctAnswer: 2,
          explanation: "Velocity has both magnitude and direction, making it a vector quantity.",
          topic: "Mechanics",
        },
        {
          question: "What is the SI unit of force?",
          options: ["Joule", "Newton", "Watt", "Pascal"],
          correctAnswer: 1,
          explanation: "The SI unit of force is Newton (N), named after Sir Isaac Newton.",
          topic: "Mechanics",
        },
        {
          question: "What happens to kinetic energy when velocity doubles?",
          options: ["Doubles", "Triples", "Quadruples", "Remains same"],
          correctAnswer: 2,
          explanation: "KE = ½mv². When velocity doubles, kinetic energy becomes four times.",
          topic: "Energy",
        },
        {
          question: "Which law states that energy cannot be created or destroyed?",
          options: ["Newton's First Law", "Law of Conservation of Energy", "Ohm's Law", "Hooke's Law"],
          correctAnswer: 1,
          explanation: "The Law of Conservation of Energy states that energy can only be transformed.",
          topic: "Energy",
        },
      ],
      Medium: [
        {
          question: "A ball is thrown vertically upward. At the highest point, what is its acceleration?",
          options: ["Zero", "9.8 m/s² downward", "9.8 m/s² upward", "Variable"],
          correctAnswer: 1,
          explanation: "At the highest point, acceleration due to gravity is still 9.8 m/s² downward.",
          topic: "Kinematics",
        },
        {
          question: "What is the work done by centripetal force?",
          options: ["Maximum", "Minimum", "Zero", "Variable"],
          correctAnswer: 2,
          explanation: "Centripetal force is perpendicular to motion, so work done is zero.",
          topic: "Circular Motion",
        },
        {
          question: "In simple harmonic motion, what is the phase difference between displacement and velocity?",
          options: ["0°", "90°", "180°", "270°"],
          correctAnswer: 1,
          explanation: "Velocity leads displacement by 90° in simple harmonic motion.",
          topic: "Oscillations",
        },
      ],
      Hard: [
        {
          question: "What is the escape velocity from Earth's surface?",
          options: ["7.9 km/s", "11.2 km/s", "15.0 km/s", "25.0 km/s"],
          correctAnswer: 1,
          explanation: "Escape velocity from Earth is 11.2 km/s, calculated using √(2GM/R).",
          topic: "Gravitation",
        },
        {
          question: "In photoelectric effect, stopping potential depends on:",
          options: ["Intensity of light", "Frequency of light", "Both", "Neither"],
          correctAnswer: 1,
          explanation: "Stopping potential depends only on frequency, not intensity of incident light.",
          topic: "Modern Physics",
        },
      ],
    },
    Chemistry: {
      Easy: [
        {
          question: "What is the atomic number of Carbon?",
          options: ["4", "6", "8", "12"],
          correctAnswer: 1,
          explanation: "Carbon has 6 protons, making its atomic number 6.",
          topic: "Atomic Structure",
        },
        {
          question: "Which gas is produced when acids react with metals?",
          options: ["Oxygen", "Carbon dioxide", "Hydrogen", "Nitrogen"],
          correctAnswer: 2,
          explanation: "Acids react with metals to produce hydrogen gas and a salt.",
          topic: "Acids and Bases",
        },
        {
          question: "What is the molecular formula of water?",
          options: ["H₂O", "H₂O₂", "HO", "H₃O"],
          correctAnswer: 0,
          explanation: "Water has the molecular formula H₂O - two hydrogen atoms and one oxygen atom.",
          topic: "Chemical Formulas",
        },
        {
          question: "Which element has the chemical symbol 'Na'?",
          options: ["Nitrogen", "Sodium", "Nickel", "Neon"],
          correctAnswer: 1,
          explanation: "Na is the chemical symbol for Sodium, from the Latin word 'natrium'.",
          topic: "Periodic Table",
        },
      ],
      Medium: [
        {
          question: "What is the hybridization of carbon in methane (CH₄)?",
          options: ["sp", "sp²", "sp³", "sp³d"],
          correctAnswer: 2,
          explanation: "Carbon in methane undergoes sp³ hybridization to form four equivalent bonds.",
          topic: "Chemical Bonding",
        },
        {
          question: "Which of the following has the highest electronegativity?",
          options: ["Oxygen", "Nitrogen", "Fluorine", "Chlorine"],
          correctAnswer: 2,
          explanation: "Fluorine has the highest electronegativity value of 4.0 on the Pauling scale.",
          topic: "Periodic Properties",
        },
      ],
      Hard: [
        {
          question: "What is the rate law for a reaction A + B → C if it's second order in A and first order in B?",
          options: ["Rate = k[A][B]", "Rate = k[A]²[B]", "Rate = k[A][B]²", "Rate = k[A]²[B]²"],
          correctAnswer: 1,
          explanation: "For second order in A and first order in B, rate = k[A]²[B].",
          topic: "Chemical Kinetics",
        },
      ],
    },
    Mathematics: {
      Easy: [
        {
          question: "What is the derivative of x²?",
          options: ["x", "2x", "x²", "2x²"],
          correctAnswer: 1,
          explanation: "Using the power rule, d/dx(x²) = 2x.",
          topic: "Calculus",
        },
        {
          question: "What is the value of sin(90°)?",
          options: ["0", "1", "√2/2", "√3/2"],
          correctAnswer: 1,
          explanation: "sin(90°) = 1, which is a fundamental trigonometric value.",
          topic: "Trigonometry",
        },
        {
          question: "What is the sum of interior angles of a triangle?",
          options: ["90°", "180°", "270°", "360°"],
          correctAnswer: 1,
          explanation: "The sum of interior angles of any triangle is always 180°.",
          topic: "Geometry",
        },
        {
          question: "What is 2³?",
          options: ["6", "8", "9", "12"],
          correctAnswer: 1,
          explanation: "2³ = 2 × 2 × 2 = 8.",
          topic: "Algebra",
        },
      ],
      Medium: [
        {
          question: "What is the integral of 2x?",
          options: ["x²", "x² + C", "2x²", "x² + 2C"],
          correctAnswer: 1,
          explanation: "∫2x dx = x² + C, where C is the constant of integration.",
          topic: "Calculus",
        },
        {
          question: "If log₂(x) = 3, what is x?",
          options: ["6", "8", "9", "12"],
          correctAnswer: 1,
          explanation: "If log₂(x) = 3, then x = 2³ = 8.",
          topic: "Logarithms",
        },
      ],
      Hard: [
        {
          question: "What is the limit of (sin x)/x as x approaches 0?",
          options: ["0", "1", "∞", "undefined"],
          correctAnswer: 1,
          explanation: "This is a standard limit: lim(x→0) (sin x)/x = 1.",
          topic: "Limits",
        },
      ],
    },
    Biology: {
      Easy: [
        {
          question: "What is the powerhouse of the cell?",
          options: ["Nucleus", "Mitochondria", "Ribosome", "Golgi apparatus"],
          correctAnswer: 1,
          explanation: "Mitochondria produce ATP energy, earning them the title 'powerhouse of the cell'.",
          topic: "Cell Biology",
        },
        {
          question: "Which process converts light energy into chemical energy?",
          options: ["Respiration", "Photosynthesis", "Digestion", "Excretion"],
          correctAnswer: 1,
          explanation: "Photosynthesis converts light energy into chemical energy (glucose).",
          topic: "Plant Biology",
        },
        {
          question: "What is the basic unit of heredity?",
          options: ["Chromosome", "Gene", "DNA", "RNA"],
          correctAnswer: 1,
          explanation: "A gene is the basic unit of heredity that carries genetic information.",
          topic: "Genetics",
        },
        {
          question: "How many chambers does a human heart have?",
          options: ["2", "3", "4", "5"],
          correctAnswer: 2,
          explanation: "The human heart has four chambers: two atria and two ventricles.",
          topic: "Human Biology",
        },
      ],
      Medium: [
        {
          question: "What is the process of cell division that produces gametes?",
          options: ["Mitosis", "Meiosis", "Binary fission", "Budding"],
          correctAnswer: 1,
          explanation: "Meiosis produces gametes with half the chromosome number.",
          topic: "Cell Division",
        },
        {
          question: "Which blood group is known as the universal donor?",
          options: ["A", "B", "AB", "O"],
          correctAnswer: 3,
          explanation: "Blood group O has no A or B antigens, making it the universal donor.",
          topic: "Blood Groups",
        },
      ],
      Hard: [
        {
          question: "What is the role of telomerase enzyme?",
          options: ["DNA replication", "Protein synthesis", "Chromosome protection", "Cell division"],
          correctAnswer: 2,
          explanation: "Telomerase adds telomeric sequences to chromosome ends, protecting them.",
          topic: "Molecular Biology",
        },
      ],
    },
  }

  const subjectBank = questionBanks[subject] || questionBanks.Physics
  const difficultyBank = subjectBank[difficulty] || subjectBank.Easy || []

  // Create a pool of questions and shuffle them
  const questionPool = [...difficultyBank]

  // If we need more questions than available, duplicate and modify them
  while (questionPool.length < count) {
    const originalQuestions = subjectBank[difficulty] || subjectBank.Easy || []
    questionPool.push(...originalQuestions)
  }

  // Shuffle the questions
  for (let i = questionPool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[questionPool[i], questionPool[j]] = [questionPool[j], questionPool[i]]
  }

  // Select the required number of questions
  const selectedQuestions = questionPool.slice(0, count).map((q, index) => ({
    ...q,
    id: `${subject.toLowerCase()}_${difficulty.toLowerCase()}_${Date.now()}_${index}`,
    difficulty,
    subject,
  }))

  return { questions: selectedQuestions }
}

// Fallback question generation
const generateFallbackQuestions = (subject: string, difficulty: string, count: number) => {
  const basicQuestions = [
    {
      question: `What is a fundamental concept in ${subject}?`,
      options: ["Option A", "Option B", "Option C", "Option D"],
      correctAnswer: 0,
      explanation: `This is a basic ${subject} question at ${difficulty} level.`,
      topic: "General",
    },
  ]

  const questions = []
  for (let i = 0; i < count; i++) {
    questions.push({
      ...basicQuestions[0],
      id: `fallback_${subject.toLowerCase()}_${i}`,
      question: `${subject} Question ${i + 1}: What is concept ${i + 1}?`,
      difficulty,
      subject,
    })
  }

  return { questions }
}

export const saveToStorage = (key: string, data: any) => {
  if (typeof window !== "undefined") {
    localStorage.setItem(key, JSON.stringify(data))
  }
}

export const getFromStorage = (key: string) => {
  if (typeof window !== "undefined") {
    const data = localStorage.getItem(key)
    return data ? JSON.parse(data) : null
  }
  return null
}
