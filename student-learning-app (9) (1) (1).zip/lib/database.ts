import mysql from "mysql2/promise"

// Database configuration from the provided credentials
const dbConfig = {
  host: "sql206.free2host.eu.org",
  user: "user_3951787S",
  password: "48b8475ed3346O7",
  database: "user_3951787S_Edspire",
  port: 252,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  acquireTimeout: 60000,
  timeout: 60000,
  reconnect: true,
}

// Create connection pool for better performance
let pool: mysql.Pool | null = null

export const getConnection = async () => {
  if (!pool) {
    pool = mysql.createPool(dbConfig)
  }
  return pool
}

// Database initialization and table creation
export const initializeDatabase = async () => {
  try {
    const connection = await getConnection()

    // Create users table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id VARCHAR(50) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        plan ENUM('free', 'premium', 'pro') DEFAULT 'free',
        xp INT DEFAULT 0,
        avatar VARCHAR(500),
        role ENUM('student', 'admin', 'teacher') DEFAULT 'student',
        class VARCHAR(50),
        exam_target VARCHAR(100),
        join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `)

    // Create courses table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS courses (
        id VARCHAR(50) PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        instructor VARCHAR(255) NOT NULL,
        category VARCHAR(100) NOT NULL,
        level ENUM('Beginner', 'Intermediate', 'Advanced') NOT NULL,
        price VARCHAR(50) NOT NULL,
        rating DECIMAL(2,1) DEFAULT 0,
        students INT DEFAULT 0,
        duration VARCHAR(50),
        lessons INT DEFAULT 0,
        thumbnail VARCHAR(500),
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      )
    `)

    // Create subjective_tests table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS subjective_tests (
        id VARCHAR(50) PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        subject VARCHAR(100) NOT NULL,
        class VARCHAR(50) NOT NULL,
        description TEXT,
        instructions TEXT,
        duration INT NOT NULL,
        total_marks INT NOT NULL,
        created_by VARCHAR(50),
        status ENUM('draft', 'published', 'archived') DEFAULT 'draft',
        start_time DATETIME,
        end_time DATETIME,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
      )
    `)

    // Create subjective_questions table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS subjective_questions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        test_id VARCHAR(50),
        question_number INT NOT NULL,
        question_text TEXT NOT NULL,
        marks INT NOT NULL,
        expected_keywords TEXT,
        sample_answer TEXT,
        evaluation_criteria TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (test_id) REFERENCES subjective_tests(id) ON DELETE CASCADE
      )
    `)

    // Create subjective_submissions table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS subjective_submissions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        test_id VARCHAR(50),
        student_id VARCHAR(50),
        submission_file VARCHAR(500),
        submission_text TEXT,
        submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status ENUM('submitted', 'under_review', 'evaluated', 'returned') DEFAULT 'submitted',
        total_score INT DEFAULT 0,
        max_score INT DEFAULT 0,
        feedback TEXT,
        evaluated_by VARCHAR(50),
        evaluated_at TIMESTAMP NULL,
        FOREIGN KEY (test_id) REFERENCES subjective_tests(id) ON DELETE CASCADE,
        FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (evaluated_by) REFERENCES users(id) ON DELETE SET NULL,
        UNIQUE KEY unique_submission (test_id, student_id)
      )
    `)

    // Create subjective_answers table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS subjective_answers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        submission_id INT,
        question_id INT,
        answer_text TEXT,
        score INT DEFAULT 0,
        max_score INT DEFAULT 0,
        feedback TEXT,
        auto_feedback TEXT,
        keywords_found TEXT,
        error_analysis TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (submission_id) REFERENCES subjective_submissions(id) ON DELETE CASCADE,
        FOREIGN KEY (question_id) REFERENCES subjective_questions(id) ON DELETE CASCADE
      )
    `)

    // Create test_analytics table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS test_analytics (
        id INT AUTO_INCREMENT PRIMARY KEY,
        test_id VARCHAR(50),
        total_submissions INT DEFAULT 0,
        average_score DECIMAL(5,2) DEFAULT 0,
        highest_score INT DEFAULT 0,
        lowest_score INT DEFAULT 0,
        completion_rate DECIMAL(5,2) DEFAULT 0,
        common_errors TEXT,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (test_id) REFERENCES subjective_tests(id) ON DELETE CASCADE
      )
    `)

    // Create existing tables (keeping the rest of your schema)
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS user_courses (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id VARCHAR(50),
        course_id VARCHAR(50),
        progress INT DEFAULT 0,
        enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
        UNIQUE KEY unique_enrollment (user_id, course_id)
      )
    `)

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS tests (
        id VARCHAR(50) PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        subject VARCHAR(100) NOT NULL,
        type ENUM('Mock Test', 'Practice', 'Custom') NOT NULL,
        difficulty ENUM('Easy', 'Medium', 'Hard') NOT NULL,
        questions INT NOT NULL,
        duration INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `)

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS test_attempts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id VARCHAR(50),
        test_id VARCHAR(50),
        score INT,
        total_questions INT,
        time_taken INT,
        attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (test_id) REFERENCES tests(id) ON DELETE CASCADE
      )
    `)

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS live_classes (
        id VARCHAR(50) PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        instructor VARCHAR(255) NOT NULL,
        subject VARCHAR(100) NOT NULL,
        class_date DATE NOT NULL,
        start_time TIME NOT NULL,
        end_time TIME NOT NULL,
        status ENUM('scheduled', 'live', 'completed', 'cancelled') DEFAULT 'scheduled',
        meeting_id VARCHAR(100),
        max_students INT DEFAULT 100,
        enrolled_students INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `)

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS notifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id VARCHAR(50),
        title VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        type ENUM('info', 'success', 'warning', 'error') DEFAULT 'info',
        is_read BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `)

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS payments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id VARCHAR(50),
        plan ENUM('premium', 'pro') NOT NULL,
        amount DECIMAL(10,2) NOT NULL,
        status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
        payment_screenshot VARCHAR(500),
        upi_transaction_id VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        approved_at TIMESTAMP NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `)

    console.log("Database initialized successfully")
    return true
  } catch (error) {
    console.error("Database initialization error:", error)
    return false
  }
}

// Seed initial data
export const seedDatabase = async () => {
  try {
    const connection = await getConnection()

    // Check if admin user exists
    const [adminExists] = await connection.execute("SELECT id FROM users WHERE email = ?", ["admin@example.com"])

    if ((adminExists as any[]).length === 0) {
      // Create admin user
      await connection.execute(
        `
        INSERT INTO users (id, name, email, password, plan, xp, avatar, role, class, exam_target)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
        [
          "admin",
          "Admin User",
          "admin@example.com",
          "admin123",
          "pro",
          5000,
          "/placeholder.svg?height=40&width=40&text=AD",
          "admin",
          "Graduate",
          "Teaching",
        ],
      )

      // Create sample teacher user
      await connection.execute(
        `
        INSERT INTO users (id, name, email, password, plan, xp, avatar, role, class, exam_target)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
        [
          "teacher1",
          "Dr. Sarah Johnson",
          "teacher@example.com",
          "teacher123",
          "pro",
          3000,
          "/placeholder.svg?height=40&width=40&text=SJ",
          "teacher",
          "Graduate",
          "Teaching",
        ],
      )

      // Create sample student user
      await connection.execute(
        `
        INSERT INTO users (id, name, email, password, plan, xp, avatar, role, class, exam_target)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
        [
          "1",
          "John Doe",
          "john@example.com",
          "password123",
          "free",
          1250,
          "/placeholder.svg?height=40&width=40&text=JD",
          "student",
          "12th",
          "JEE Main",
        ],
      )
    }

    console.log("Database seeded successfully")
    return true
  } catch (error) {
    console.error("Database seeding error:", error)
    return false
  }
}
