export const UPI_CONFIG = {
  merchantId: "rizwan.894@ptyes",
  merchantName: "Rizwan Ahmad",
  merchantCode: "EDU001",
}

export const PLAN_PRICING = {
  premium: {
    amount: 90,
    duration: "1 month",
    features: ["15 AI Questions/day", "Live Classes", "All Courses", "Priority Support"],
  },
  pro: {
    amount: 480,
    duration: "6 months",
    features: ["Unlimited AI Questions", "1-on-1 Sessions", "Advanced Analytics", "Certificate"],
  },
}

export interface PaymentDetails {
  id?: string
  userId: string
  userName: string
  userEmail: string
  amount: number
  plan: "premium" | "pro"
  upiId: string
  transactionId: string
  timestamp: Date
  status: "pending" | "approved" | "rejected"
  approvedBy?: string
  approvedAt?: Date
  screenshot?: string
}

export interface PurchaseStats {
  totalPurchases: number
  totalRevenue: number
  pendingApprovals: number
  monthlyRevenue: number
  planBreakdown: {
    premium: number
    pro: number
  }
}

export const generateTransactionId = (): string => {
  return `TXN${Date.now()}${Math.random().toString(36).substr(2, 9).toUpperCase()}`
}

export const generateUPIUrl = (amount: number, plan: string, transactionId: string): string => {
  const params = new URLSearchParams({
    pa: UPI_CONFIG.merchantId,
    pn: UPI_CONFIG.merchantName,
    mc: UPI_CONFIG.merchantCode,
    tr: transactionId,
    tn: `EduPlatform ${plan} Plan`,
    am: amount.toString(),
    cu: "INR",
  })
  return `upi://pay?${params.toString()}`
}

export const generateQRCodeUrl = (amount: number, plan: string, transactionId: string): string => {
  const upiUrl = generateUPIUrl(amount, plan, transactionId)
  return `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(upiUrl)}`
}

export const storePayment = (payment: PaymentDetails): void => {
  const payments = getStoredPayments()
  const newPayment = {
    ...payment,
    id: generateTransactionId(),
    status: "pending" as const,
  }
  payments.push(newPayment)
  localStorage.setItem("payments", JSON.stringify(payments))

  // Store notification for user
  const notifications = JSON.parse(localStorage.getItem("notifications") || "[]")
  notifications.push({
    id: Date.now().toString(),
    userId: payment.userId,
    type: "payment",
    title: "Payment Submitted",
    message: "Your payment has been submitted and is under review. You will get access within 24 hours.",
    timestamp: new Date(),
    read: false,
  })
  localStorage.setItem("notifications", JSON.stringify(notifications))
}

export const getStoredPayments = (): PaymentDetails[] => {
  if (typeof window === "undefined") return []
  return JSON.parse(localStorage.getItem("payments") || "[]")
}

export const updatePaymentStatus = (paymentId: string, status: "approved" | "rejected", adminId: string): void => {
  const payments = getStoredPayments()
  const paymentIndex = payments.findIndex((p) => p.id === paymentId)

  if (paymentIndex !== -1) {
    payments[paymentIndex].status = status
    payments[paymentIndex].approvedBy = adminId
    payments[paymentIndex].approvedAt = new Date()
    localStorage.setItem("payments", JSON.stringify(payments))

    // Update user's plan if approved
    if (status === "approved") {
      const users = JSON.parse(localStorage.getItem("users") || "[]")
      const userIndex = users.findIndex((u: any) => u.id === payments[paymentIndex].userId)
      if (userIndex !== -1) {
        users[userIndex].plan = payments[paymentIndex].plan
        localStorage.setItem("users", JSON.stringify(users))
      }

      // Send approval notification
      const notifications = JSON.parse(localStorage.getItem("notifications") || "[]")
      notifications.push({
        id: Date.now().toString(),
        userId: payments[paymentIndex].userId,
        type: "approval",
        title: "Payment Approved!",
        message: `Your ${payments[paymentIndex].plan} plan has been activated. Enjoy premium features!`,
        timestamp: new Date(),
        read: false,
      })
      localStorage.setItem("notifications", JSON.stringify(notifications))
    }
  }
}

export const getPurchaseStats = (): PurchaseStats => {
  const payments = getStoredPayments()
  const approved = payments.filter((p) => p.status === "approved")
  const pending = payments.filter((p) => p.status === "pending")

  const currentMonth = new Date().getMonth()
  const monthlyPayments = approved.filter((p) => new Date(p.timestamp).getMonth() === currentMonth)

  return {
    totalPurchases: approved.length,
    totalRevenue: approved.reduce((sum, p) => sum + p.amount, 0),
    pendingApprovals: pending.length,
    monthlyRevenue: monthlyPayments.reduce((sum, p) => sum + p.amount, 0),
    planBreakdown: {
      premium: approved.filter((p) => p.plan === "premium").length,
      pro: approved.filter((p) => p.plan === "pro").length,
    },
  }
}

export const verifyPayment = async (transactionId: string): Promise<{ success: boolean }> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 2000))
  return { success: true }
}
