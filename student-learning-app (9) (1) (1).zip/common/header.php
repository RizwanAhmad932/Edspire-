<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, maximum-scale=1.0, minimum-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle : 'Student Learning App'; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            -webkit-touch-callout: none;
        }
        input, textarea { -webkit-user-select: text; -moz-user-select: text; user-select: text; }
        .loader { border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; width: 40px; height: 40px; animation: spin 2s linear infinite; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body class="bg-gray-50">
     Header 
    <header class="bg-blue-600 text-white p-4 flex justify-between items-center">
        <div class="flex items-center">
            <button id="sidebarToggle" class="mr-3 md:hidden">
                <i class="fas fa-bars"></i>
            </button>
            <h1 class="text-xl font-bold">StudyApp</h1>
        </div>
        <div class="flex items-center space-x-4">
            <?php if (isLoggedIn()): ?>
                <span class="hidden md:inline">Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                <div class="relative">
                    <button id="userMenu" class="flex items-center">
                        <i class="fas fa-user-circle text-2xl"></i>
                    </button>
                    <div id="userDropdown" class="hidden absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50">
                        <a href="index.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Dashboard</a>
                        <a href="subscription.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Subscription</a>
                        <a href="logout.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Logout</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </header>

    <script>
        // Security: Disable right-click, text selection, zoom
        document.addEventListener('contextmenu', e => e.preventDefault());
        document.addEventListener('selectstart', e => e.preventDefault());
        document.addEventListener('dragstart', e => e.preventDefault());
        document.addEventListener('keydown', function(e) {
            if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && e.key === 'I') || 
                (e.ctrlKey && e.shiftKey && e.key === 'J') || (e.ctrlKey && e.key === 'u') ||
                (e.ctrlKey && (e.key === '+' || e.key === '-' || e.key === '0'))) {
                e.preventDefault();
            }
        });
        document.addEventListener('wheel', function(e) {
            if (e.ctrlKey) e.preventDefault();
        }, { passive: false });

        // User menu toggle
        document.getElementById('userMenu')?.addEventListener('click', function() {
            document.getElementById('userDropdown').classList.toggle('hidden');
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!document.getElementById('userMenu')?.contains(e.target)) {
                document.getElementById('userDropdown')?.classList.add('hidden');
            }
        });
    </script>
