"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { FileText, Clock, Users, Plus, Eye, Edit, Upload, CheckCircle, BookOpen, PenTool, Star } from "lucide-react"

interface SubjectiveTest {
  id: string
  title: string
  subject: string
  class: string
  description: string
  instructions: string
  duration: number
  total_marks: number
  status: string
  start_time: string
  end_time: string
  creator_name: string
  total_submissions: number
  total_questions: number
  created_at: string
}

interface User {
  id: string
  name: string
  email: string
  role: string
  class: string
}

interface SubjectiveTestsProps {
  user: User
}

export function SubjectiveTests({ user }: SubjectiveTestsProps) {
  const [tests, setTests] = useState<SubjectiveTest[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedTest, setSelectedTest] = useState<SubjectiveTest | null>(null)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [filterStatus, setFilterStatus] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")

  // New test form state
  const [newTest, setNewTest] = useState({
    title: "",
    subject: "",
    class: "",
    description: "",
    instructions: "",
    duration: 120,
    totalMarks: 100,
    status: "draft",
    startTime: "",
    endTime: "",
    questions: [
      {
        text: "",
        marks: 10,
        keywords: [],
        sampleAnswer: "",
        criteria: "",
      },
    ],
  })

  useEffect(() => {
    fetchTests()
  }, [user.id, user.role, filterStatus])

  const fetchTests = async () => {
    try {
      setLoading(true)
      const response = await fetch(
        `/api/subjective-tests?userId=${user.id}&userRole=${user.role}&status=${filterStatus !== "all" ? filterStatus : ""}`,
      )
      const data = await response.json()

      if (data.success) {
        setTests(data.tests)
      }
    } catch (error) {
      console.error("Error fetching tests:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleCreateTest = async () => {
    try {
      const response = await fetch("/api/subjective-tests", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...newTest,
          createdBy: user.id,
        }),
      })

      const data = await response.json()

      if (data.success) {
        setIsCreateDialogOpen(false)
        fetchTests()
        // Reset form
        setNewTest({
          title: "",
          subject: "",
          class: "",
          description: "",
          instructions: "",
          duration: 120,
          totalMarks: 100,
          status: "draft",
          startTime: "",
          endTime: "",
          questions: [
            {
              text: "",
              marks: 10,
              keywords: [],
              sampleAnswer: "",
              criteria: "",
            },
          ],
        })
      }
    } catch (error) {
      console.error("Error creating test:", error)
    }
  }

  const addQuestion = () => {
    setNewTest({
      ...newTest,
      questions: [
        ...newTest.questions,
        {
          text: "",
          marks: 10,
          keywords: [],
          sampleAnswer: "",
          criteria: "",
        },
      ],
    })
  }

  const updateQuestion = (index: number, field: string, value: any) => {
    const updatedQuestions = [...newTest.questions]
    updatedQuestions[index] = { ...updatedQuestions[index], [field]: value }
    setNewTest({ ...newTest, questions: updatedQuestions })
  }

  const removeQuestion = (index: number) => {
    const updatedQuestions = newTest.questions.filter((_, i) => i !== index)
    setNewTest({ ...newTest, questions: updatedQuestions })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "published":
        return "bg-green-100 text-green-800"
      case "draft":
        return "bg-yellow-100 text-yellow-800"
      case "archived":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-blue-100 text-blue-800"
    }
  }

  const filteredTests = tests.filter((test) => {
    const matchesSearch =
      test.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      test.subject.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesSearch
  })

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2">Subjective Tests</h1>
          <p className="text-gray-600">
            {user.role === "student"
              ? "Take subjective tests and submit your answers"
              : "Create and manage subjective tests with automated evaluation"}
          </p>
        </div>
        {(user.role === "teacher" || user.role === "admin") && (
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                <Plus className="mr-2 h-4 w-4" />
                Create Test
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create Subjective Test</DialogTitle>
                <DialogDescription>
                  Create a new subjective test with automated evaluation capabilities
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-6">
                {/* Basic Information */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="title">Test Title</Label>
                    <Input
                      id="title"
                      value={newTest.title}
                      onChange={(e) => setNewTest({ ...newTest, title: e.target.value })}
                      placeholder="Enter test title"
                    />
                  </div>
                  <div>
                    <Label htmlFor="subject">Subject</Label>
                    <Select
                      value={newTest.subject}
                      onValueChange={(value) => setNewTest({ ...newTest, subject: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select subject" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Physics">Physics</SelectItem>
                        <SelectItem value="Chemistry">Chemistry</SelectItem>
                        <SelectItem value="Mathematics">Mathematics</SelectItem>
                        <SelectItem value="Biology">Biology</SelectItem>
                        <SelectItem value="English">English</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="class">Class</Label>
                    <Select value={newTest.class} onValueChange={(value) => setNewTest({ ...newTest, class: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select class" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="9th">9th Grade</SelectItem>
                        <SelectItem value="10th">10th Grade</SelectItem>
                        <SelectItem value="11th">11th Grade</SelectItem>
                        <SelectItem value="12th">12th Grade</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="duration">Duration (minutes)</Label>
                    <Input
                      id="duration"
                      type="number"
                      value={newTest.duration}
                      onChange={(e) => setNewTest({ ...newTest, duration: Number.parseInt(e.target.value) })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="totalMarks">Total Marks</Label>
                    <Input
                      id="totalMarks"
                      type="number"
                      value={newTest.totalMarks}
                      onChange={(e) => setNewTest({ ...newTest, totalMarks: Number.parseInt(e.target.value) })}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newTest.description}
                    onChange={(e) => setNewTest({ ...newTest, description: e.target.value })}
                    placeholder="Describe the test objectives and scope"
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="instructions">Instructions</Label>
                  <Textarea
                    id="instructions"
                    value={newTest.instructions}
                    onChange={(e) => setNewTest({ ...newTest, instructions: e.target.value })}
                    placeholder="Provide detailed instructions for students"
                    rows={3}
                  />
                </div>

                {/* Questions Section */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold">Questions</h3>
                    <Button onClick={addQuestion} variant="outline" size="sm">
                      <Plus className="mr-2 h-4 w-4" />
                      Add Question
                    </Button>
                  </div>

                  {newTest.questions.map((question, index) => (
                    <Card key={index} className="mb-4">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-base">Question {index + 1}</CardTitle>
                          {newTest.questions.length > 1 && (
                            <Button
                              onClick={() => removeQuestion(index)}
                              variant="outline"
                              size="sm"
                              className="text-red-600"
                            >
                              Remove
                            </Button>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <Label>Question Text</Label>
                          <Textarea
                            value={question.text}
                            onChange={(e) => updateQuestion(index, "text", e.target.value)}
                            placeholder="Enter the question"
                            rows={3}
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>Marks</Label>
                            <Input
                              type="number"
                              value={question.marks}
                              onChange={(e) => updateQuestion(index, "marks", Number.parseInt(e.target.value))}
                            />
                          </div>
                          <div>
                            <Label>Expected Keywords (comma-separated)</Label>
                            <Input
                              value={question.keywords.join(", ")}
                              onChange={(e) =>
                                updateQuestion(
                                  index,
                                  "keywords",
                                  e.target.value.split(",").map((k) => k.trim()),
                                )
                              }
                              placeholder="keyword1, keyword2, keyword3"
                            />
                          </div>
                        </div>

                        <div>
                          <Label>Sample Answer (for reference)</Label>
                          <Textarea
                            value={question.sampleAnswer}
                            onChange={(e) => updateQuestion(index, "sampleAnswer", e.target.value)}
                            placeholder="Provide a sample answer for evaluation reference"
                            rows={3}
                          />
                        </div>

                        <div>
                          <Label>Evaluation Criteria</Label>
                          <Textarea
                            value={question.criteria}
                            onChange={(e) => updateQuestion(index, "criteria", e.target.value)}
                            placeholder="Specify what to look for when evaluating answers"
                            rows={2}
                          />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreateTest}>Create Test</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <Input
                placeholder="Search tests..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Tests</SelectItem>
                <SelectItem value="published">Published</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="archived">Archived</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Tests Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTests.map((test) => (
          <Card key={test.id} className="hover:shadow-lg transition-all duration-200 hover:scale-105">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg mb-2">{test.title}</CardTitle>
                  <div className="flex items-center space-x-2 mb-2">
                    <Badge variant="outline">{test.subject}</Badge>
                    <Badge variant="outline">{test.class}</Badge>
                    <Badge className={getStatusColor(test.status)}>{test.status}</Badge>
                  </div>
                </div>
                <FileText className="h-6 w-6 text-gray-400" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <p className="text-sm text-gray-600 line-clamp-2">{test.description}</p>

                <div className="flex items-center justify-between text-sm">
                  <span className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    {test.duration} min
                  </span>
                  <span className="flex items-center">
                    <Star className="h-4 w-4 mr-1" />
                    {test.total_marks} marks
                  </span>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <span className="flex items-center">
                    <BookOpen className="h-4 w-4 mr-1" />
                    {test.total_questions} questions
                  </span>
                  <span className="flex items-center">
                    <Users className="h-4 w-4 mr-1" />
                    {test.total_submissions} submissions
                  </span>
                </div>

                <div className="flex space-x-2 mt-4">
                  <Button
                    className="flex-1"
                    onClick={() => {
                      setSelectedTest(test)
                      setIsViewDialogOpen(true)
                    }}
                  >
                    <Eye className="mr-2 h-4 w-4" />
                    {user.role === "student" ? "Take Test" : "View"}
                  </Button>
                  {(user.role === "teacher" || user.role === "admin") && (
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredTests.length === 0 && (
        <Card className="text-center py-12">
          <CardContent>
            <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No tests found</h3>
            <p className="text-gray-600 mb-4">
              {user.role === "student"
                ? "No tests are currently available for your class"
                : "Create your first subjective test to get started"}
            </p>
            {(user.role === "teacher" || user.role === "admin") && (
              <Button onClick={() => setIsCreateDialogOpen(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Create Test
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Test View/Take Dialog */}
      {selectedTest && (
        <TestViewDialog
          test={selectedTest}
          user={user}
          isOpen={isViewDialogOpen}
          onClose={() => {
            setIsViewDialogOpen(false)
            setSelectedTest(null)
          }}
          onSubmissionComplete={fetchTests}
        />
      )}
    </div>
  )
}

// Test View/Take Dialog Component
function TestViewDialog({
  test,
  user,
  isOpen,
  onClose,
  onSubmissionComplete,
}: {
  test: SubjectiveTest
  user: User
  isOpen: boolean
  onClose: () => void
  onSubmissionComplete: () => void
}) {
  const [testDetails, setTestDetails] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [answers, setAnswers] = useState<string[]>([])
  const [submissionText, setSubmissionText] = useState("")
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (isOpen && test) {
      fetchTestDetails()
    }
  }, [isOpen, test])

  const fetchTestDetails = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/subjective-tests/${test.id}?userId=${user.id}`)
      const data = await response.json()

      if (data.success) {
        setTestDetails(data.test)
        setAnswers(new Array(data.test.questions.length).fill(""))
      }
    } catch (error) {
      console.error("Error fetching test details:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async () => {
    try {
      setSubmitting(true)
      const formData = new FormData()
      formData.append("testId", test.id)
      formData.append("studentId", user.id)
      formData.append("submissionText", submissionText)
      formData.append("answers", JSON.stringify(answers.map((text, index) => ({ text, score: 0 }))))

      if (selectedFile) {
        formData.append("file", selectedFile)
      }

      const response = await fetch("/api/subjective-tests/submit", {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (data.success) {
        onClose()
        onSubmissionComplete()
        alert(`Submission successful! Auto-score: ${data.autoScore}/${data.maxScore}`)
      } else {
        alert(data.error || "Submission failed")
      }
    } catch (error) {
      console.error("Submission error:", error)
      alert("Submission failed")
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <PenTool className="h-5 w-5" />
            <span>{test.title}</span>
          </DialogTitle>
          <DialogDescription>
            {test.subject} • {test.class} • {test.duration} minutes • {test.total_marks} marks
          </DialogDescription>
        </DialogHeader>

        {testDetails && (
          <div className="space-y-6">
            {/* Test Info */}
            <Card>
              <CardContent className="p-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <strong>Duration:</strong> {test.duration} minutes
                  </div>
                  <div>
                    <strong>Total Marks:</strong> {test.total_marks}
                  </div>
                  <div>
                    <strong>Questions:</strong> {testDetails.questions.length}
                  </div>
                  <div>
                    <strong>Status:</strong>
                    <Badge className={`ml-2 ${getStatusColor(test.status)}`}>{test.status}</Badge>
                  </div>
                </div>

                {test.description && (
                  <div className="mt-4">
                    <strong>Description:</strong>
                    <p className="mt-1 text-gray-600">{test.description}</p>
                  </div>
                )}

                {test.instructions && (
                  <div className="mt-4">
                    <strong>Instructions:</strong>
                    <p className="mt-1 text-gray-600">{test.instructions}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Check if user has already submitted */}
            {testDetails.userSubmission ? (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span>Submission Complete</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <strong>Score:</strong> {testDetails.userSubmission.total_score}/
                        {testDetails.userSubmission.max_score}
                      </div>
                      <div>
                        <strong>Status:</strong>
                        <Badge className="ml-2">{testDetails.userSubmission.status}</Badge>
                      </div>
                    </div>

                    {testDetails.userSubmission.feedback && (
                      <div>
                        <strong>Feedback:</strong>
                        <p className="mt-1 text-gray-600">{testDetails.userSubmission.feedback}</p>
                      </div>
                    )}

                    <div className="text-sm text-gray-500">
                      Submitted on: {new Date(testDetails.userSubmission.submitted_at).toLocaleString()}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : user.role === "student" ? (
              // Student submission form
              <div className="space-y-6">
                {/* Questions */}
                {testDetails.questions.map((question: any, index: number) => (
                  <Card key={question.id}>
                    <CardHeader>
                      <CardTitle className="text-base">
                        Question {question.question_number} ({question.marks} marks)
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <p className="font-medium">{question.question_text}</p>
                        <Textarea
                          value={answers[index]}
                          onChange={(e) => {
                            const newAnswers = [...answers]
                            newAnswers[index] = e.target.value
                            setAnswers(newAnswers)
                          }}
                          placeholder="Write your answer here..."
                          rows={6}
                          className="w-full"
                        />
                      </div>
                    </CardContent>
                  </Card>
                ))}

                {/* Additional submission options */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Additional Submission Options</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="submissionText">Additional Notes (Optional)</Label>
                      <Textarea
                        id="submissionText"
                        value={submissionText}
                        onChange={(e) => setSubmissionText(e.target.value)}
                        placeholder="Any additional notes or explanations..."
                        rows={3}
                      />
                    </div>

                    <div>
                      <Label htmlFor="file">Upload PDF (Optional)</Label>
                      <Input
                        id="file"
                        type="file"
                        accept=".pdf"
                        onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                        className="mt-1"
                      />
                      <p className="text-sm text-gray-500 mt-1">
                        You can upload a PDF with your handwritten solutions or diagrams
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={onClose}>
                    Cancel
                  </Button>
                  <Button onClick={handleSubmit} disabled={submitting}>
                    {submitting ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Submitting...
                      </>
                    ) : (
                      <>
                        <Upload className="mr-2 h-4 w-4" />
                        Submit Answers
                      </>
                    )}
                  </Button>
                </div>
              </div>
            ) : (
              // Teacher/Admin view
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Questions Preview</h3>
                {testDetails.questions.map((question: any, index: number) => (
                  <Card key={question.id}>
                    <CardHeader>
                      <CardTitle className="text-base">
                        Question {question.question_number} ({question.marks} marks)
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <p className="font-medium">{question.question_text}</p>

                        {question.expected_keywords && (
                          <div>
                            <strong className="text-sm">Expected Keywords:</strong>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {JSON.parse(question.expected_keywords).map((keyword: string, i: number) => (
                                <Badge key={i} variant="outline" className="text-xs">
                                  {keyword}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}

                        {question.sample_answer && (
                          <div>
                            <strong className="text-sm">Sample Answer:</strong>
                            <p className="text-sm text-gray-600 mt-1">{question.sample_answer}</p>
                          </div>
                        )}

                        {question.evaluation_criteria && (
                          <div>
                            <strong className="text-sm">Evaluation Criteria:</strong>
                            <p className="text-sm text-gray-600 mt-1">{question.evaluation_criteria}</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

function getStatusColor(status: string) {
  switch (status) {
    case "published":
      return "bg-green-100 text-green-800"
    case "draft":
      return "bg-yellow-100 text-yellow-800"
    case "archived":
      return "bg-gray-100 text-gray-800"
    default:
      return "bg-blue-100 text-blue-800"
  }
}
