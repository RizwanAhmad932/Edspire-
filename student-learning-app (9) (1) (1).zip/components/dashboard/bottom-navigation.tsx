"use client"

import { Badge } from "@/components/ui/badge"
import { Home, BookOpen, FileText, PenTool, Video, MessageCircle, User, Trophy } from "lucide-react"

interface BottomNavigationProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const menuItems = [
    { id: "home", label: "Home", icon: Home },
    { id: "courses", label: "Courses", icon: BookOpen },
    { id: "tests", label: "MCQ", icon: FileText },
    { id: "subjective-tests", label: "Essays", icon: PenTool, badge: "New" },
    { id: "live-classes", label: "Live", icon: Video },
    { id: "ask-ai", label: "AI", icon: MessageCircle },
    { id: "leaderboard", label: "Rank", icon: Trophy },
    { id: "profile", label: "Profile", icon: User },
  ]

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-2 py-1 z-50">
      <div className="flex items-center justify-around">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={`flex flex-col items-center justify-center p-2 rounded-lg transition-colors relative ${
              activeTab === item.id ? "text-blue-600 bg-blue-50" : "text-gray-600 hover:text-gray-900 hover:bg-gray-50"
            }`}
          >
            <item.icon className="h-5 w-5 mb-1" />
            <span className="text-xs font-medium">{item.label}</span>
            {item.badge && (
              <Badge variant="secondary" className="absolute -top-1 -right-1 text-xs px-1 py-0 h-4 min-w-4">
                {item.badge}
              </Badge>
            )}
          </button>
        ))}
      </div>
    </div>
  )
}
