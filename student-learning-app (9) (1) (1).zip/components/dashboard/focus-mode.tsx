"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Play, Pause, RotateCcw, Timer, Coffee } from "lucide-react"

export function FocusMode() {
  const [timeLeft, setTimeLeft] = useState(25 * 60) // 25 minutes in seconds
  const [isActive, setIsActive] = useState(false)
  const [isBreak, setIsBreak] = useState(false)
  const [sessions, setSessions] = useState(0)

  const totalTime = isBreak ? 5 * 60 : 25 * 60
  const progress = ((totalTime - timeLeft) / totalTime) * 100

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((time) => time - 1)
      }, 1000)
    } else if (timeLeft === 0) {
      // Timer finished
      if (!isBreak) {
        setSessions((prev) => prev + 1)
        setIsBreak(true)
        setTimeLeft(5 * 60) // 5 minute break
      } else {
        setIsBreak(false)
        setTimeLeft(25 * 60) // Back to 25 minutes
      }
      setIsActive(false)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isActive, timeLeft, isBreak])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const handleStart = () => setIsActive(true)
  const handlePause = () => setIsActive(false)
  const handleReset = () => {
    setIsActive(false)
    setTimeLeft(isBreak ? 5 * 60 : 25 * 60)
  }

  const recentSessions = [
    { date: "Today", sessions: 3, totalTime: "1h 15m" },
    { date: "Yesterday", sessions: 4, totalTime: "1h 40m" },
    { date: "2 days ago", sessions: 2, totalTime: "50m" },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-2">Focus Mode</h1>
        <p className="text-gray-600">Use the Pomodoro technique to boost your productivity</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Timer */}
        <div className="lg:col-span-2">
          <Card>
            <CardContent className="p-8">
              <div className="text-center space-y-6">
                <div className="flex items-center justify-center space-x-2 mb-4">
                  {isBreak ? (
                    <>
                      <Coffee className="h-6 w-6 text-green-600" />
                      <span className="text-lg font-medium text-green-600">Break Time</span>
                    </>
                  ) : (
                    <>
                      <Timer className="h-6 w-6 text-blue-600" />
                      <span className="text-lg font-medium text-blue-600">Focus Session</span>
                    </>
                  )}
                </div>

                <div className="relative">
                  <div className="text-6xl font-mono font-bold text-gray-800 mb-4">{formatTime(timeLeft)}</div>
                  <Progress value={progress} className="w-full h-2" />
                </div>

                <div className="flex justify-center space-x-4">
                  {!isActive ? (
                    <Button onClick={handleStart} size="lg" className="px-8">
                      <Play className="mr-2 h-5 w-5" />
                      Start
                    </Button>
                  ) : (
                    <Button onClick={handlePause} size="lg" variant="outline" className="px-8 bg-transparent">
                      <Pause className="mr-2 h-5 w-5" />
                      Pause
                    </Button>
                  )}
                  <Button onClick={handleReset} size="lg" variant="outline">
                    <RotateCcw className="mr-2 h-5 w-5" />
                    Reset
                  </Button>
                </div>

                <div className="text-sm text-gray-600">
                  Sessions completed today: <span className="font-medium">{sessions}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Stats & History */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Today's Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Sessions</span>
                    <span>{sessions}/8</span>
                  </div>
                  <Progress value={(sessions / 8) * 100} />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Focus Time</span>
                    <span>{sessions * 25}m</span>
                  </div>
                  <Progress value={((sessions * 25) / 200) * 100} />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Recent Sessions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentSessions.map((session, index) => (
                  <div key={index} className="flex justify-between items-center p-2 border rounded">
                    <div>
                      <div className="font-medium text-sm">{session.date}</div>
                      <div className="text-xs text-gray-600">{session.totalTime}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold">{session.sessions}</div>
                      <div className="text-xs text-gray-600">sessions</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Tips */}
      <Card>
        <CardHeader>
          <CardTitle>Pomodoro Tips</CardTitle>
          <CardDescription>Make the most of your focus sessions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="font-medium mb-2">During Focus Sessions:</h4>
              <ul className="space-y-1 text-gray-600">
                <li>• Turn off notifications</li>
                <li>• Focus on one task only</li>
                <li>• Keep water nearby</li>
                <li>• Take notes if needed</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2">During Breaks:</h4>
              <ul className="space-y-1 text-gray-600">
                <li>• Step away from your desk</li>
                <li>• Do light stretching</li>
                <li>• Avoid screens if possible</li>
                <li>• Take deep breaths</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
