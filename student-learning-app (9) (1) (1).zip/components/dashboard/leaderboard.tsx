"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Trophy, Medal, Award, Crown, Star, TrendingUp, Calendar, Users } from "lucide-react"

interface User {
  id: string
  name: string
  email: string
  plan: "free" | "premium" | "pro"
  xp: number
  avatar?: string
  role: "student" | "admin"
  joinDate: string
  lastActive: string
}

interface LeaderboardProps {
  user: User
}

interface LeaderboardEntry {
  id: string
  name: string
  xp: number
  avatar?: string
  plan: "free" | "premium" | "pro"
  streak: number
  coursesCompleted: number
  testsCompleted: number
  rank: number
  change: number // position change from last period
}

export function Leaderboard({ user }: LeaderboardProps) {
  const [activeTab, setActiveTab] = useState<"weekly" | "monthly" | "allTime">("weekly")
  const [leaderboardData, setLeaderboardData] = useState<LeaderboardEntry[]>([])

  useEffect(() => {
    // Generate mock leaderboard data
    const generateLeaderboard = (period: "weekly" | "monthly" | "allTime") => {
      const baseData: LeaderboardEntry[] = [
        {
          id: "1",
          name: "Sarah Johnson",
          xp: period === "weekly" ? 850 : period === "monthly" ? 3200 : 4200,
          avatar: "/placeholder.svg?height=40&width=40&text=SJ",
          plan: "pro",
          streak: 12,
          coursesCompleted: 6,
          testsCompleted: 18,
          rank: 1,
          change: 0,
        },
        {
          id: "2",
          name: "Mike Chen",
          xp: period === "weekly" ? 720 : period === "monthly" ? 2800 : 3850,
          avatar: "/placeholder.svg?height=40&width=40&text=MC",
          plan: "premium",
          streak: 8,
          coursesCompleted: 4,
          testsCompleted: 15,
          rank: 2,
          change: 1,
        },
        {
          id: "3",
          name: "Emma Davis",
          xp: period === "weekly" ? 680 : period === "monthly" ? 2650 : 3600,
          avatar: "/placeholder.svg?height=40&width=40&text=ED",
          plan: "premium",
          streak: 15,
          coursesCompleted: 5,
          testsCompleted: 12,
          rank: 3,
          change: -1,
        },
        {
          id: "4",
          name: "John Doe",
          xp: period === "weekly" ? 520 : period === "monthly" ? 1850 : 2850,
          avatar: "/placeholder.svg?height=40&width=40&text=JD",
          plan: "premium",
          streak: 7,
          coursesCompleted: 3,
          testsCompleted: 10,
          rank: 4,
          change: 2,
        },
        {
          id: "5",
          name: "Alex Rodriguez",
          xp: period === "weekly" ? 480 : period === "monthly" ? 1650 : 2400,
          avatar: "/placeholder.svg?height=40&width=40&text=AR",
          plan: "free",
          streak: 5,
          coursesCompleted: 2,
          testsCompleted: 8,
          rank: 5,
          change: 0,
        },
        {
          id: "6",
          name: "Lisa Wang",
          xp: period === "weekly" ? 420 : period === "monthly" ? 1450 : 2100,
          avatar: "/placeholder.svg?height=40&width=40&text=LW",
          plan: "premium",
          streak: 9,
          coursesCompleted: 3,
          testsCompleted: 9,
          rank: 6,
          change: -2,
        },
        {
          id: "7",
          name: "David Kim",
          xp: period === "weekly" ? 380 : period === "monthly" ? 1320 : 1950,
          avatar: "/placeholder.svg?height=40&width=40&text=DK",
          plan: "free",
          streak: 4,
          coursesCompleted: 2,
          testsCompleted: 7,
          rank: 7,
          change: 1,
        },
        {
          id: "8",
          name: "Rachel Green",
          xp: period === "weekly" ? 350 : period === "monthly" ? 1200 : 1800,
          avatar: "/placeholder.svg?height=40&width=40&text=RG",
          plan: "pro",
          streak: 6,
          coursesCompleted: 4,
          testsCompleted: 11,
          rank: 8,
          change: 0,
        },
      ]

      return baseData
    }

    setLeaderboardData(generateLeaderboard(activeTab))
  }, [activeTab])

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-6 w-6 text-yellow-500" />
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />
      case 3:
        return <Award className="h-6 w-6 text-amber-600" />
      default:
        return <span className="text-lg font-bold text-gray-600">#{rank}</span>
    }
  }

  const getPlanIcon = (plan: string) => {
    switch (plan) {
      case "pro":
        return <Crown className="h-4 w-4 text-purple-500" />
      case "premium":
        return <Star className="h-4 w-4 text-blue-500" />
      default:
        return null
    }
  }

  const getChangeIndicator = (change: number) => {
    if (change > 0) {
      return <TrendingUp className="h-4 w-4 text-green-500" />
    } else if (change < 0) {
      return <TrendingUp className="h-4 w-4 text-red-500 rotate-180" />
    }
    return <div className="h-4 w-4" />
  }

  const userRank = leaderboardData.findIndex((entry) => entry.name === user.name) + 1 || "N/A"
  const userEntry = leaderboardData.find((entry) => entry.name === user.name)

  const stats = {
    totalParticipants: 156,
    yourRank: userRank,
    topPercentile: userRank !== "N/A" ? Math.round((1 - ((userRank as number) - 1) / 156) * 100) : 0,
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-2">Leaderboard</h1>
        <p className="text-gray-600">Compete with fellow learners and track your progress</p>
      </div>

      {/* Your Stats */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold mb-1">Your Position</h3>
              <div className="flex items-center space-x-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-blue-600">#{userRank}</p>
                  <p className="text-sm text-gray-600">Current Rank</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-purple-600">{user.xp}</p>
                  <p className="text-sm text-gray-600">XP Points</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-green-600">{stats.topPercentile}%</p>
                  <p className="text-sm text-gray-600">Top Percentile</p>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-600 mb-1">Total Participants</div>
              <div className="flex items-center space-x-2">
                <Users className="h-4 w-4 text-gray-500" />
                <span className="font-semibold">{stats.totalParticipants}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Time Period Tabs */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Rankings</CardTitle>
              <CardDescription>See how you stack up against other learners</CardDescription>
            </div>
            <div className="flex space-x-1 bg-gray-100 rounded-lg p-1">
              <Button
                size="sm"
                variant={activeTab === "weekly" ? "default" : "ghost"}
                onClick={() => setActiveTab("weekly")}
                className="text-xs"
              >
                <Calendar className="h-3 w-3 mr-1" />
                Weekly
              </Button>
              <Button
                size="sm"
                variant={activeTab === "monthly" ? "default" : "ghost"}
                onClick={() => setActiveTab("monthly")}
                className="text-xs"
              >
                <Calendar className="h-3 w-3 mr-1" />
                Monthly
              </Button>
              <Button
                size="sm"
                variant={activeTab === "allTime" ? "default" : "ghost"}
                onClick={() => setActiveTab("allTime")}
                className="text-xs"
              >
                <Trophy className="h-3 w-3 mr-1" />
                All Time
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {leaderboardData.map((entry, index) => (
              <div
                key={entry.id}
                className={`flex items-center space-x-4 p-4 rounded-lg border transition-colors ${
                  entry.name === user.name ? "bg-blue-50 border-blue-200" : "hover:bg-gray-50"
                }`}
              >
                {/* Rank */}
                <div className="flex items-center space-x-2 w-12">
                  {getRankIcon(entry.rank)}
                  {getChangeIndicator(entry.change)}
                </div>

                {/* Avatar & Name */}
                <div className="flex items-center space-x-3 flex-1">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={entry.avatar || "/placeholder.svg"} />
                    <AvatarFallback>
                      {entry.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-semibold">{entry.name}</span>
                      {getPlanIcon(entry.plan)}
                      {entry.name === user.name && (
                        <Badge variant="secondary" className="text-xs">
                          You
                        </Badge>
                      )}
                    </div>
                    <div className="text-sm text-gray-600">
                      {entry.coursesCompleted} courses • {entry.testsCompleted} tests
                    </div>
                  </div>
                </div>

                {/* Stats */}
                <div className="text-right">
                  <div className="text-lg font-bold text-blue-600">{entry.xp}</div>
                  <div className="text-sm text-gray-600">XP</div>
                </div>

                <div className="text-right">
                  <div className="text-lg font-bold text-orange-600">{entry.streak}</div>
                  <div className="text-sm text-gray-600">Streak</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Achievement Progress */}
      <Card>
        <CardHeader>
          <CardTitle>Next Milestone</CardTitle>
          <CardDescription>Keep learning to reach the next level</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Progress to next rank</span>
                <span>
                  {user.xp} / {userEntry ? userEntry.xp + 200 : user.xp + 200} XP
                </span>
              </div>
              <Progress value={userEntry ? (user.xp / (userEntry.xp + 200)) * 100 : 75} className="h-2" />
            </div>

            <div className="grid md:grid-cols-3 gap-4 text-center">
              <div className="p-3 bg-yellow-50 rounded-lg">
                <Trophy className="h-6 w-6 text-yellow-500 mx-auto mb-1" />
                <p className="text-sm font-medium">Top 10</p>
                <p className="text-xs text-gray-600">Earn 500 more XP</p>
              </div>
              <div className="p-3 bg-purple-50 rounded-lg">
                <Crown className="h-6 w-6 text-purple-500 mx-auto mb-1" />
                <p className="text-sm font-medium">Study Streak</p>
                <p className="text-xs text-gray-600">Maintain 30 days</p>
              </div>
              <div className="p-3 bg-blue-50 rounded-lg">
                <Star className="h-6 w-6 text-blue-500 mx-auto mb-1" />
                <p className="text-sm font-medium">Course Master</p>
                <p className="text-xs text-gray-600">Complete 10 courses</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
