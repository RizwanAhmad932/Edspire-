"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { generateQuestionsWithGemini } from "@/lib/utils"
import { FileText, Clock, Target, Plus, Play, Search, Zap, Brain, CheckCircle } from "lucide-react"

interface Question {
  id: string
  question: string
  options: string[]
  correctAnswer: number
  explanation: string
  difficulty: string
  subject: string
}

interface Test {
  id: string
  title: string
  subject: string
  type: string
  difficulty: string
  questions: number
  duration: number
  attempts: number
  bestScore: number | null
}

export function Tests() {
  const [tests, setTests] = useState<Test[]>([
    {
      id: "1",
      title: "Physics Mock Test - Mechanics",
      subject: "Physics",
      type: "Mock Test",
      difficulty: "Medium",
      questions: 30,
      duration: 90,
      attempts: 3,
      bestScore: 85,
    },
    {
      id: "2",
      title: "Chemistry Practice Quiz",
      subject: "Chemistry",
      type: "Practice",
      difficulty: "Easy",
      questions: 20,
      duration: 45,
      attempts: 5,
      bestScore: 92,
    },
    {
      id: "3",
      title: "Mathematics Advanced Test",
      subject: "Mathematics",
      type: "Mock Test",
      difficulty: "Hard",
      questions: 40,
      duration: 120,
      attempts: 2,
      bestScore: 78,
    },
    {
      id: "4",
      title: "Biology Comprehensive Test",
      subject: "Biology",
      type: "Mock Test",
      difficulty: "Medium",
      questions: 35,
      duration: 100,
      attempts: 1,
      bestScore: null,
    },
  ])

  const [filteredTests, setFilteredTests] = useState(tests)
  const [searchTerm, setSearchTerm] = useState("")
  const [subjectFilter, setSubjectFilter] = useState("all")
  const [difficultyFilter, setDifficultyFilter] = useState("all")
  const [isCreatingCustomTest, setIsCreatingCustomTest] = useState(false)
  const [customTestConfig, setCustomTestConfig] = useState({
    subject: "",
    difficulty: "Medium",
    questions: 20,
    duration: 60,
    title: "",
  })
  const [isGenerating, setIsGenerating] = useState(false)
  const [currentTest, setCurrentTest] = useState<Question[] | null>(null)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([])
  const [testStarted, setTestStarted] = useState(false)
  const [testCompleted, setTestCompleted] = useState(false)
  const [score, setScore] = useState(0)
  const [timeRemaining, setTimeRemaining] = useState(0)

  useEffect(() => {
    let filtered = tests

    if (searchTerm) {
      filtered = filtered.filter(
        (test) =>
          test.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          test.subject.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (subjectFilter !== "all") {
      filtered = filtered.filter((test) => test.subject === subjectFilter)
    }

    if (difficultyFilter !== "all") {
      filtered = filtered.filter((test) => test.difficulty === difficultyFilter)
    }

    setFilteredTests(filtered)
  }, [searchTerm, subjectFilter, difficultyFilter, tests])

  useEffect(() => {
    let timer: NodeJS.Timeout
    if (testStarted && timeRemaining > 0 && !testCompleted) {
      timer = setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            handleTestComplete()
            return 0
          }
          return prev - 1
        })
      }, 1000)
    }
    return () => clearInterval(timer)
  }, [testStarted, timeRemaining, testCompleted])

  const handleCreateCustomTest = async () => {
    if (!customTestConfig.subject || !customTestConfig.title) {
      alert("Please fill in all required fields")
      return
    }

    setIsGenerating(true)
    try {
      const result = await generateQuestionsWithGemini(
        customTestConfig.subject,
        customTestConfig.difficulty,
        customTestConfig.questions,
      )

      if (result.questions) {
        setCurrentTest(result.questions)
        setTimeRemaining(customTestConfig.duration * 60)
        setSelectedAnswers(new Array(result.questions.length).fill(-1))
        setIsCreatingCustomTest(false)
        setTestStarted(true)
        setCurrentQuestionIndex(0)
        setTestCompleted(false)
        setScore(0)
      }
    } catch (error) {
      console.error("Error creating custom test:", error)
      alert("Failed to create custom test. Please try again.")
    } finally {
      setIsGenerating(false)
    }
  }

  const handleAnswerSelect = (answerIndex: number) => {
    const newAnswers = [...selectedAnswers]
    newAnswers[currentQuestionIndex] = answerIndex
    setSelectedAnswers(newAnswers)
  }

  const handleNextQuestion = () => {
    if (currentQuestionIndex < (currentTest?.length || 0) - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1)
    }
  }

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1)
    }
  }

  const handleTestComplete = () => {
    if (!currentTest) return

    let correctAnswers = 0
    currentTest.forEach((question, index) => {
      if (selectedAnswers[index] === question.correctAnswer) {
        correctAnswers++
      }
    })

    const finalScore = Math.round((correctAnswers / currentTest.length) * 100)
    setScore(finalScore)
    setTestCompleted(true)
    setTestStarted(false)
  }

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case "easy":
        return "bg-green-100 text-green-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "hard":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600"
    if (score >= 60) return "text-yellow-600"
    return "text-red-600"
  }

  if (testStarted && currentTest) {
    const currentQuestion = currentTest[currentQuestionIndex]
    const progress = ((currentQuestionIndex + 1) / currentTest.length) * 100

    return (
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Test Header */}
        <Card className="shadow-lg">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center space-x-2">
                  <Brain className="h-5 w-5" />
                  <span>Custom Test - {customTestConfig.subject}</span>
                </CardTitle>
                <CardDescription>
                  Question {currentQuestionIndex + 1} of {currentTest.length}
                </CardDescription>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-blue-600">{formatTime(timeRemaining)}</div>
                <div className="text-sm text-gray-600">Time Remaining</div>
              </div>
            </div>
            <Progress value={progress} className="mt-4" />
          </CardHeader>
        </Card>

        {/* Question Card */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">{currentQuestion.question}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {currentQuestion.options.map((option, index) => (
                <Button
                  key={index}
                  variant={selectedAnswers[currentQuestionIndex] === index ? "default" : "outline"}
                  className="w-full text-left justify-start h-auto p-4"
                  onClick={() => handleAnswerSelect(index)}
                >
                  <span className="mr-3 font-bold">{String.fromCharCode(65 + index)}.</span>
                  {option}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between items-center">
          <Button variant="outline" onClick={handlePreviousQuestion} disabled={currentQuestionIndex === 0}>
            Previous
          </Button>

          <div className="flex space-x-2">
            {currentTest.map((_, index) => (
              <Button
                key={index}
                variant={
                  index === currentQuestionIndex ? "default" : selectedAnswers[index] !== -1 ? "secondary" : "outline"
                }
                size="sm"
                className="w-8 h-8 p-0"
                onClick={() => setCurrentQuestionIndex(index)}
              >
                {index + 1}
              </Button>
            ))}
          </div>

          {currentQuestionIndex === currentTest.length - 1 ? (
            <Button onClick={handleTestComplete} className="bg-green-600 hover:bg-green-700">
              <CheckCircle className="h-4 w-4 mr-2" />
              Submit Test
            </Button>
          ) : (
            <Button onClick={handleNextQuestion}>Next</Button>
          )}
        </div>
      </div>
    )
  }

  if (testCompleted && currentTest) {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        <Card className="shadow-lg">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Test Completed!</CardTitle>
            <CardDescription>Here are your results</CardDescription>
          </CardHeader>
          <CardContent className="text-center space-y-6">
            <div className="text-6xl font-bold text-blue-600">{score}%</div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {selectedAnswers.filter((answer, index) => answer === currentTest[index].correctAnswer).length}
                </div>
                <div className="text-sm text-gray-600">Correct</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">
                  {
                    selectedAnswers.filter(
                      (answer, index) => answer !== -1 && answer !== currentTest[index].correctAnswer,
                    ).length
                  }
                </div>
                <div className="text-sm text-gray-600">Incorrect</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-600">
                  {selectedAnswers.filter((answer) => answer === -1).length}
                </div>
                <div className="text-sm text-gray-600">Unanswered</div>
              </div>
            </div>
            <Button
              onClick={() => {
                setCurrentTest(null)
                setTestStarted(false)
                setTestCompleted(false)
                setCurrentQuestionIndex(0)
                setSelectedAnswers([])
              }}
              className="w-full"
            >
              Back to Tests
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2">Tests & Quizzes</h1>
          <p className="text-gray-600">Practice with our comprehensive test library</p>
        </div>
        <Dialog open={isCreatingCustomTest} onOpenChange={setIsCreatingCustomTest}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
              <Plus className="mr-2 h-4 w-4" />
              Create Custom Test
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <Zap className="h-5 w-5" />
                <span>Create Custom Test with AI</span>
              </DialogTitle>
              <DialogDescription>Generate unique questions using Gemini AI</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="test-title">Test Title</Label>
                <Input
                  id="test-title"
                  placeholder="Enter test title"
                  value={customTestConfig.title}
                  onChange={(e) => setCustomTestConfig({ ...customTestConfig, title: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="subject">Subject</Label>
                <Select
                  value={customTestConfig.subject}
                  onValueChange={(value) => setCustomTestConfig({ ...customTestConfig, subject: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select subject" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Physics">Physics</SelectItem>
                    <SelectItem value="Chemistry">Chemistry</SelectItem>
                    <SelectItem value="Mathematics">Mathematics</SelectItem>
                    <SelectItem value="Biology">Biology</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="difficulty">Difficulty</Label>
                <Select
                  value={customTestConfig.difficulty}
                  onValueChange={(value) => setCustomTestConfig({ ...customTestConfig, difficulty: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Easy">Easy</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Hard">Hard</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="questions">Number of Questions</Label>
                <Select
                  value={customTestConfig.questions.toString()}
                  onValueChange={(value) =>
                    setCustomTestConfig({ ...customTestConfig, questions: Number.parseInt(value) })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10 Questions</SelectItem>
                    <SelectItem value="20">20 Questions</SelectItem>
                    <SelectItem value="30">30 Questions</SelectItem>
                    <SelectItem value="50">50 Questions</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="duration">Duration (minutes)</Label>
                <Select
                  value={customTestConfig.duration.toString()}
                  onValueChange={(value) =>
                    setCustomTestConfig({ ...customTestConfig, duration: Number.parseInt(value) })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="60">60 minutes</SelectItem>
                    <SelectItem value="90">90 minutes</SelectItem>
                    <SelectItem value="120">120 minutes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button
                onClick={handleCreateCustomTest}
                disabled={isGenerating}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                {isGenerating ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Generating with AI...
                  </>
                ) : (
                  <>
                    <Brain className="mr-2 h-4 w-4" />
                    Generate Test
                  </>
                )}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card className="shadow-lg">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search tests..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={subjectFilter} onValueChange={setSubjectFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="All Subjects" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Subjects</SelectItem>
                <SelectItem value="Physics">Physics</SelectItem>
                <SelectItem value="Chemistry">Chemistry</SelectItem>
                <SelectItem value="Mathematics">Mathematics</SelectItem>
                <SelectItem value="Biology">Biology</SelectItem>
              </SelectContent>
            </Select>
            <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="All Difficulties" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Difficulties</SelectItem>
                <SelectItem value="Easy">Easy</SelectItem>
                <SelectItem value="Medium">Medium</SelectItem>
                <SelectItem value="Hard">Hard</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Tests Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTests.map((test) => (
          <Card key={test.id} className="hover:shadow-lg transition-all duration-200 hover:scale-105">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg mb-2">{test.title}</CardTitle>
                  <div className="flex items-center space-x-2 mb-2">
                    <Badge variant="outline">{test.subject}</Badge>
                    <Badge className={getDifficultyColor(test.difficulty)}>{test.difficulty}</Badge>
                  </div>
                </div>
                <FileText className="h-6 w-6 text-gray-400" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="flex items-center">
                    <Target className="h-4 w-4 mr-1" />
                    {test.questions} Questions
                  </span>
                  <span className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    {test.duration} min
                  </span>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <span>Attempts: {test.attempts}</span>
                  {test.bestScore && (
                    <span className={`font-medium ${getScoreColor(test.bestScore)}`}>Best: {test.bestScore}%</span>
                  )}
                </div>

                <Button className="w-full mt-4">
                  <Play className="mr-2 h-4 w-4" />
                  Start Test
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredTests.length === 0 && (
        <Card className="text-center py-12">
          <CardContent>
            <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No tests found</h3>
            <p className="text-gray-600 mb-4">Try adjusting your search or filters</p>
            <Button
              onClick={() => {
                setSearchTerm("")
                setSubjectFilter("all")
                setDifficultyFilter("all")
              }}
            >
              Clear Filters
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
