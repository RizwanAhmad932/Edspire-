"use client"
import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Mail,
  Calendar,
  Target,
  BookOpen,
  Clock,
  Award,
  Edit,
  Camera,
  Crown,
  Zap,
  TrendingUp,
  Star,
} from "lucide-react"

interface ProfileProps {
  user: {
    id: string
    name: string
    email: string
    plan: "free" | "premium" | "pro"
    xp: number
    avatar?: string
    role: "student" | "admin"
    joinDate: string
    lastActive: string
  }
}

export function Profile({ user }: ProfileProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [selectedAvatar, setSelectedAvatar] = useState(user.avatar || "")
  const [editedName, setEditedName] = useState(user.name)
  const [editedEmail, setEditedEmail] = useState(user.email)

  const currentLevel = Math.floor(user.xp / 100) + 1
  const xpForNextLevel = currentLevel * 100 - user.xp
  const progressToNextLevel = ((user.xp % 100) / 100) * 100

  // Mock data for demonstration
  const stats = {
    testsCompleted: 127,
    totalStudyTime: 2340, // minutes
    averageScore: 78,
    streak: 7,
    coursesEnrolled: 12,
    questionsAnswered: 2847,
  }

  const achievements = [
    {
      id: 1,
      title: "First Steps",
      description: "Complete your first test",
      icon: "🎯",
      unlocked: true,
      date: "2024-01-15",
    },
    {
      id: 2,
      title: "Speed Demon",
      description: "Complete 10 tests in under 5 minutes each",
      icon: "⚡",
      unlocked: true,
      date: "2024-01-20",
    },
    {
      id: 3,
      title: "Physics Master",
      description: "Score 90%+ in 5 consecutive physics tests",
      icon: "🔬",
      unlocked: true,
      date: "2024-01-25",
    },
    {
      id: 4,
      title: "Streak Champion",
      description: "Maintain 7-day study streak",
      icon: "🔥",
      unlocked: true,
      date: "2024-02-01",
    },
    {
      id: 5,
      title: "Knowledge Seeker",
      description: "Ask 50 questions to AI tutor",
      icon: "🧠",
      unlocked: false,
      progress: 32,
    },
    { id: 6, title: "Perfect Score", description: "Score 100% in any test", icon: "💯", unlocked: false, progress: 0 },
  ]

  const recentActivity = [
    { id: 1, type: "test", title: "Completed Physics Mock Test 15", score: 85, time: "2 hours ago" },
    { id: 2, type: "course", title: "Started Organic Chemistry Chapter 3", time: "5 hours ago" },
    { id: 3, type: "achievement", title: "Unlocked 'Streak Champion' achievement", time: "1 day ago" },
    { id: 4, type: "ai", title: "Asked AI about quantum mechanics", time: "1 day ago" },
    { id: 5, type: "test", title: "Completed Mathematics Practice Set 8", score: 92, time: "2 days ago" },
  ]

  const avatarOptions = [
    "/placeholder.svg?height=80&width=80&text=👨‍🎓",
    "/placeholder.svg?height=80&width=80&text=👩‍🎓",
    "/placeholder.svg?height=80&width=80&text=🧑‍💻",
    "/placeholder.svg?height=80&width=80&text=👨‍🔬",
    "/placeholder.svg?height=80&width=80&text=👩‍🔬",
    "/placeholder.svg?height=80&width=80&text=🤓",
    "/placeholder.svg?height=80&width=80&text=😊",
    "/placeholder.svg?height=80&width=80&text=🚀",
  ]

  const getPlanColor = (plan: string) => {
    switch (plan) {
      case "free":
        return "bg-gray-100 text-gray-700"
      case "premium":
        return "bg-blue-100 text-blue-700"
      case "pro":
        return "bg-purple-100 text-purple-700"
      default:
        return "bg-gray-100 text-gray-700"
    }
  }

  const getPlanIcon = (plan: string) => {
    switch (plan) {
      case "pro":
        return <Crown className="h-4 w-4" />
      case "premium":
        return <Zap className="h-4 w-4" />
      default:
        return null
    }
  }

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "test":
        return "📝"
      case "course":
        return "📚"
      case "achievement":
        return "🏆"
      case "ai":
        return "🤖"
      default:
        return "📌"
    }
  }

  const handleSaveProfile = () => {
    // Here you would typically save to backend
    setIsEditing(false)
    // Update user data...
  }

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <Card className="bg-gradient-to-r from-blue-50 via-purple-50 to-pink-50 border-blue-200">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row md:items-center gap-6">
            <div className="flex items-center gap-4">
              <div className="relative">
                <Avatar className="h-20 w-20">
                  <AvatarImage src={selectedAvatar || "/placeholder.svg"} alt={user.name} />
                  <AvatarFallback className="bg-blue-600 text-white text-xl">
                    {user.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button size="sm" className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full p-0">
                      <Camera className="h-4 w-4" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Choose Avatar</DialogTitle>
                      <DialogDescription>Select an avatar for your profile</DialogDescription>
                    </DialogHeader>
                    <div className="grid grid-cols-4 gap-4 py-4">
                      {avatarOptions.map((avatar, index) => (
                        <button
                          key={index}
                          onClick={() => setSelectedAvatar(avatar)}
                          className={`p-2 rounded-lg border-2 transition-colors ${
                            selectedAvatar === avatar
                              ? "border-blue-500 bg-blue-50"
                              : "border-gray-200 hover:border-gray-300"
                          }`}
                        >
                          <Avatar className="h-12 w-12 mx-auto">
                            <AvatarImage src={avatar || "/placeholder.svg"} />
                            <AvatarFallback>A{index + 1}</AvatarFallback>
                          </Avatar>
                        </button>
                      ))}
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
              <div>
                {isEditing ? (
                  <div className="space-y-2">
                    <Input
                      value={editedName}
                      onChange={(e) => setEditedName(e.target.value)}
                      className="font-semibold text-lg"
                    />
                    <Input
                      value={editedEmail}
                      onChange={(e) => setEditedEmail(e.target.value)}
                      className="text-gray-600"
                    />
                  </div>
                ) : (
                  <>
                    <h1 className="text-2xl font-bold text-gray-900">{user.name}</h1>
                    <p className="text-gray-600">{user.email}</p>
                  </>
                )}
                <div className="flex items-center gap-2 mt-2">
                  <Badge className={`${getPlanColor(user.plan)}`}>
                    {getPlanIcon(user.plan)}
                    <span className="ml-1">{user.plan.toUpperCase()}</span>
                  </Badge>
                  <Badge variant="outline">Class 12 • JEE Main 2025</Badge>
                </div>
              </div>
            </div>
            <div className="flex-1">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">{currentLevel}</div>
                  <div className="text-sm text-gray-600">Level</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">{user.xp}</div>
                  <div className="text-sm text-gray-600">Total XP</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">{stats.streak}</div>
                  <div className="text-sm text-gray-600">Day Streak</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">{stats.averageScore}%</div>
                  <div className="text-sm text-gray-600">Avg Score</div>
                </div>
              </div>
              <div className="mt-4">
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>Progress to Level {currentLevel + 1}</span>
                  <span>{xpForNextLevel} XP to go</span>
                </div>
                <Progress value={progressToNextLevel} className="h-2" />
              </div>
            </div>
            <div className="flex gap-2">
              {isEditing ? (
                <>
                  <Button onClick={handleSaveProfile} size="sm">
                    Save
                  </Button>
                  <Button onClick={() => setIsEditing(false)} variant="outline" size="sm">
                    Cancel
                  </Button>
                </>
              ) : (
                <Button onClick={() => setIsEditing(true)} variant="outline" size="sm">
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Profile
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Statistics */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-blue-500" />
              Study Statistics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{stats.testsCompleted}</div>
                <div className="text-sm text-blue-700">Tests Completed</div>
              </div>
              <div className="text-center p-3 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{Math.floor(stats.totalStudyTime / 60)}h</div>
                <div className="text-sm text-green-700">Study Time</div>
              </div>
              <div className="text-center p-3 bg-purple-50 rounded-lg">
                <div className="text-2xl font-bold text-purple-600">{stats.coursesEnrolled}</div>
                <div className="text-sm text-purple-700">Courses</div>
              </div>
              <div className="text-center p-3 bg-orange-50 rounded-lg">
                <div className="text-2xl font-bold text-orange-600">{stats.questionsAnswered}</div>
                <div className="text-sm text-orange-700">Questions</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Personal Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Mail className="h-5 w-5 text-green-500" />
              Personal Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3">
              <Mail className="h-4 w-4 text-gray-500" />
              <div>
                <div className="text-sm font-medium">Email</div>
                <div className="text-sm text-gray-600">{user.email}</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Calendar className="h-4 w-4 text-gray-500" />
              <div>
                <div className="text-sm font-medium">Joined</div>
                <div className="text-sm text-gray-600">{new Date(user.joinDate).toLocaleDateString()}</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Target className="h-4 w-4 text-gray-500" />
              <div>
                <div className="text-sm font-medium">Target Exam</div>
                <div className="text-sm text-gray-600">JEE Main 2025</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <BookOpen className="h-4 w-4 text-gray-500" />
              <div>
                <div className="text-sm font-medium">Class</div>
                <div className="text-sm text-gray-600">12th Grade</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Achievements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5 text-yellow-500" />
            Achievements
          </CardTitle>
          <CardDescription>Your milestones and accomplishments</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {achievements.map((achievement) => (
              <div
                key={achievement.id}
                className={`p-4 rounded-lg border-2 transition-all ${
                  achievement.unlocked ? "border-green-200 bg-green-50" : "border-gray-200 bg-gray-50 opacity-75"
                }`}
              >
                <div className="flex items-center gap-3 mb-2">
                  <div className="text-2xl">{achievement.icon}</div>
                  <div className="flex-1">
                    <div className="font-medium text-sm">{achievement.title}</div>
                    <div className="text-xs text-gray-600">{achievement.description}</div>
                  </div>
                  {achievement.unlocked && (
                    <Badge className="bg-green-500 text-white">
                      <Star className="h-3 w-3 mr-1" />
                      Unlocked
                    </Badge>
                  )}
                </div>
                {achievement.unlocked ? (
                  <div className="text-xs text-green-600">Unlocked on {achievement.date}</div>
                ) : (
                  <div className="space-y-1">
                    <div className="text-xs text-gray-500">
                      Progress: {achievement.progress || 0}/{achievement.title === "Knowledge Seeker" ? 50 : 1}
                    </div>
                    <Progress
                      value={achievement.title === "Knowledge Seeker" ? (achievement.progress || 0) * 2 : 0}
                      className="h-1"
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-blue-500" />
            Recent Activity
          </CardTitle>
          <CardDescription>Your latest learning activities</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <div className="text-xl">{getActivityIcon(activity.type)}</div>
                <div className="flex-1">
                  <div className="font-medium text-sm">{activity.title}</div>
                  {activity.score && <div className="text-xs text-green-600">Score: {activity.score}%</div>}
                </div>
                <div className="text-xs text-gray-500">{activity.time}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
