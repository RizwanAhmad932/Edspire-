"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Check, Crown, Zap, Star, Clock, AlertCircle } from "lucide-react"
import { PaymentModal } from "@/components/payment/payment-modal"

interface User {
  id: string
  name: string
  email: string
  plan: "free" | "premium" | "pro"
  xp: number
  avatar?: string
  role: "student" | "admin"
  joinDate: string
  lastActive: string
}

interface SubscriptionProps {
  user: User
}

export function Subscription({ user }: SubscriptionProps) {
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState<"premium" | "pro">("premium")

  const handleUpgrade = (plan: "premium" | "pro") => {
    setSelectedPlan(plan)
    setShowPaymentModal(true)
  }

  const handlePaymentSuccess = (plan: string) => {
    // Store pending payment in localStorage for admin approval
    const pendingPayments = JSON.parse(localStorage.getItem("pendingPayments") || "[]")
    const newPayment = {
      id: Date.now().toString(),
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      plan: plan,
      amount: plan === "premium" ? 90 : 480,
      date: new Date().toISOString(),
      status: "pending",
      paymentMethod: "UPI",
      transactionId: `TXN${Date.now()}`,
    }

    pendingPayments.push(newPayment)
    localStorage.setItem("pendingPayments", JSON.stringify(pendingPayments))

    // Show success message
    alert("Payment submitted successfully! Your subscription will be activated within 24 hours after admin approval.")
    setShowPaymentModal(false)
  }

  const plans = [
    {
      name: "Free",
      price: "₹0",
      period: "forever",
      description: "Perfect for getting started",
      features: [
        "3 AI questions per day",
        "Basic course access",
        "Limited test attempts",
        "Community support",
        "Basic progress tracking",
      ],
      current: user.plan === "free",
      popular: false,
      color: "border-gray-200",
      buttonText: "Current Plan",
      buttonDisabled: true,
    },
    {
      name: "Premium",
      price: "₹90",
      period: "per month",
      description: "Best for regular learners",
      features: [
        "15 AI questions per day",
        "All course access",
        "Unlimited test attempts",
        "Live class access",
        "Priority support",
        "Advanced analytics",
        "Download certificates",
      ],
      current: user.plan === "premium",
      popular: true,
      color: "border-blue-500",
      buttonText: user.plan === "premium" ? "Current Plan" : "Upgrade to Premium",
      buttonDisabled: user.plan === "premium",
    },
    {
      name: "Pro",
      price: "₹480",
      period: "per 6 months",
      description: "For serious students",
      features: [
        "Unlimited AI questions",
        "All Premium features",
        "1-on-1 doubt sessions",
        "Personalized study plans",
        "Advanced test analytics",
        "Priority live class seats",
        "Exclusive study materials",
        "Career guidance sessions",
      ],
      current: user.plan === "pro",
      popular: false,
      color: "border-purple-500",
      buttonText: user.plan === "pro" ? "Current Plan" : "Upgrade to Pro",
      buttonDisabled: user.plan === "pro",
    },
  ]

  const getPlanIcon = (planName: string) => {
    switch (planName) {
      case "Premium":
        return <Crown className="h-6 w-6 text-blue-500" />
      case "Pro":
        return <Zap className="h-6 w-6 text-purple-500" />
      default:
        return <Star className="h-6 w-6 text-gray-500" />
    }
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-2">Choose Your Plan</h1>
        <p className="text-gray-600 mb-4">Unlock your learning potential with our premium features</p>
        <div className="inline-flex items-center space-x-2 bg-orange-100 text-orange-800 px-4 py-2 rounded-full text-sm">
          <Clock className="h-4 w-4" />
          <span>Access granted within 24 hours after payment verification</span>
        </div>
      </div>

      {/* Current Plan Status */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold mb-1">
                Current Plan: {user.plan.charAt(0).toUpperCase() + user.plan.slice(1)}
              </h3>
              <p className="text-gray-600">
                {user.plan === "free" && "You're on the free plan. Upgrade to unlock more features!"}
                {user.plan === "premium" &&
                  "You have access to all premium features. Consider Pro for unlimited access!"}
                {user.plan === "pro" && "You have unlimited access to all features. Enjoy learning!"}
              </p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-blue-600">{user.xp}</div>
              <div className="text-sm text-gray-600">Total XP</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Plans Grid */}
      <div className="grid md:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <Card
            key={plan.name}
            className={`relative ${plan.color} ${plan.popular ? "ring-2 ring-blue-500" : ""} ${plan.current ? "bg-gray-50" : ""}`}
          >
            {plan.popular && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <Badge className="bg-blue-500 text-white">Most Popular</Badge>
              </div>
            )}

            <CardHeader className="text-center pb-4">
              <div className="flex items-center justify-center mb-2">{getPlanIcon(plan.name)}</div>
              <CardTitle className="text-xl">{plan.name}</CardTitle>
              <div className="text-3xl font-bold">
                {plan.price}
                <span className="text-sm font-normal text-gray-600">/{plan.period}</span>
              </div>
              <CardDescription>{plan.description}</CardDescription>
            </CardHeader>

            <CardContent className="space-y-4">
              <ul className="space-y-2">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <Check className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button
                className="w-full"
                variant={plan.current ? "outline" : "default"}
                disabled={plan.buttonDisabled}
                onClick={() => {
                  if (plan.name === "Premium") {
                    handleUpgrade("premium")
                  } else if (plan.name === "Pro") {
                    handleUpgrade("pro")
                  }
                }}
              >
                {plan.buttonText}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Payment Process Info */}
      <Card className="bg-yellow-50 border-yellow-200">
        <CardContent className="p-6">
          <div className="flex items-start space-x-3">
            <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5" />
            <div>
              <h3 className="font-semibold text-yellow-800 mb-2">Payment Process</h3>
              <div className="text-sm text-yellow-700 space-y-1">
                <p>1. Select your desired plan and complete the payment</p>
                <p>2. Upload payment screenshot for verification</p>
                <p>3. Admin will review and approve within 24 hours</p>
                <p>4. You'll receive confirmation and plan activation</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Features Comparison */}
      <Card>
        <CardHeader>
          <CardTitle>Feature Comparison</CardTitle>
          <CardDescription>See what's included in each plan</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2">Feature</th>
                  <th className="text-center py-2">Free</th>
                  <th className="text-center py-2">Premium</th>
                  <th className="text-center py-2">Pro</th>
                </tr>
              </thead>
              <tbody className="space-y-2">
                <tr className="border-b">
                  <td className="py-2">AI Questions per day</td>
                  <td className="text-center">3</td>
                  <td className="text-center">15</td>
                  <td className="text-center">Unlimited</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2">Course Access</td>
                  <td className="text-center">Basic</td>
                  <td className="text-center">All</td>
                  <td className="text-center">All + Exclusive</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2">Live Classes</td>
                  <td className="text-center">❌</td>
                  <td className="text-center">✅</td>
                  <td className="text-center">✅ Priority</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2">1-on-1 Sessions</td>
                  <td className="text-center">❌</td>
                  <td className="text-center">❌</td>
                  <td className="text-center">✅</td>
                </tr>
                <tr className="border-b">
                  <td className="py-2">Support</td>
                  <td className="text-center">Community</td>
                  <td className="text-center">Priority</td>
                  <td className="text-center">Dedicated</td>
                </tr>
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Payment Modal */}
      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        plan={selectedPlan}
        onSuccess={handlePaymentSuccess}
      />
    </div>
  )
}
