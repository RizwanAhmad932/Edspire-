"use client"
import { useState } from "react"
import { useAuth } from "@/app/providers"
import { DashboardHome } from "./dashboard-home"
import { Tests } from "./tests"
import { Courses } from "./courses"
import { AskAI } from "./ask-ai"
import { LiveClasses } from "./live-classes"
import { Leaderboard } from "./leaderboard"
import { Profile } from "./profile"
import { PYQ } from "./pyq"
import { Subscription } from "./subscription"
import { SubjectiveTests } from "./subjective-tests"
import { Sidebar } from "./sidebar"
import { Header } from "./header"
import { BottomNavigation } from "./bottom-navigation"
import { FocusMode } from "./focus-mode"
import { LoadingScreen } from "@/components/common/loading-screen"

export function Dashboard() {
  const { user, isLoading } = useAuth()
  const [activeTab, setActiveTab] = useState("home")
  const [isFocusMode, setIsFocusMode] = useState(false)

  if (isLoading) {
    return <LoadingScreen />
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Authentication Required</h2>
          <p className="text-gray-600">Please log in to access the dashboard.</p>
        </div>
      </div>
    )
  }

  if (isFocusMode) {
    return <FocusMode onExit={() => setIsFocusMode(false)} />
  }

  const renderContent = () => {
    switch (activeTab) {
      case "home":
        return <DashboardHome user={user} onNavigate={setActiveTab} onFocusMode={() => setIsFocusMode(true)} />
      case "tests":
        return <Tests user={user} />
      case "subjective-tests":
        return <SubjectiveTests user={user} />
      case "courses":
        return <Courses user={user} />
      case "ask-ai":
        return <AskAI user={user} />
      case "live-classes":
        return <LiveClasses user={user} />
      case "leaderboard":
        return <Leaderboard user={user} />
      case "profile":
        return <Profile user={user} />
      case "pyq":
        return <PYQ user={user} />
      case "subscription":
        return <Subscription user={user} />
      default:
        return <DashboardHome user={user} onNavigate={setActiveTab} onFocusMode={() => setIsFocusMode(true)} />
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="flex">
        {/* Desktop Sidebar */}
        <div className="hidden lg:block">
          <Sidebar activeTab={activeTab} onTabChange={setActiveTab} user={user} />
        </div>

        {/* Main Content */}
        <div className="flex-1 lg:ml-64">
          <Header user={user} />
          <main className="p-4 pb-20 lg:pb-4">{renderContent()}</main>
        </div>
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="lg:hidden">
        <BottomNavigation activeTab={activeTab} onTabChange={setActiveTab} />
      </div>
    </div>
  )
}
