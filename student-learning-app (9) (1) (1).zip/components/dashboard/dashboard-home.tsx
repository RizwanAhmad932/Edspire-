"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import {
  BookOpen,
  Brain,
  Trophy,
  Clock,
  Target,
  Zap,
  TrendingUp,
  Calendar,
  Award,
  PlayCircle,
  FileText,
  MessageSquare,
  Focus,
} from "lucide-react"

interface User {
  id: string
  name: string
  email: string
  plan: "free" | "premium" | "pro"
  xp: number
  avatar?: string
  role: "student" | "admin"
  joinDate: string
  lastActive: string
}

interface DashboardHomeProps {
  user: User
  onNavigate: (tab: string) => void
  onFocusMode: () => void
}

export function DashboardHome({ user, onNavigate, onFocusMode }: DashboardHomeProps) {
  const currentLevel = Math.floor(user.xp / 100) + 1
  const xpForNextLevel = currentLevel * 100 - user.xp
  const progressToNextLevel = ((user.xp % 100) / 100) * 100

  // Mock data for demonstration
  const todayStats = {
    testsCompleted: 3,
    questionsAnswered: 45,
    studyTime: 120, // minutes
    accuracy: 78,
  }

  const upcomingClasses = [
    { id: 1, subject: "Physics", topic: "Quantum Mechanics", time: "2:00 PM", instructor: "Dr. Smith" },
    { id: 2, subject: "Mathematics", topic: "Calculus Integration", time: "4:00 PM", instructor: "Prof. Johnson" },
    { id: 3, subject: "Chemistry", topic: "Organic Reactions", time: "6:00 PM", instructor: "Dr. Brown" },
  ]

  const recentAchievements = [
    { id: 1, title: "Speed Demon", description: "Completed 10 tests in under 5 minutes each", icon: "⚡" },
    { id: 2, title: "Physics Master", description: "Scored 90%+ in 5 consecutive physics tests", icon: "🔬" },
    { id: 3, title: "Streak Champion", description: "Maintained 7-day study streak", icon: "🔥" },
  ]

  const quickActions = [
    {
      title: "Take Practice Test",
      description: "Start a custom test",
      icon: FileText,
      action: () => onNavigate("tests"),
      color: "bg-blue-500",
    },
    {
      title: "Ask AI Tutor",
      description: "Get instant help",
      icon: Brain,
      action: () => onNavigate("ask-ai"),
      color: "bg-purple-500",
    },
    {
      title: "Join Live Class",
      description: "Interactive learning",
      icon: PlayCircle,
      action: () => onNavigate("live-classes"),
      color: "bg-green-500",
    },
    {
      title: "Focus Mode",
      description: "Distraction-free study",
      icon: Focus,
      action: onFocusMode,
      color: "bg-orange-500",
    },
    {
      title: "Browse Courses",
      description: "Explore content",
      icon: BookOpen,
      action: () => onNavigate("courses"),
      color: "bg-indigo-500",
    },
    {
      title: "View Leaderboard",
      description: "Check your rank",
      icon: Trophy,
      action: () => onNavigate("leaderboard"),
      color: "bg-yellow-500",
    },
  ]

  return (
    <div className="space-y-6">
      {/* Welcome Section with Class Display */}
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-blue-800 rounded-2xl p-6 text-white">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div className="mb-4 md:mb-0">
            <h1 className="text-2xl md:text-3xl font-bold mb-2">Welcome back, {user.name}! 👋</h1>
            <div className="flex flex-wrap items-center gap-4 text-blue-100">
              <div className="flex items-center gap-2">
                <Target className="h-4 w-4" />
                <span className="font-medium">Class 12 • JEE Main 2025</span>
              </div>
              <div className="flex items-center gap-2">
                <Award className="h-4 w-4" />
                <span>Level {currentLevel}</span>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="h-4 w-4" />
                <span>{user.xp} XP</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-blue-200 mb-1">Progress to Level {currentLevel + 1}</div>
            <div className="w-32 bg-blue-700 rounded-full h-2 mb-2">
              <div
                className="bg-white rounded-full h-2 transition-all duration-300"
                style={{ width: `${progressToNextLevel}%` }}
              ></div>
            </div>
            <div className="text-xs text-blue-200">{xpForNextLevel} XP to go</div>
          </div>
        </div>
      </div>

      {/* Quick Actions Grid */}
      <div>
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <Zap className="h-5 w-5 text-yellow-500" />
          Quick Actions
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {quickActions.map((action, index) => (
            <Card
              key={index}
              className="cursor-pointer hover:shadow-lg transition-all duration-200 hover:scale-105 border-0 bg-gradient-to-br from-white to-gray-50"
              onClick={action.action}
            >
              <CardContent className="p-4 text-center">
                <div className={`${action.color} w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3`}>
                  <action.icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="font-medium text-sm mb-1">{action.title}</h3>
                <p className="text-xs text-gray-600">{action.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Today's Stats */}
      <div>
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-green-500" />
          Today's Progress
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardContent className="p-4 text-center">
              <FileText className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-blue-700">{todayStats.testsCompleted}</div>
              <div className="text-sm text-blue-600">Tests Completed</div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardContent className="p-4 text-center">
              <MessageSquare className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-green-700">{todayStats.questionsAnswered}</div>
              <div className="text-sm text-green-600">Questions Solved</div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <CardContent className="p-4 text-center">
              <Clock className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-purple-700">{todayStats.studyTime}m</div>
              <div className="text-sm text-purple-600">Study Time</div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
            <CardContent className="p-4 text-center">
              <Target className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-orange-700">{todayStats.accuracy}%</div>
              <div className="text-sm text-orange-600">Accuracy</div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Upcoming Live Classes */}
        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-700">
              <Calendar className="h-5 w-5" />
              Upcoming Live Classes
            </CardTitle>
            <CardDescription>Join interactive sessions with expert instructors</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {upcomingClasses.map((class_) => (
                <div key={class_.id} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                  <div>
                    <div className="font-medium text-sm">{class_.subject}</div>
                    <div className="text-xs text-gray-600">{class_.topic}</div>
                    <div className="text-xs text-gray-500">by {class_.instructor}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium text-green-600">{class_.time}</div>
                    <Badge variant="outline" className="text-xs">
                      Live
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
            <Button className="w-full mt-4 bg-green-600 hover:bg-green-700" onClick={() => onNavigate("live-classes")}>
              <PlayCircle className="mr-2 h-4 w-4" />
              View All Classes
            </Button>
          </CardContent>
        </Card>

        {/* Recent Achievements */}
        <Card className="bg-gradient-to-br from-yellow-50 to-amber-50 border-yellow-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-yellow-700">
              <Award className="h-5 w-5" />
              Recent Achievements
            </CardTitle>
            <CardDescription>Your latest milestones and accomplishments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentAchievements.map((achievement) => (
                <div key={achievement.id} className="flex items-center gap-3 p-3 bg-white rounded-lg border">
                  <div className="text-2xl">{achievement.icon}</div>
                  <div>
                    <div className="font-medium text-sm">{achievement.title}</div>
                    <div className="text-xs text-gray-600">{achievement.description}</div>
                  </div>
                </div>
              ))}
            </div>
            <Button
              variant="outline"
              className="w-full mt-4 border-yellow-300 text-yellow-700 hover:bg-yellow-100 bg-transparent"
              onClick={() => onNavigate("profile")}
            >
              <Trophy className="mr-2 h-4 w-4" />
              View All Achievements
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Study Streak */}
      <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-orange-700 mb-2">🔥 Study Streak</h3>
              <p className="text-orange-600">Keep up the momentum! You're on a 7-day streak.</p>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold text-orange-600">7</div>
              <div className="text-sm text-orange-500">days</div>
            </div>
          </div>
          <div className="mt-4">
            <div className="flex justify-between text-xs text-orange-600 mb-1">
              <span>This week</span>
              <span>7/7 days</span>
            </div>
            <Progress value={100} className="h-2 bg-orange-200" />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
