"use client"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Bell, Search, Menu, Settings, LogOut, Crown, Zap } from "lucide-react"
import { useAuth } from "@/app/providers"

interface HeaderProps {
  user: {
    id: string
    name: string
    email: string
    plan: "free" | "premium" | "pro"
    xp: number
    avatar?: string
    role: "student" | "admin"
    joinDate: string
    lastActive: string
  }
}

export function Header({ user }: HeaderProps) {
  const { logout } = useAuth()
  const [notifications] = useState([
    {
      id: 1,
      title: "New test available",
      message: "Physics Mock Test 15 is now live",
      time: "2 min ago",
      unread: true,
    },
    {
      id: 2,
      title: "Live class starting",
      message: "Organic Chemistry class in 10 minutes",
      time: "8 min ago",
      unread: true,
    },
    {
      id: 3,
      title: "Achievement unlocked",
      message: "You've completed 50 practice tests!",
      time: "1 hour ago",
      unread: false,
    },
  ])

  const unreadCount = notifications.filter((n) => n.unread).length
  const currentLevel = Math.floor(user.xp / 100) + 1

  const getPlanIcon = (plan: string) => {
    switch (plan) {
      case "pro":
        return <Crown className="h-4 w-4 text-purple-600" />
      case "premium":
        return <Zap className="h-4 w-4 text-blue-600" />
      default:
        return null
    }
  }

  const getPlanColor = (plan: string) => {
    switch (plan) {
      case "free":
        return "bg-gray-100 text-gray-700"
      case "premium":
        return "bg-blue-100 text-blue-700"
      case "pro":
        return "bg-purple-100 text-purple-700"
      default:
        return "bg-gray-100 text-gray-700"
    }
  }

  return (
    <header className="bg-white border-b border-gray-200 px-4 py-3">
      <div className="flex items-center justify-between">
        {/* Left side - Mobile menu and search */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" className="lg:hidden">
            <Menu className="h-5 w-5" />
          </Button>

          {/* Search - Hidden on mobile */}
          <div className="hidden md:flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-2 min-w-[300px]">
            <Search className="h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search courses, tests, topics..."
              className="bg-transparent border-none outline-none text-sm flex-1"
            />
          </div>
        </div>

        {/* Right side - Notifications and user menu */}
        <div className="flex items-center gap-3">
          {/* Search button for mobile */}
          <Button variant="ghost" size="sm" className="md:hidden">
            <Search className="h-5 w-5" />
          </Button>

          {/* Notifications */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="h-5 w-5" />
                {unreadCount > 0 && (
                  <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center bg-red-500 text-white text-xs">
                    {unreadCount}
                  </Badge>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80">
              <DropdownMenuLabel className="flex items-center justify-between">
                Notifications
                <Badge variant="secondary" className="text-xs">
                  {unreadCount} new
                </Badge>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <div className="max-h-64 overflow-y-auto">
                {notifications.map((notification) => (
                  <DropdownMenuItem key={notification.id} className="flex-col items-start p-3">
                    <div className="flex items-center justify-between w-full">
                      <div className="font-medium text-sm">{notification.title}</div>
                      {notification.unread && <div className="w-2 h-2 bg-blue-600 rounded-full"></div>}
                    </div>
                    <div className="text-xs text-gray-600 mt-1">{notification.message}</div>
                    <div className="text-xs text-gray-400 mt-1">{notification.time}</div>
                  </DropdownMenuItem>
                ))}
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* User Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center gap-2 px-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                  <AvatarFallback className="bg-blue-600 text-white text-sm">
                    {user.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="hidden md:block text-left">
                  <div className="text-sm font-medium">{user.name}</div>
                  <div className="flex items-center gap-1">
                    <Badge className={`text-xs ${getPlanColor(user.plan)}`}>
                      {getPlanIcon(user.plan)}
                      <span className="ml-1">{user.plan.toUpperCase()}</span>
                    </Badge>
                  </div>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium">{user.name}</p>
                  <p className="text-xs text-gray-600">{user.email}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge className={`text-xs ${getPlanColor(user.plan)}`}>
                      {getPlanIcon(user.plan)}
                      <span className="ml-1">{user.plan.toUpperCase()}</span>
                    </Badge>
                    <div className="text-xs text-gray-600">Level {currentLevel}</div>
                  </div>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <span className="mr-2 h-4 w-4">User</span>
                <span>Profile</span>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Settings className="mr-2 h-4 w-4" />
                <span>Settings</span>
              </DropdownMenuItem>
              {user.plan === "free" && (
                <DropdownMenuItem className="text-blue-600">
                  <Crown className="mr-2 h-4 w-4" />
                  <span>Upgrade Plan</span>
                </DropdownMenuItem>
              )}
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={logout} className="text-red-600">
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}
