"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { generateQuestionsWithGemini } from "@/lib/utils"
import { BookMarked, Calendar, Search, Play, Zap, CheckCircle } from "lucide-react"

interface PYQQuestion {
  id: string
  question: string
  options: string[]
  correctAnswer: number
  explanation: string
  year: string
  exam: string
  subject: string
  difficulty: string
}

export function PYQ() {
  const [pyqQuestions, setPyqQuestions] = useState<PYQQuestion[]>([])
  const [filteredQuestions, setFilteredQuestions] = useState<PYQQuestion[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [subjectFilter, setSubjectFilter] = useState("all")
  const [yearFilter, setYearFilter] = useState("all")
  const [examFilter, setExamFilter] = useState("all")
  const [isGenerating, setIsGenerating] = useState(false)
  const [selectedQuestion, setSelectedQuestion] = useState<PYQQuestion | null>(null)
  const [userAnswer, setUserAnswer] = useState<number | null>(null)
  const [showExplanation, setShowExplanation] = useState(false)

  // Sample PYQ data
  const samplePYQs: PYQQuestion[] = [
    {
      id: "pyq_1",
      question: "A particle moves in a circle of radius R. What is the displacement after completing half circle?",
      options: ["πR", "2R", "R", "0"],
      correctAnswer: 1,
      explanation:
        "Displacement is the shortest distance between initial and final positions, which is 2R for half circle.",
      year: "2023",
      exam: "JEE Main",
      subject: "Physics",
      difficulty: "Medium",
    },
    {
      id: "pyq_2",
      question: "Which of the following has maximum bond angle?",
      options: ["NH₃", "H₂O", "CH₄", "H₂S"],
      correctAnswer: 2,
      explanation: "CH₄ has tetrahedral geometry with bond angle 109.5°, which is maximum among given options.",
      year: "2023",
      exam: "NEET",
      subject: "Chemistry",
      difficulty: "Medium",
    },
    {
      id: "pyq_3",
      question: "If f(x) = x³ - 3x + 2, then f'(1) equals:",
      options: ["0", "1", "2", "3"],
      correctAnswer: 0,
      explanation: "f'(x) = 3x² - 3, so f'(1) = 3(1)² - 3 = 3 - 3 = 0.",
      year: "2023",
      exam: "JEE Main",
      subject: "Mathematics",
      difficulty: "Easy",
    },
    {
      id: "pyq_4",
      question: "Which enzyme is responsible for unwinding DNA during replication?",
      options: ["DNA polymerase", "Helicase", "Ligase", "Primase"],
      correctAnswer: 1,
      explanation: "Helicase unwinds the DNA double helix by breaking hydrogen bonds between base pairs.",
      year: "2023",
      exam: "NEET",
      subject: "Biology",
      difficulty: "Medium",
    },
  ]

  useEffect(() => {
    setPyqQuestions(samplePYQs)
    setFilteredQuestions(samplePYQs)
  }, [])

  useEffect(() => {
    let filtered = pyqQuestions

    if (searchTerm) {
      filtered = filtered.filter(
        (q) =>
          q.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
          q.subject.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (subjectFilter !== "all") {
      filtered = filtered.filter((q) => q.subject === subjectFilter)
    }

    if (yearFilter !== "all") {
      filtered = filtered.filter((q) => q.year === yearFilter)
    }

    if (examFilter !== "all") {
      filtered = filtered.filter((q) => q.exam === examFilter)
    }

    setFilteredQuestions(filtered)
  }, [searchTerm, subjectFilter, yearFilter, examFilter, pyqQuestions])

  const generateMorePYQs = async () => {
    setIsGenerating(true)
    try {
      const subjects = ["Physics", "Chemistry", "Mathematics", "Biology"]
      const newQuestions: PYQQuestion[] = []

      for (const subject of subjects) {
        const result = await generateQuestionsWithGemini(subject, "Medium", 5)
        if (result.questions) {
          const pyqQuestions = result.questions.map((q: any, index: number) => ({
            ...q,
            id: `ai_pyq_${subject}_${Date.now()}_${index}`,
            year: "2024",
            exam: subject === "Biology" ? "NEET" : "JEE Main",
            subject,
          }))
          newQuestions.push(...pyqQuestions)
        }
      }

      setPyqQuestions((prev) => [...prev, ...newQuestions])
    } catch (error) {
      console.error("Error generating PYQs:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  const handleAnswerSelect = (answerIndex: number) => {
    setUserAnswer(answerIndex)
    setShowExplanation(true)
  }

  const resetQuestion = () => {
    setSelectedQuestion(null)
    setUserAnswer(null)
    setShowExplanation(false)
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case "easy":
        return "bg-green-100 text-green-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "hard":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getExamColor = (exam: string) => {
    switch (exam) {
      case "JEE Main":
        return "bg-blue-100 text-blue-800"
      case "JEE Advanced":
        return "bg-purple-100 text-purple-800"
      case "NEET":
        return "bg-green-100 text-green-800"
      case "BITSAT":
        return "bg-orange-100 text-orange-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  if (selectedQuestion) {
    return (
      <div className="max-w-4xl mx-auto space-y-6">
        <Card className="shadow-lg">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center space-x-2">
                  <BookMarked className="h-5 w-5" />
                  <span>Previous Year Question</span>
                </CardTitle>
                <CardDescription>
                  {selectedQuestion.exam} {selectedQuestion.year} - {selectedQuestion.subject}
                </CardDescription>
              </div>
              <Button variant="outline" onClick={resetQuestion}>
                Back to PYQs
              </Button>
            </div>
          </CardHeader>
        </Card>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">{selectedQuestion.question}</CardTitle>
            <div className="flex items-center space-x-2">
              <Badge className={getExamColor(selectedQuestion.exam)}>{selectedQuestion.exam}</Badge>
              <Badge variant="outline">{selectedQuestion.year}</Badge>
              <Badge className={getDifficultyColor(selectedQuestion.difficulty)}>{selectedQuestion.difficulty}</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {selectedQuestion.options.map((option, index) => {
                let buttonClass = "w-full text-left justify-start h-auto p-4 "

                if (showExplanation) {
                  if (index === selectedQuestion.correctAnswer) {
                    buttonClass += "bg-green-100 border-green-500 text-green-800"
                  } else if (index === userAnswer && index !== selectedQuestion.correctAnswer) {
                    buttonClass += "bg-red-100 border-red-500 text-red-800"
                  } else {
                    buttonClass += "opacity-60"
                  }
                } else if (userAnswer === index) {
                  buttonClass += "bg-blue-100 border-blue-500"
                }

                return (
                  <Button
                    key={index}
                    variant="outline"
                    className={buttonClass}
                    onClick={() => !showExplanation && handleAnswerSelect(index)}
                    disabled={showExplanation}
                  >
                    <span className="mr-3 font-bold">{String.fromCharCode(65 + index)}.</span>
                    {option}
                    {showExplanation && index === selectedQuestion.correctAnswer && (
                      <CheckCircle className="ml-auto h-5 w-5 text-green-600" />
                    )}
                  </Button>
                )
              })}
            </div>

            {showExplanation && (
              <div className="mt-6 p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
                <h4 className="font-medium text-blue-800 mb-2">Explanation:</h4>
                <p className="text-blue-700">{selectedQuestion.explanation}</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2">Previous Year Questions</h1>
          <p className="text-gray-600">Practice with authentic exam questions from past years</p>
        </div>
        <Button
          onClick={generateMorePYQs}
          disabled={isGenerating}
          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
        >
          {isGenerating ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Generating...
            </>
          ) : (
            <>
              <Zap className="mr-2 h-4 w-4" />
              Generate More PYQs
            </>
          )}
        </Button>
      </div>

      {/* Filters */}
      <Card className="shadow-lg">
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search questions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={subjectFilter} onValueChange={setSubjectFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Subjects" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Subjects</SelectItem>
                <SelectItem value="Physics">Physics</SelectItem>
                <SelectItem value="Chemistry">Chemistry</SelectItem>
                <SelectItem value="Mathematics">Mathematics</SelectItem>
                <SelectItem value="Biology">Biology</SelectItem>
              </SelectContent>
            </Select>
            <Select value={yearFilter} onValueChange={setYearFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Years" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Years</SelectItem>
                <SelectItem value="2024">2024</SelectItem>
                <SelectItem value="2023">2023</SelectItem>
                <SelectItem value="2022">2022</SelectItem>
                <SelectItem value="2021">2021</SelectItem>
                <SelectItem value="2020">2020</SelectItem>
              </SelectContent>
            </Select>
            <Select value={examFilter} onValueChange={setExamFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Exams" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Exams</SelectItem>
                <SelectItem value="JEE Main">JEE Main</SelectItem>
                <SelectItem value="JEE Advanced">JEE Advanced</SelectItem>
                <SelectItem value="NEET">NEET</SelectItem>
                <SelectItem value="BITSAT">BITSAT</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* PYQ Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredQuestions.map((question) => (
          <Card
            key={question.id}
            className="hover:shadow-lg transition-all duration-200 hover:scale-105 cursor-pointer"
            onClick={() => setSelectedQuestion(question)}
          >
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg mb-2 line-clamp-2">{question.question}</CardTitle>
                  <div className="flex items-center space-x-2 mb-2">
                    <Badge variant="outline">{question.subject}</Badge>
                    <Badge className={getExamColor(question.exam)}>{question.exam}</Badge>
                  </div>
                </div>
                <BookMarked className="h-6 w-6 text-gray-400" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    {question.year}
                  </span>
                  <Badge className={getDifficultyColor(question.difficulty)}>{question.difficulty}</Badge>
                </div>

                <Button className="w-full mt-4">
                  <Play className="mr-2 h-4 w-4" />
                  Solve Question
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredQuestions.length === 0 && (
        <Card className="text-center py-12">
          <CardContent>
            <BookMarked className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No questions found</h3>
            <p className="text-gray-600 mb-4">Try adjusting your search or filters</p>
            <Button
              onClick={() => {
                setSearchTerm("")
                setSubjectFilter("all")
                setYearFilter("all")
                setExamFilter("all")
              }}
            >
              Clear Filters
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
