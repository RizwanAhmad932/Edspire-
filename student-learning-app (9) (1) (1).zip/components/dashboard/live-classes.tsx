"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, Users, Video, Play, Pause, Volume2, VolumeX, Maximize } from "lucide-react"
import { mockData } from "@/lib/utils"

interface LiveClassesProps {
  user?: any
}

export function LiveClasses({ user }: LiveClassesProps) {
  const [joinedClass, setJoinedClass] = useState<string | null>(null)
  const [isVideoPlaying, setIsVideoPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "live":
        return "bg-red-500"
      case "upcoming":
        return "bg-green-500"
      case "scheduled":
        return "bg-blue-500"
      default:
        return "bg-gray-500"
    }
  }

  const handleJoinClass = (classId: string) => {
    if (user?.plan === "free") {
      alert("Live classes are available for Premium and Pro subscribers only. Please upgrade your plan.")
      return
    }
    setJoinedClass(classId)
    setIsVideoPlaying(true)
  }

  const handleLeaveClass = () => {
    setJoinedClass(null)
    setIsVideoPlaying(false)
  }

  if (joinedClass) {
    const currentClass = mockData.liveClasses.find((c) => c.id === joinedClass)

    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">{currentClass?.title}</h1>
            <p className="text-gray-600">by {currentClass?.instructor}</p>
          </div>
          <Button onClick={handleLeaveClass} variant="outline">
            Leave Class
          </Button>
        </div>

        {/* Video Player */}
        <Card>
          <CardContent className="p-0">
            <div className="video-player bg-black rounded-lg">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-white text-center">
                  <Video className="h-16 w-16 mx-auto mb-4 opacity-50" />
                  <p className="text-lg">Live Class in Progress</p>
                  <p className="text-sm opacity-75">Meeting ID: {currentClass?.meetingId}</p>
                </div>
              </div>

              {/* Video Controls */}
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Button size="sm" variant="secondary" onClick={() => setIsVideoPlaying(!isVideoPlaying)}>
                    {isVideoPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  </Button>
                  <Button size="sm" variant="secondary" onClick={() => setIsMuted(!isMuted)}>
                    {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                  </Button>
                </div>

                <div className="flex items-center space-x-2">
                  <Badge className="bg-red-500">LIVE</Badge>
                  <span className="text-white text-sm">{currentClass?.students} viewers</span>
                </div>

                <Button size="sm" variant="secondary">
                  <Maximize className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Chat and Notes */}
        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Class Notes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <p className="font-medium">Key Point 1:</p>
                    <p className="text-sm text-gray-600">Wave motion fundamentals and basic equations</p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <p className="font-medium">Key Point 2:</p>
                    <p className="text-sm text-gray-600">Types of waves and their properties</p>
                  </div>
                  <div className="p-3 bg-yellow-50 rounded-lg">
                    <p className="font-medium">Assignment:</p>
                    <p className="text-sm text-gray-600">Complete practice problems 1-10 from chapter 15</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card>
              <CardHeader>
                <CardTitle>Live Chat</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 h-64 overflow-y-auto">
                  <div className="text-sm">
                    <span className="font-medium text-blue-600">Student1:</span>
                    <span className="ml-2">Great explanation!</span>
                  </div>
                  <div className="text-sm">
                    <span className="font-medium text-green-600">Student2:</span>
                    <span className="ml-2">Can you repeat the formula?</span>
                  </div>
                  <div className="text-sm">
                    <span className="font-medium text-purple-600">Instructor:</span>
                    <span className="ml-2">v = fλ</span>
                  </div>
                </div>
                <div className="mt-4 flex space-x-2">
                  <input
                    type="text"
                    placeholder="Type your message..."
                    className="flex-1 px-3 py-2 border rounded-md text-sm"
                  />
                  <Button size="sm">Send</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-2">Live Classes</h1>
        <p className="text-gray-600">Join live interactive sessions with expert instructors</p>
      </div>

      <div className="grid gap-4">
        {mockData.liveClasses.map((class_) => (
          <Card key={class_.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <Badge variant="secondary">{class_.subject}</Badge>
                    <Badge className={getStatusColor(class_.status)}>{class_.status.toUpperCase()}</Badge>
                  </div>

                  <h3 className="text-lg font-semibold mb-1">{class_.title}</h3>
                  <p className="text-gray-600 mb-3">by {class_.instructor}</p>

                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-4 w-4" />
                      <span>{class_.date}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4" />
                      <span>{class_.time}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Users className="h-4 w-4" />
                      <span>{class_.students.toLocaleString()} students</span>
                    </div>
                  </div>
                </div>

                <div className="ml-4">
                  <Button
                    className={class_.status === "live" ? "bg-red-500 hover:bg-red-600" : ""}
                    onClick={() => (class_.status === "live" ? handleJoinClass(class_.id) : undefined)}
                    disabled={user?.plan === "free" && class_.status === "live"}
                  >
                    <Video className="mr-2 h-4 w-4" />
                    {class_.status === "live"
                      ? user?.plan === "free"
                        ? "Premium Required"
                        : "Join Now"
                      : "Set Reminder"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Schedule Section */}
      <Card>
        <CardHeader>
          <CardTitle>This Week's Schedule</CardTitle>
          <CardDescription>Upcoming live classes for the week</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-7 gap-2">
            {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day, index) => (
              <div key={day} className="text-center p-3 border rounded-lg">
                <div className="font-medium text-sm">{day}</div>
                <div className="text-xs text-gray-500 mt-1">
                  {index < 3 ? "2 classes" : index < 5 ? "1 class" : "No classes"}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
