"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Send, Bot, Sparkles, BookOpen, Calculator, Atom, Dna } from "lucide-react"

interface User {
  id: string
  name: string
  email: string
  plan: "free" | "premium" | "pro"
  xp: number
  avatar?: string
  role: "student" | "admin"
  joinDate: string
  lastActive: string
  class?: string
  examTarget?: string
}

interface Message {
  id: string
  type: "user" | "ai"
  content: string
  timestamp: Date
  subject?: string
}

interface AskAIProps {
  user?: User | null
}

export default function AskAI({ user }: AskAIProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      type: "ai",
      content:
        "Hello! I'm your AI tutor. I can help you with Physics, Chemistry, Mathematics, and Biology questions. What would you like to learn today?",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  if (!user) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Bot className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">Loading AI Assistant...</p>
        </div>
      </div>
    )
  }

  const handleSendMessage = async () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    // Simulate AI response
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        type: "ai",
        content: generateAIResponse(input),
        timestamp: new Date(),
        subject: detectSubject(input),
      }
      setMessages((prev) => [...prev, aiResponse])
      setIsLoading(false)
    }, 1500)
  }

  const generateAIResponse = (question: string): string => {
    const lowerQuestion = question.toLowerCase()

    if (lowerQuestion.includes("physics") || lowerQuestion.includes("force") || lowerQuestion.includes("motion")) {
      return "Great physics question! Let me help you understand this concept. In physics, we often deal with fundamental forces and motion. Would you like me to explain the specific concept you're asking about with examples and formulas?"
    }

    if (
      lowerQuestion.includes("chemistry") ||
      lowerQuestion.includes("reaction") ||
      lowerQuestion.includes("molecule")
    ) {
      return "Excellent chemistry question! Chemistry is all about understanding how atoms and molecules interact. I can help you with reaction mechanisms, molecular structures, and chemical equations. What specific area would you like to explore?"
    }

    if (lowerQuestion.includes("math") || lowerQuestion.includes("equation") || lowerQuestion.includes("solve")) {
      return "Perfect math question! Mathematics is the foundation of all sciences. I can help you with algebra, calculus, geometry, and more. Let me break down the problem step by step for you."
    }

    if (lowerQuestion.includes("biology") || lowerQuestion.includes("cell") || lowerQuestion.includes("organism")) {
      return "Fascinating biology question! Biology helps us understand life itself. I can explain cellular processes, genetics, ecology, and human physiology. What biological concept interests you most?"
    }

    return "That's an interesting question! I'm here to help you with any academic topic. Could you provide more details so I can give you a more specific and helpful explanation?"
  }

  const detectSubject = (question: string): string => {
    const lowerQuestion = question.toLowerCase()
    if (lowerQuestion.includes("physics") || lowerQuestion.includes("force") || lowerQuestion.includes("motion"))
      return "Physics"
    if (lowerQuestion.includes("chemistry") || lowerQuestion.includes("reaction") || lowerQuestion.includes("molecule"))
      return "Chemistry"
    if (lowerQuestion.includes("math") || lowerQuestion.includes("equation") || lowerQuestion.includes("solve"))
      return "Mathematics"
    if (lowerQuestion.includes("biology") || lowerQuestion.includes("cell") || lowerQuestion.includes("organism"))
      return "Biology"
    return "General"
  }

  const getSubjectIcon = (subject: string) => {
    switch (subject) {
      case "Physics":
        return <Calculator className="h-4 w-4" />
      case "Chemistry":
        return <Atom className="h-4 w-4" />
      case "Mathematics":
        return <Calculator className="h-4 w-4" />
      case "Biology":
        return <Dna className="h-4 w-4" />
      default:
        return <BookOpen className="h-4 w-4" />
    }
  }

  const quickQuestions = [
    { text: "Explain Newton's laws of motion", subject: "Physics" },
    { text: "How do chemical bonds form?", subject: "Chemistry" },
    { text: "Solve quadratic equations", subject: "Mathematics" },
    { text: "What is photosynthesis?", subject: "Biology" },
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            AI Tutor
          </h1>
          <p className="text-muted-foreground">Get instant help with your studies</p>
        </div>
        <div className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-yellow-500" />
          <Badge variant="secondary" className="bg-gradient-to-r from-blue-500/10 to-purple-500/10">
            {user.plan === "free" ? "5 questions left today" : "Unlimited questions"}
          </Badge>
        </div>
      </div>

      {/* Quick Questions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Quick Questions</CardTitle>
          <CardDescription>Get started with these common topics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {quickQuestions.map((question, index) => (
              <Button
                key={index}
                variant="outline"
                className="justify-start h-auto p-3 text-left bg-transparent"
                onClick={() => setInput(question.text)}
              >
                <div className="flex items-center gap-2">
                  {getSubjectIcon(question.subject)}
                  <span className="text-sm">{question.text}</span>
                </div>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Chat Interface */}
      <Card className="flex-1">
        <CardContent className="p-0">
          {/* Messages */}
          <div className="h-96 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.type === "user" ? "justify-end" : "justify-start"}`}
              >
                {message.type === "ai" && (
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
                      <Bot className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                )}

                <div className={`max-w-[80%] ${message.type === "user" ? "order-first" : ""}`}>
                  <div
                    className={`rounded-lg p-3 ${
                      message.type === "user"
                        ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white ml-auto"
                        : "bg-muted"
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <p className="text-xs text-muted-foreground">{message.timestamp.toLocaleTimeString()}</p>
                    {message.subject && (
                      <Badge variant="outline" className="text-xs">
                        {getSubjectIcon(message.subject)}
                        <span className="ml-1">{message.subject}</span>
                      </Badge>
                    )}
                  </div>
                </div>

                {message.type === "user" && (
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user.avatar || "/placeholder.svg"} />
                    <AvatarFallback>{/* User Icon Placeholder */}</AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}

            {isLoading && (
              <div className="flex gap-3">
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
                    <Bot className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="bg-muted rounded-lg p-3">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div
                      className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                      style={{ animationDelay: "0.1s" }}
                    ></div>
                    <div
                      className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                      style={{ animationDelay: "0.2s" }}
                    ></div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <div className="border-t p-4">
            <div className="flex gap-2">
              <Textarea
                placeholder="Ask me anything about Physics, Chemistry, Mathematics, or Biology..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault()
                    handleSendMessage()
                  }
                }}
                className="min-h-[60px] resize-none"
              />
              <Button
                onClick={handleSendMessage}
                disabled={!input.trim() || isLoading}
                className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>

            {user.plan === "free" && (
              <p className="text-xs text-muted-foreground mt-2">
                Free plan: 5 questions per day. Upgrade for unlimited access!
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
