"use client"
import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { BookOpen, Clock, Users, Star, Search, Play, CheckCircle, Lock } from "lucide-react"

interface User {
  id: string
  name: string
  email: string
  plan: "free" | "premium" | "pro"
  xp: number
  avatar?: string
  role: "student" | "admin"
  joinDate: string
  lastActive: string
}

interface Course {
  id: string
  title: string
  description: string
  subject: string
  level: "beginner" | "intermediate" | "advanced"
  duration: number // in hours
  lessons: number
  enrolled: number
  rating: number
  price: number
  isPremium: boolean
  isEnrolled: boolean
  progress: number
  instructor: string
  thumbnail: string
  tags: string[]
}

interface CoursesProps {
  user: User
}

export function Courses({ user }: CoursesProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedSubject, setSelectedSubject] = useState("all")
  const [selectedLevel, setSelectedLevel] = useState("all")
  const [selectedTab, setSelectedTab] = useState("all") // all, enrolled, recommended

  const courses: Course[] = [
    {
      id: "1",
      title: "Advanced Physics - Mechanics",
      description: "Master the fundamentals of classical mechanics with detailed explanations and practice problems.",
      subject: "Physics",
      level: "advanced",
      duration: 45,
      lessons: 32,
      enrolled: 1247,
      rating: 4.8,
      price: 2999,
      isPremium: true,
      isEnrolled: true,
      progress: 65,
      instructor: "Dr. Rajesh Kumar",
      thumbnail: "/physics-mechanics.png",
      tags: ["JEE Main", "JEE Advanced", "NEET"],
    },
    {
      id: "2",
      title: "Organic Chemistry Mastery",
      description: "Complete guide to organic chemistry reactions, mechanisms, and problem-solving strategies.",
      subject: "Chemistry",
      level: "intermediate",
      duration: 38,
      lessons: 28,
      enrolled: 892,
      rating: 4.7,
      price: 2499,
      isPremium: true,
      isEnrolled: true,
      progress: 40,
      instructor: "Prof. Priya Sharma",
      thumbnail: "/organic-chemistry.png",
      tags: ["JEE Main", "NEET", "Board Exams"],
    },
    {
      id: "3",
      title: "Calculus and Differential Equations",
      description: "From basic differentiation to advanced differential equations with real-world applications.",
      subject: "Mathematics",
      level: "advanced",
      duration: 52,
      lessons: 40,
      enrolled: 1156,
      rating: 4.9,
      price: 3499,
      isPremium: true,
      isEnrolled: false,
      progress: 0,
      instructor: "Dr. Amit Verma",
      thumbnail: "/calculus-math.png",
      tags: ["JEE Advanced", "Engineering", "Research"],
    },
    {
      id: "4",
      title: "Cell Biology and Genetics",
      description: "Explore the microscopic world of cells and understand the principles of heredity.",
      subject: "Biology",
      level: "intermediate",
      duration: 35,
      lessons: 25,
      enrolled: 743,
      rating: 4.6,
      price: 1999,
      isPremium: false,
      isEnrolled: true,
      progress: 80,
      instructor: "Dr. Meera Patel",
      thumbnail: "/cell-biology.png",
      tags: ["NEET", "Board Exams", "Medical"],
    },
    {
      id: "5",
      title: "Human Anatomy & Physiology",
      description: "Comprehensive study of human body systems and their functions.",
      subject: "Biology",
      level: "advanced",
      duration: 48,
      lessons: 36,
      enrolled: 654,
      rating: 4.8,
      price: 2799,
      isPremium: true,
      isEnrolled: false,
      progress: 0,
      instructor: "Dr. Suresh Reddy",
      thumbnail: "/human-physiology.png",
      tags: ["NEET", "Medical", "AIIMS"],
    },
    {
      id: "6",
      title: "Thermodynamics & Heat Transfer",
      description: "Master the laws of thermodynamics and heat transfer mechanisms.",
      subject: "Physics",
      level: "intermediate",
      duration: 30,
      lessons: 22,
      enrolled: 567,
      rating: 4.5,
      price: 1799,
      isPremium: false,
      isEnrolled: false,
      progress: 0,
      instructor: "Prof. Anita Singh",
      thumbnail: "/thermodynamics.png",
      tags: ["JEE Main", "Engineering", "Board Exams"],
    },
  ]

  const subjects = ["all", "Physics", "Chemistry", "Mathematics", "Biology"]
  const levels = ["all", "beginner", "intermediate", "advanced"]

  const filteredCourses = courses.filter((course) => {
    const matchesSearch =
      course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.instructor.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesSubject = selectedSubject === "all" || course.subject === selectedSubject
    const matchesLevel = selectedLevel === "all" || course.level === selectedLevel
    const matchesTab =
      selectedTab === "all" ||
      (selectedTab === "enrolled" && course.isEnrolled) ||
      (selectedTab === "recommended" && !course.isEnrolled)

    return matchesSearch && matchesSubject && matchesLevel && matchesTab
  })

  const enrolledCourses = courses.filter((course) => course.isEnrolled)
  const totalProgress =
    enrolledCourses.length > 0
      ? enrolledCourses.reduce((sum, course) => sum + course.progress, 0) / enrolledCourses.length
      : 0

  const getLevelColor = (level: string) => {
    switch (level) {
      case "beginner":
        return "bg-green-100 text-green-700"
      case "intermediate":
        return "bg-yellow-100 text-yellow-700"
      case "advanced":
        return "bg-red-100 text-red-700"
      default:
        return "bg-gray-100 text-gray-700"
    }
  }

  const getSubjectColor = (subject: string) => {
    switch (subject) {
      case "Physics":
        return "bg-blue-100 text-blue-700"
      case "Chemistry":
        return "bg-purple-100 text-purple-700"
      case "Mathematics":
        return "bg-orange-100 text-orange-700"
      case "Biology":
        return "bg-green-100 text-green-700"
      default:
        return "bg-gray-100 text-gray-700"
    }
  }

  const canAccessCourse = (course: Course) => {
    if (!course.isPremium) return true
    return user.plan === "premium" || user.plan === "pro"
  }

  const handleEnrollCourse = (courseId: string) => {
    // Handle course enrollment
    console.log("Enrolling in course:", courseId)
  }

  return (
    <div className="space-y-6">
      {/* Header with Stats */}
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 rounded-2xl p-6 text-white">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold mb-2">Course Library</h1>
            <p className="text-blue-100">Explore comprehensive courses designed for JEE & NEET preparation</p>
          </div>
          <div className="mt-4 md:mt-0 grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold">{enrolledCourses.length}</div>
              <div className="text-sm text-blue-200">Enrolled</div>
            </div>
            <div>
              <div className="text-2xl font-bold">{Math.round(totalProgress)}%</div>
              <div className="text-sm text-blue-200">Avg Progress</div>
            </div>
            <div>
              <div className="text-2xl font-bold">{courses.length}</div>
              <div className="text-sm text-blue-200">Available</div>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search courses, instructors, topics..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Subject" />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map((subject) => (
                    <SelectItem key={subject} value={subject}>
                      {subject === "all" ? "All Subjects" : subject}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={selectedLevel} onValueChange={setSelectedLevel}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Level" />
                </SelectTrigger>
                <SelectContent>
                  {levels.map((level) => (
                    <SelectItem key={level} value={level}>
                      {level === "all" ? "All Levels" : level.charAt(0).toUpperCase() + level.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Course Tabs */}
      <div className="flex gap-2 border-b">
        {[
          { id: "all", label: "All Courses", count: courses.length },
          { id: "enrolled", label: "My Courses", count: enrolledCourses.length },
          { id: "recommended", label: "Recommended", count: courses.filter((c) => !c.isEnrolled).length },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSelectedTab(tab.id)}
            className={`px-4 py-2 font-medium text-sm border-b-2 transition-colors ${
              selectedTab === tab.id
                ? "border-blue-600 text-blue-600"
                : "border-transparent text-gray-600 hover:text-gray-900"
            }`}
          >
            {tab.label} ({tab.count})
          </button>
        ))}
      </div>

      {/* Course Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCourses.map((course) => (
          <Card key={course.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="relative">
              <img
                src={course.thumbnail || "/placeholder.svg"}
                alt={course.title}
                className="w-full h-48 object-cover"
              />
              <div className="absolute top-2 left-2 flex gap-2">
                <Badge className={getSubjectColor(course.subject)}>{course.subject}</Badge>
                <Badge className={getLevelColor(course.level)}>{course.level}</Badge>
              </div>
              {course.isPremium && !canAccessCourse(course) && (
                <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                  <div className="text-white text-center">
                    <Lock className="h-8 w-8 mx-auto mb-2" />
                    <div className="text-sm font-medium">Premium Course</div>
                  </div>
                </div>
              )}
            </div>
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between">
                <CardTitle className="text-lg leading-tight">{course.title}</CardTitle>
                {course.isEnrolled && (
                  <Badge className="bg-green-500 text-white">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Enrolled
                  </Badge>
                )}
              </div>
              <CardDescription className="text-sm">{course.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between text-sm text-gray-600">
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  <span>{course.duration}h</span>
                </div>
                <div className="flex items-center gap-1">
                  <BookOpen className="h-4 w-4" />
                  <span>{course.lessons} lessons</span>
                </div>
                <div className="flex items-center gap-1">
                  <Users className="h-4 w-4" />
                  <span>{course.enrolled}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm font-medium">{course.rating}</span>
                </div>
                <div className="text-sm text-gray-600">by {course.instructor}</div>
              </div>

              {course.isEnrolled && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Progress</span>
                    <span>{course.progress}%</span>
                  </div>
                  <Progress value={course.progress} className="h-2" />
                </div>
              )}

              <div className="flex flex-wrap gap-1">
                {course.tags.map((tag, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="text-lg font-bold text-green-600">
                  {course.price === 0 ? "Free" : `₹${course.price}`}
                </div>
                {course.isEnrolled ? (
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Play className="h-4 w-4 mr-2" />
                    Continue
                  </Button>
                ) : canAccessCourse(course) ? (
                  <Button onClick={() => handleEnrollCourse(course.id)} variant="outline">
                    Enroll Now
                  </Button>
                ) : (
                  <Button disabled className="opacity-50">
                    <Lock className="h-4 w-4 mr-2" />
                    Premium
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredCourses.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center text-gray-500">
            <BookOpen className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No courses found matching your criteria.</p>
            <p className="text-sm mt-2">Try adjusting your search or filters.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
