"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { X, Smartphone, Copy, AlertCircle, Clock, Upload } from "lucide-react"
import {
  generateUPIUrl,
  generateQRCodeUrl,
  generateTransactionId,
  verifyPayment,
  storePayment,
  PLAN_PRICING,
  UPI_CONFIG,
  type PaymentDetails,
} from "@/lib/payment-utils"
import { useAuth } from "@/app/providers"

interface PaymentModalProps {
  isOpen: boolean
  onClose: () => void
  plan: "premium" | "pro"
  onSuccess: (plan: string) => void
}

type PaymentStep = "method" | "upi" | "verification" | "success" | "pending"

export function PaymentModal({ isOpen, onClose, plan, onSuccess }: PaymentModalProps) {
  const { user } = useAuth()
  const [step, setStep] = useState<PaymentStep>("method")
  const [transactionId, setTransactionId] = useState("")
  const [paymentUrl, setPaymentUrl] = useState("")
  const [qrCodeUrl, setQrCodeUrl] = useState("")
  const [isVerifying, setIsVerifying] = useState(false)
  const [userTransactionId, setUserTransactionId] = useState("")
  const [timeLeft, setTimeLeft] = useState(600) // 10 minutes
  const [screenshot, setScreenshot] = useState<string>("")

  const planDetails = PLAN_PRICING[plan]

  useEffect(() => {
    if (isOpen) {
      const txnId = generateTransactionId()
      setTransactionId(txnId)
      setPaymentUrl(generateUPIUrl(planDetails.amount, plan, txnId))
      setQrCodeUrl(generateQRCodeUrl(planDetails.amount, plan, txnId))
      setStep("method")
      setTimeLeft(600)
    }
  }, [isOpen, plan, planDetails.amount])

  // Timer countdown
  useEffect(() => {
    if (step === "upi" && timeLeft > 0) {
      const timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1)
      }, 1000)
      return () => clearInterval(timer)
    }
  }, [step, timeLeft])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const handleUPIPayment = () => {
    setStep("upi")
  }

  const handlePayNow = () => {
    // Open UPI app
    window.open(paymentUrl, "_blank")
    setStep("verification")
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setScreenshot(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleVerifyPayment = async () => {
    if (!userTransactionId.trim()) {
      alert("Please enter your transaction ID")
      return
    }

    if (!user) {
      alert("User not found")
      return
    }

    setIsVerifying(true)

    try {
      const result = await verifyPayment(userTransactionId)

      if (result.success) {
        // Store payment details for admin approval
        const paymentDetails: PaymentDetails = {
          userId: user.id,
          userName: user.name,
          userEmail: user.email,
          amount: planDetails.amount,
          plan: plan,
          upiId: UPI_CONFIG.merchantId,
          transactionId: userTransactionId,
          timestamp: new Date(),
          status: "pending",
          screenshot: screenshot,
        }
        storePayment(paymentDetails)

        setStep("pending")
      }
    } catch (error) {
      alert("Payment verification failed. Please try again.")
    } finally {
      setIsVerifying(false)
    }
  }

  const handleClose = () => {
    setStep("method")
    setUserTransactionId("")
    setScreenshot("")
    setTimeLeft(600)
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Upgrade to {plan.charAt(0).toUpperCase() + plan.slice(1)}</span>
            <Button variant="ghost" size="sm" onClick={handleClose}>
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
          <DialogDescription>Complete your payment to unlock premium features</DialogDescription>
        </DialogHeader>

        {/* Payment Method Selection */}
        {step === "method" && (
          <div className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <div className="text-center space-y-2">
                  <h3 className="text-lg font-semibold">{plan.charAt(0).toUpperCase() + plan.slice(1)} Plan</h3>
                  <div className="text-3xl font-bold text-green-600">₹{planDetails.amount}</div>
                  <p className="text-sm text-gray-600">for {planDetails.duration}</p>
                  <div className="space-y-1 text-xs text-gray-500">
                    {planDetails.features.map((feature, index) => (
                      <div key={index}>✓ {feature}</div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-3">
              <Button onClick={handleUPIPayment} className="w-full flex items-center justify-center space-x-2 h-12">
                <Smartphone className="h-5 w-5" />
                <span>Pay with UPI</span>
                <Badge className="bg-green-100 text-green-800">Instant</Badge>
              </Button>

              <div className="text-center">
                <p className="text-xs text-gray-500">Secure payment powered by UPI</p>
                <p className="text-xs text-orange-600 mt-1">
                  ⚠️ Access will be granted within 24 hours after verification
                </p>
              </div>
            </div>
          </div>
        )}

        {/* UPI Payment */}
        {step === "upi" && (
          <div className="space-y-4">
            <div className="text-center">
              <div className="flex items-center justify-center space-x-2 mb-2">
                <Clock className="h-4 w-4 text-orange-500" />
                <span className="text-sm font-medium">Time remaining: {formatTime(timeLeft)}</span>
              </div>
              <Badge className="bg-blue-100 text-blue-800">Transaction ID: {transactionId}</Badge>
            </div>

            {/* QR Code */}
            <Card>
              <CardContent className="p-4 text-center">
                <img
                  src={qrCodeUrl || "/placeholder.svg"}
                  alt="UPI QR Code"
                  className="w-48 h-48 mx-auto mb-4 border rounded-lg"
                />
                <p className="text-sm text-gray-600 mb-2">Scan with any UPI app</p>
                <Button onClick={handlePayNow} className="w-full">
                  <Smartphone className="mr-2 h-4 w-4" />
                  Open UPI App
                </Button>
              </CardContent>
            </Card>

            {/* Manual UPI Details */}
            <Card>
              <CardContent className="p-4 space-y-3">
                <h4 className="font-medium">Or pay manually:</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between items-center">
                    <span>UPI ID:</span>
                    <div className="flex items-center space-x-2">
                      <code className="bg-gray-100 px-2 py-1 rounded">{UPI_CONFIG.merchantId}</code>
                      <Button size="sm" variant="outline" onClick={() => copyToClipboard(UPI_CONFIG.merchantId)}>
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span>Amount:</span>
                    <span className="font-medium">₹{planDetails.amount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Name:</span>
                    <span>{UPI_CONFIG.merchantName}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Button onClick={() => setStep("verification")} variant="outline" className="w-full">
              I have completed the payment
            </Button>
          </div>
        )}

        {/* Payment Verification */}
        {step === "verification" && (
          <div className="space-y-4">
            <div className="text-center">
              <AlertCircle className="h-12 w-12 text-orange-500 mx-auto mb-2" />
              <h3 className="text-lg font-semibold">Verify Your Payment</h3>
              <p className="text-sm text-gray-600">Please provide payment details for verification</p>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium mb-1">UPI Transaction ID / Reference Number</label>
                <Input
                  placeholder="e.g., 123456789012"
                  value={userTransactionId}
                  onChange={(e) => setUserTransactionId(e.target.value)}
                />
                <p className="text-xs text-gray-500 mt-1">You can find this in your UPI app's transaction history</p>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Payment Screenshot (Optional)</label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="screenshot-upload"
                  />
                  <label htmlFor="screenshot-upload" className="cursor-pointer">
                    <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                    <p className="text-sm text-gray-600">Click to upload screenshot</p>
                  </label>
                  {screenshot && (
                    <div className="mt-2">
                      <img
                        src={screenshot || "/placeholder.svg"}
                        alt="Payment Screenshot"
                        className="max-w-full h-20 mx-auto rounded"
                      />
                    </div>
                  )}
                </div>
              </div>

              <Button
                onClick={handleVerifyPayment}
                disabled={isVerifying || !userTransactionId.trim()}
                className="w-full"
              >
                {isVerifying ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Submitting for Verification...
                  </>
                ) : (
                  "Submit for Verification"
                )}
              </Button>
            </div>

            <div className="text-center">
              <Button variant="link" onClick={() => setStep("upi")}>
                ← Back to payment
              </Button>
            </div>
          </div>
        )}

        {/* Pending Approval */}
        {step === "pending" && (
          <div className="text-center space-y-4">
            <Clock className="h-16 w-16 text-orange-500 mx-auto" />
            <div>
              <h3 className="text-lg font-semibold text-orange-600">Payment Under Review</h3>
              <p className="text-sm text-gray-600">Your payment has been submitted successfully and is under review.</p>
            </div>
            <div className="bg-orange-50 p-4 rounded-lg">
              <p className="text-sm text-orange-800 font-medium">🕐 You will get access within 24 hours</p>
              <p className="text-xs text-orange-700 mt-1">
                We'll notify you once your payment is verified and your plan is activated.
              </p>
            </div>
            <div className="bg-blue-50 p-3 rounded-lg">
              <p className="text-sm text-blue-800">Transaction ID: {userTransactionId}</p>
            </div>
            <Button onClick={handleClose} className="w-full">
              Close
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
