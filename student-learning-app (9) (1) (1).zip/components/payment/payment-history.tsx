"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Download, Receipt, Calendar, CreditCard } from "lucide-react"
import { getStoredPayments, type PaymentDetails } from "@/lib/payment-utils"

export function PaymentHistory() {
  const [payments, setPayments] = useState<PaymentDetails[]>([])

  useEffect(() => {
    setPayments(getStoredPayments())
  }, [])

  const downloadReceipt = (payment: PaymentDetails) => {
    const receiptContent = `
EDUPLATFORM PAYMENT RECEIPT
============================

Transaction ID: ${payment.transactionId}
Date: ${payment.timestamp.toLocaleDateString()}
Time: ${payment.timestamp.toLocaleTimeString()}

Plan: ${payment.plan.toUpperCase()}
Amount: ₹${payment.amount}
Payment Method: UPI
UPI ID: ${payment.upiId}

Status: SUCCESSFUL

Thank you for your payment!
Contact: support@eduplatform.com
    `.trim()

    const blob = new Blob([receiptContent], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `receipt-${payment.transactionId}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  if (payments.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Receipt className="h-5 w-5" />
            <span>Payment History</span>
          </CardTitle>
          <CardDescription>Your payment transactions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            <CreditCard className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No payments found</p>
            <p className="text-sm">Your payment history will appear here</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Receipt className="h-5 w-5" />
          <span>Payment History</span>
        </CardTitle>
        <CardDescription>Your payment transactions</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {payments.map((payment, index) => (
            <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-1">
                  <Badge className="bg-green-100 text-green-800">{payment.plan.toUpperCase()}</Badge>
                  <Badge variant="outline">SUCCESS</Badge>
                </div>
                <p className="font-medium">
                  ₹{payment.amount} - {payment.plan} Plan
                </p>
                <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-3 w-3" />
                    <span>{new Date(payment.timestamp).toLocaleDateString()}</span>
                  </div>
                  <span>TXN: {payment.transactionId}</span>
                </div>
              </div>
              <Button size="sm" variant="outline" onClick={() => downloadReceipt(payment)}>
                <Download className="mr-1 h-3 w-3" />
                Receipt
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
