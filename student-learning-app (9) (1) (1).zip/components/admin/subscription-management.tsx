"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Check, X, Clock, DollarSign, Users, Search, Eye } from "lucide-react"

interface PendingPayment {
  id: string
  userId: string
  userName: string
  userEmail: string
  plan: string
  amount: number
  date: string
  status: "pending" | "approved" | "rejected"
  paymentMethod: string
  transactionId: string
  screenshot?: string
  adminNotes?: string
}

export function SubscriptionManagement() {
  const [pendingPayments, setPendingPayments] = useState<PendingPayment[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedPayment, setSelectedPayment] = useState<PendingPayment | null>(null)
  const [adminNotes, setAdminNotes] = useState("")

  useEffect(() => {
    // Load pending payments from localStorage
    const payments = JSON.parse(localStorage.getItem("pendingPayments") || "[]")
    setPendingPayments(payments)
  }, [])

  const handleApprove = (paymentId: string) => {
    const updatedPayments = pendingPayments.map((payment) => {
      if (payment.id === paymentId) {
        // Update user plan in localStorage
        const users = JSON.parse(localStorage.getItem("users") || "[]")
        const userIndex = users.findIndex((u: any) => u.id === payment.userId)
        if (userIndex !== -1) {
          users[userIndex].plan = payment.plan
          localStorage.setItem("users", JSON.stringify(users))
        }

        return {
          ...payment,
          status: "approved" as const,
          adminNotes: adminNotes || "Payment approved and plan activated",
        }
      }
      return payment
    })

    setPendingPayments(updatedPayments)
    localStorage.setItem("pendingPayments", JSON.stringify(updatedPayments))
    setSelectedPayment(null)
    setAdminNotes("")

    alert(`Payment approved! User plan has been upgraded to ${selectedPayment?.plan}.`)
  }

  const handleReject = (paymentId: string) => {
    const updatedPayments = pendingPayments.map((payment) => {
      if (payment.id === paymentId) {
        return {
          ...payment,
          status: "rejected" as const,
          adminNotes: adminNotes || "Payment rejected - please contact support",
        }
      }
      return payment
    })

    setPendingPayments(updatedPayments)
    localStorage.setItem("pendingPayments", JSON.stringify(updatedPayments))
    setSelectedPayment(null)
    setAdminNotes("")

    alert("Payment rejected. User has been notified.")
  }

  const filteredPayments = pendingPayments.filter(
    (payment) =>
      payment.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.userEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.transactionId.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const stats = {
    pending: pendingPayments.filter((p) => p.status === "pending").length,
    approved: pendingPayments.filter((p) => p.status === "approved").length,
    rejected: pendingPayments.filter((p) => p.status === "rejected").length,
    totalRevenue: pendingPayments.filter((p) => p.status === "approved").reduce((sum, p) => sum + p.amount, 0),
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-2">Subscription Management</h1>
        <p className="text-gray-600">Manage payment approvals and subscription plans</p>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-orange-500" />
              <div>
                <p className="text-sm text-gray-600">Pending</p>
                <p className="text-2xl font-bold">{stats.pending}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Check className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-sm text-gray-600">Approved</p>
                <p className="text-2xl font-bold">{stats.approved}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <X className="h-5 w-5 text-red-500" />
              <div>
                <p className="text-sm text-gray-600">Rejected</p>
                <p className="text-2xl font-bold">{stats.rejected}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <DollarSign className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-sm text-gray-600">Revenue</p>
                <p className="text-2xl font-bold">₹{stats.totalRevenue}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search by name, email, or transaction ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Payments List */}
      <Card>
        <CardHeader>
          <CardTitle>Payment Requests</CardTitle>
          <CardDescription>Review and approve subscription payments</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredPayments.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No payment requests found</p>
              </div>
            ) : (
              filteredPayments.map((payment) => (
                <div key={payment.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <div>
                          <h3 className="font-semibold">{payment.userName}</h3>
                          <p className="text-sm text-gray-600">{payment.userEmail}</p>
                        </div>
                        <Badge
                          variant={
                            payment.status === "pending"
                              ? "secondary"
                              : payment.status === "approved"
                                ? "default"
                                : "destructive"
                          }
                        >
                          {payment.status}
                        </Badge>
                      </div>

                      <div className="grid md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600">Plan</p>
                          <p className="font-medium capitalize">{payment.plan}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Amount</p>
                          <p className="font-medium">₹{payment.amount}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Date</p>
                          <p className="font-medium">{new Date(payment.date).toLocaleDateString()}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Transaction ID</p>
                          <p className="font-medium">{payment.transactionId}</p>
                        </div>
                      </div>

                      {payment.adminNotes && (
                        <div className="mt-2 p-2 bg-gray-100 rounded text-sm">
                          <p className="text-gray-600">Admin Notes:</p>
                          <p>{payment.adminNotes}</p>
                        </div>
                      )}
                    </div>

                    <div className="flex space-x-2 ml-4">
                      <Button size="sm" variant="outline" onClick={() => setSelectedPayment(payment)}>
                        <Eye className="h-4 w-4 mr-1" />
                        Review
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Review Modal */}
      {selectedPayment && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <CardTitle>Review Payment Request</CardTitle>
              <CardDescription>Transaction ID: {selectedPayment.transactionId}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">User Details</h4>
                  <div className="space-y-1 text-sm">
                    <p>
                      <span className="text-gray-600">Name:</span> {selectedPayment.userName}
                    </p>
                    <p>
                      <span className="text-gray-600">Email:</span> {selectedPayment.userEmail}
                    </p>
                    <p>
                      <span className="text-gray-600">User ID:</span> {selectedPayment.userId}
                    </p>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Payment Details</h4>
                  <div className="space-y-1 text-sm">
                    <p>
                      <span className="text-gray-600">Plan:</span> {selectedPayment.plan}
                    </p>
                    <p>
                      <span className="text-gray-600">Amount:</span> ₹{selectedPayment.amount}
                    </p>
                    <p>
                      <span className="text-gray-600">Method:</span> {selectedPayment.paymentMethod}
                    </p>
                    <p>
                      <span className="text-gray-600">Date:</span> {new Date(selectedPayment.date).toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Admin Notes</label>
                <Textarea
                  placeholder="Add notes about this payment approval/rejection..."
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  rows={3}
                />
              </div>

              <div className="flex space-x-3">
                {selectedPayment.status === "pending" && (
                  <>
                    <Button
                      onClick={() => handleApprove(selectedPayment.id)}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Check className="h-4 w-4 mr-1" />
                      Approve Payment
                    </Button>
                    <Button variant="destructive" onClick={() => handleReject(selectedPayment.id)}>
                      <X className="h-4 w-4 mr-1" />
                      Reject Payment
                    </Button>
                  </>
                )}
                <Button
                  variant="outline"
                  onClick={() => {
                    setSelectedPayment(null)
                    setAdminNotes("")
                  }}
                >
                  Close
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
