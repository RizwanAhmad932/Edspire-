"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, Users, DollarSign, Clock, Target, Activity } from "lucide-react"
import { mockData } from "@/lib/utils"

export function Analytics() {
  const metrics = [
    {
      title: "Revenue Growth",
      value: "+15.3%",
      description: "vs last month",
      icon: DollarSign,
      color: "text-green-600",
      bgColor: "bg-green-100",
    },
    {
      title: "User Engagement",
      value: "85.2%",
      description: "retention rate",
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
    },
    {
      title: "Course Completion",
      value: "78.5%",
      description: "average rate",
      icon: Target,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
    },
    {
      title: "Session Duration",
      value: "45 min",
      description: "average time",
      icon: Clock,
      color: "text-orange-600",
      bgColor: "bg-orange-100",
    },
  ]

  const topCourses = [
    { name: "Complete Physics for JEE", enrollments: 15420, revenue: "₹12.5L" },
    { name: "Advanced Mathematics", enrollments: 12350, revenue: "₹9.8L" },
    { name: "Organic Chemistry", enrollments: 9800, revenue: "₹7.2L" },
    { name: "Biology Fundamentals", enrollments: 8500, revenue: "₹6.1L" },
  ]

  const recentActivity = [
    { event: "New user registration spike", time: "2 hours ago", type: "positive" },
    { event: "Course completion rate increased", time: "4 hours ago", type: "positive" },
    { event: "Payment gateway issue resolved", time: "6 hours ago", type: "neutral" },
    { event: "Server maintenance completed", time: "8 hours ago", type: "neutral" },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-2">Analytics Dashboard</h1>
        <p className="text-gray-600">Comprehensive platform analytics and insights</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => {
          const Icon = metric.icon
          return (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{metric.title}</p>
                    <p className="text-2xl font-bold">{metric.value}</p>
                    <p className="text-sm text-gray-500">{metric.description}</p>
                  </div>
                  <div className={`p-3 rounded-full ${metric.bgColor}`}>
                    <Icon className={`h-6 w-6 ${metric.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Charts Section */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Revenue Trends</CardTitle>
            <CardDescription>Monthly revenue over the last 6 months</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center bg-gray-50 rounded">
              <div className="text-center">
                <TrendingUp className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-600">Revenue Chart</p>
                <p className="text-sm text-gray-500">
                  ₹{(mockData.analytics.totalRevenue / 100000).toFixed(1)}L total revenue
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>User Activity</CardTitle>
            <CardDescription>Daily active users over time</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center bg-gray-50 rounded">
              <div className="text-center">
                <Activity className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-600">Activity Chart</p>
                <p className="text-sm text-gray-500">{mockData.analytics.activeUsers.toLocaleString()} active users</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top Performing Content */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Top Performing Courses</CardTitle>
            <CardDescription>Courses with highest enrollment and revenue</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topCourses.map((course, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">{course.name}</p>
                    <p className="text-sm text-gray-600">{course.enrollments.toLocaleString()} enrollments</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-green-600">{course.revenue}</p>
                    <p className="text-sm text-gray-500">revenue</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest platform events and updates</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-center space-x-3 p-3 border rounded-lg">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      activity.type === "positive"
                        ? "bg-green-500"
                        : activity.type === "negative"
                          ? "bg-red-500"
                          : "bg-blue-500"
                    }`}
                  ></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{activity.event}</p>
                    <p className="text-xs text-gray-500">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Stats */}
      <Card>
        <CardHeader>
          <CardTitle>Platform Statistics</CardTitle>
          <CardDescription>Comprehensive platform metrics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="space-y-4">
              <h4 className="font-semibold">User Metrics</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Total Users:</span>
                  <span className="font-medium">{mockData.analytics.totalUsers.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Active Users:</span>
                  <span className="font-medium">{mockData.analytics.activeUsers.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Monthly Growth:</span>
                  <span className="font-medium text-green-600">+{mockData.analytics.monthlyGrowth}%</span>
                </div>
                <div className="flex justify-between">
                  <span>Retention Rate:</span>
                  <span className="font-medium">{mockData.analytics.userRetention}%</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold">Content Metrics</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Total Courses:</span>
                  <span className="font-medium">{mockData.analytics.totalCourses}</span>
                </div>
                <div className="flex justify-between">
                  <span>Completion Rate:</span>
                  <span className="font-medium">{mockData.analytics.completionRate}%</span>
                </div>
                <div className="flex justify-between">
                  <span>Avg Session Time:</span>
                  <span className="font-medium">{mockData.analytics.avgSessionTime} min</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Tests:</span>
                  <span className="font-medium">{mockData.tests.length}</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-semibold">Revenue Metrics</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Total Revenue:</span>
                  <span className="font-medium">₹{(mockData.analytics.totalRevenue / 100000).toFixed(1)}L</span>
                </div>
                <div className="flex justify-between">
                  <span>Monthly Growth:</span>
                  <span className="font-medium text-green-600">+15.3%</span>
                </div>
                <div className="flex justify-between">
                  <span>Avg Revenue/User:</span>
                  <span className="font-medium">
                    ₹{Math.round(mockData.analytics.totalRevenue / mockData.analytics.totalUsers)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Conversion Rate:</span>
                  <span className="font-medium">12.5%</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
