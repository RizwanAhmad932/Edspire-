"use client"

import { useState } from "react"
import { AdminHeader } from "./admin-header"
import { AdminSidebar } from "./admin-sidebar"
import { AdminOverview } from "./admin-overview"
import { UserManagement } from "./user-management"
import { CourseManagement } from "./course-management"
import { TestManagement } from "./test-management"
import { LiveClassManagement } from "./live-class-management"
import { Analytics } from "./analytics"
import { Settings } from "./settings"
import { SubscriptionManagement } from "./subscription-management"
import { LectureManagement } from "./lecture-management"
import { NotificationManagement } from "./notification-management"
import { ProgressTracking } from "./progress-tracking"

interface User {
  id: string
  name: string
  email: string
  plan: "free" | "premium" | "pro"
  xp: number
  avatar?: string
  role: "student" | "admin"
  joinDate: string
  lastActive: string
}

interface AdminDashboardProps {
  user: User
  onLogout: () => void
}

type ActiveTab =
  | "overview"
  | "subscriptions"
  | "users"
  | "progress"
  | "courses"
  | "lectures"
  | "tests"
  | "live-classes"
  | "notifications"
  | "analytics"
  | "settings"

export function AdminDashboard({ user, onLogout }: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<ActiveTab>("overview")
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const renderContent = () => {
    switch (activeTab) {
      case "overview":
        return <AdminOverview />
      case "subscriptions":
        return <SubscriptionManagement />
      case "users":
        return <UserManagement />
      case "progress":
        return <ProgressTracking />
      case "courses":
        return <CourseManagement />
      case "lectures":
        return <LectureManagement />
      case "tests":
        return <TestManagement />
      case "live-classes":
        return <LiveClassManagement />
      case "notifications":
        return <NotificationManagement />
      case "analytics":
        return <Analytics />
      case "settings":
        return <Settings />
      default:
        return <AdminOverview />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader user={user} onLogout={onLogout} onMenuClick={() => setSidebarOpen(!sidebarOpen)} />

      <div className="flex">
        <AdminSidebar
          activeTab={activeTab}
          onTabChange={setActiveTab}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
        />

        <main className="flex-1 p-4 md:p-6 md:ml-64">{renderContent()}</main>
      </div>
    </div>
  )
}
