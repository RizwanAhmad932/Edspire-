"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Save, Upload, Download, RefreshCw, AlertTriangle } from "lucide-react"

export function Settings() {
  const [settings, setSettings] = useState({
    siteName: "EduPlatform",
    siteDescription: "Complete online learning platform",
    allowRegistration: true,
    requireEmailVerification: true,
    enableLiveClasses: true,
    enableAI: true,
    maxFreeQuestions: 3,
    maxPremiumQuestions: 15,
    maxProQuestions: 50,
    maintenanceMode: false,
    emailNotifications: true,
    smsNotifications: false,
  })

  const handleSettingChange = (key: string, value: any) => {
    setSettings((prev) => ({ ...prev, [key]: value }))
  }

  const handleSave = () => {
    // Save settings logic
    console.log("Settings saved:", settings)
  }

  const handleBackup = () => {
    // Backup logic
    console.log("Creating backup...")
  }

  const handleRestore = () => {
    // Restore logic
    console.log("Restoring from backup...")
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-2">System Settings</h1>
        <p className="text-gray-600">Configure platform settings and preferences</p>
      </div>

      {/* General Settings */}
      <Card>
        <CardHeader>
          <CardTitle>General Settings</CardTitle>
          <CardDescription>Basic platform configuration</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Site Name</label>
            <Input
              value={settings.siteName}
              onChange={(e) => handleSettingChange("siteName", e.target.value)}
              placeholder="Enter site name"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Site Description</label>
            <Textarea
              value={settings.siteDescription}
              onChange={(e) => handleSettingChange("siteDescription", e.target.value)}
              placeholder="Enter site description"
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      {/* User Settings */}
      <Card>
        <CardHeader>
          <CardTitle>User Management</CardTitle>
          <CardDescription>User registration and authentication settings</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Allow User Registration</p>
              <p className="text-sm text-gray-600">Enable new users to register</p>
            </div>
            <Switch
              checked={settings.allowRegistration}
              onCheckedChange={(checked) => handleSettingChange("allowRegistration", checked)}
            />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Require Email Verification</p>
              <p className="text-sm text-gray-600">Users must verify email before access</p>
            </div>
            <Switch
              checked={settings.requireEmailVerification}
              onCheckedChange={(checked) => handleSettingChange("requireEmailVerification", checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Feature Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Feature Configuration</CardTitle>
          <CardDescription>Enable or disable platform features</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Live Classes</p>
              <p className="text-sm text-gray-600">Enable live streaming classes</p>
            </div>
            <Switch
              checked={settings.enableLiveClasses}
              onCheckedChange={(checked) => handleSettingChange("enableLiveClasses", checked)}
            />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">AI Assistant</p>
              <p className="text-sm text-gray-600">Enable AI-powered Q&A feature</p>
            </div>
            <Switch
              checked={settings.enableAI}
              onCheckedChange={(checked) => handleSettingChange("enableAI", checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* AI Question Limits */}
      <Card>
        <CardHeader>
          <CardTitle>AI Question Limits</CardTitle>
          <CardDescription>Set daily question limits for different plans</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Free Plan</label>
              <Input
                type="number"
                value={settings.maxFreeQuestions}
                onChange={(e) => handleSettingChange("maxFreeQuestions", Number.parseInt(e.target.value))}
                min="0"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Premium Plan</label>
              <Input
                type="number"
                value={settings.maxPremiumQuestions}
                onChange={(e) => handleSettingChange("maxPremiumQuestions", Number.parseInt(e.target.value))}
                min="0"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Pro Plan</label>
              <Input
                type="number"
                value={settings.maxProQuestions}
                onChange={(e) => handleSettingChange("maxProQuestions", Number.parseInt(e.target.value))}
                min="0"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Notification Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Notifications</CardTitle>
          <CardDescription>Configure notification preferences</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Email Notifications</p>
              <p className="text-sm text-gray-600">Send notifications via email</p>
            </div>
            <Switch
              checked={settings.emailNotifications}
              onCheckedChange={(checked) => handleSettingChange("emailNotifications", checked)}
            />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">SMS Notifications</p>
              <p className="text-sm text-gray-600">Send notifications via SMS</p>
            </div>
            <Switch
              checked={settings.smsNotifications}
              onCheckedChange={(checked) => handleSettingChange("smsNotifications", checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* System Maintenance */}
      <Card>
        <CardHeader>
          <CardTitle>System Maintenance</CardTitle>
          <CardDescription>System maintenance and backup options</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-3 border rounded-lg">
            <div>
              <p className="font-medium">Maintenance Mode</p>
              <p className="text-sm text-gray-600">Put site in maintenance mode</p>
            </div>
            <div className="flex items-center space-x-2">
              {settings.maintenanceMode && (
                <Badge className="bg-red-100 text-red-800">
                  <AlertTriangle className="w-3 h-3 mr-1" />
                  Active
                </Badge>
              )}
              <Switch
                checked={settings.maintenanceMode}
                onCheckedChange={(checked) => handleSettingChange("maintenanceMode", checked)}
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <Button variant="outline" onClick={handleBackup}>
              <Download className="mr-2 h-4 w-4" />
              Create Backup
            </Button>
            <Button variant="outline" onClick={handleRestore}>
              <Upload className="mr-2 h-4 w-4" />
              Restore Backup
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end space-x-4">
        <Button variant="outline">
          <RefreshCw className="mr-2 h-4 w-4" />
          Reset to Defaults
        </Button>
        <Button onClick={handleSave}>
          <Save className="mr-2 h-4 w-4" />
          Save Settings
        </Button>
      </div>
    </div>
  )
}
