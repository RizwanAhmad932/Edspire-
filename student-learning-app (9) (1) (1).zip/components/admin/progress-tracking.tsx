"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { TrendingUp, Users, BookOpen, Clock, Search, Eye, Award, Target } from "lucide-react"

interface StudentProgress {
  id: string
  name: string
  email: string
  plan: "free" | "premium" | "pro"
  joinDate: string
  lastActive: string
  coursesEnrolled: number
  coursesCompleted: number
  totalStudyTime: number // in minutes
  xp: number
  streak: number
  testsAttempted: number
  testsCompleted: number
  averageScore: number
  aiQuestionsAsked: number
  liveClassesAttended: number
  certificatesEarned: number
}

export function ProgressTracking() {
  const [students, setStudents] = useState<StudentProgress[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [filterPlan, setFilterPlan] = useState("all")
  const [sortBy, setSortBy] = useState("xp")
  const [selectedStudent, setSelectedStudent] = useState<StudentProgress | null>(null)

  useEffect(() => {
    // Load student progress from localStorage
    const savedProgress = JSON.parse(localStorage.getItem("studentProgress") || "[]")
    if (savedProgress.length === 0) {
      // Add sample student progress data
      const sampleProgress: StudentProgress[] = [
        {
          id: "1",
          name: "John Doe",
          email: "john@example.com",
          plan: "premium",
          joinDate: "2024-01-15",
          lastActive: "2024-01-19",
          coursesEnrolled: 5,
          coursesCompleted: 3,
          totalStudyTime: 1250,
          xp: 2850,
          streak: 7,
          testsAttempted: 12,
          testsCompleted: 10,
          averageScore: 85,
          aiQuestionsAsked: 45,
          liveClassesAttended: 8,
          certificatesEarned: 3,
        },
        {
          id: "2",
          name: "Sarah Johnson",
          email: "sarah@example.com",
          plan: "pro",
          joinDate: "2024-01-10",
          lastActive: "2024-01-19",
          coursesEnrolled: 8,
          coursesCompleted: 6,
          totalStudyTime: 2100,
          xp: 4200,
          streak: 12,
          testsAttempted: 20,
          testsCompleted: 18,
          averageScore: 92,
          aiQuestionsAsked: 78,
          liveClassesAttended: 15,
          certificatesEarned: 6,
        },
        {
          id: "3",
          name: "Mike Wilson",
          email: "mike@example.com",
          plan: "free",
          joinDate: "2024-01-18",
          lastActive: "2024-01-19",
          coursesEnrolled: 2,
          coursesCompleted: 1,
          totalStudyTime: 320,
          xp: 650,
          streak: 3,
          testsAttempted: 4,
          testsCompleted: 3,
          averageScore: 78,
          aiQuestionsAsked: 12,
          liveClassesAttended: 2,
          certificatesEarned: 1,
        },
      ]
      setStudents(sampleProgress)
      localStorage.setItem("studentProgress", JSON.stringify(sampleProgress))
    } else {
      setStudents(savedProgress)
    }
  }, [])

  const filteredAndSortedStudents = students
    .filter((student) => {
      const matchesSearch =
        student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        student.email.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesPlan = filterPlan === "all" || student.plan === filterPlan
      return matchesSearch && matchesPlan
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "xp":
          return b.xp - a.xp
        case "studyTime":
          return b.totalStudyTime - a.totalStudyTime
        case "courses":
          return b.coursesCompleted - a.coursesCompleted
        case "score":
          return b.averageScore - a.averageScore
        case "streak":
          return b.streak - a.streak
        default:
          return 0
      }
    })

  const stats = {
    totalStudents: students.length,
    activeStudents: students.filter((s) => {
      const lastActive = new Date(s.lastActive)
      const threeDaysAgo = new Date()
      threeDaysAgo.setDate(threeDaysAgo.getDate() - 3)
      return lastActive > threeDaysAgo
    }).length,
    avgCompletionRate:
      students.length > 0
        ? Math.round(
            students.reduce((sum, s) => sum + (s.coursesCompleted / s.coursesEnrolled) * 100, 0) / students.length,
          )
        : 0,
    totalStudyHours: Math.round(students.reduce((sum, s) => sum + s.totalStudyTime, 0) / 60),
  }

  const formatStudyTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return `${hours}h ${mins}m`
  }

  const getEngagementLevel = (student: StudentProgress) => {
    const score = student.streak * 10 + student.liveClassesAttended * 5 + student.aiQuestionsAsked * 2
    if (score >= 200) return { level: "High", color: "bg-green-100 text-green-800" }
    if (score >= 100) return { level: "Medium", color: "bg-yellow-100 text-yellow-800" }
    return { level: "Low", color: "bg-red-100 text-red-800" }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-2">Progress Tracking</h1>
        <p className="text-gray-600">Monitor student performance and engagement</p>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-sm text-gray-600">Total Students</p>
                <p className="text-2xl font-bold">{stats.totalStudents}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-sm text-gray-600">Active Students</p>
                <p className="text-2xl font-bold">{stats.activeStudents}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Target className="h-5 w-5 text-purple-500" />
              <div>
                <p className="text-sm text-gray-600">Avg Completion</p>
                <p className="text-2xl font-bold">{stats.avgCompletionRate}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-orange-500" />
              <div>
                <p className="text-sm text-gray-600">Study Hours</p>
                <p className="text-2xl font-bold">{stats.totalStudyHours}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search students..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterPlan} onValueChange={setFilterPlan}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filter by plan" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Plans</SelectItem>
                <SelectItem value="free">Free</SelectItem>
                <SelectItem value="premium">Premium</SelectItem>
                <SelectItem value="pro">Pro</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="xp">XP Points</SelectItem>
                <SelectItem value="studyTime">Study Time</SelectItem>
                <SelectItem value="courses">Courses Completed</SelectItem>
                <SelectItem value="score">Average Score</SelectItem>
                <SelectItem value="streak">Study Streak</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Students List */}
      <div className="grid gap-4">
        {filteredAndSortedStudents.map((student) => {
          const engagement = getEngagementLevel(student)
          const completionRate =
            student.coursesEnrolled > 0 ? Math.round((student.coursesCompleted / student.coursesEnrolled) * 100) : 0

          return (
            <Card key={student.id}>
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-3">
                      <div>
                        <h3 className="text-lg font-semibold">{student.name}</h3>
                        <p className="text-sm text-gray-600">{student.email}</p>
                      </div>
                      <Badge variant="outline" className="capitalize">
                        {student.plan}
                      </Badge>
                      <Badge className={engagement.color}>{engagement.level} Engagement</Badge>
                    </div>

                    <div className="grid md:grid-cols-6 gap-4 mb-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-blue-600">{student.xp}</p>
                        <p className="text-xs text-gray-600">XP Points</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-green-600">{student.coursesCompleted}</p>
                        <p className="text-xs text-gray-600">Courses Done</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-purple-600">{student.streak}</p>
                        <p className="text-xs text-gray-600">Day Streak</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-orange-600">{student.averageScore}%</p>
                        <p className="text-xs text-gray-600">Avg Score</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-red-600">{formatStudyTime(student.totalStudyTime)}</p>
                        <p className="text-xs text-gray-600">Study Time</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-indigo-600">{student.certificatesEarned}</p>
                        <p className="text-xs text-gray-600">Certificates</p>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Course Completion</span>
                        <span>{completionRate}%</span>
                      </div>
                      <Progress value={completionRate} className="h-2" />
                    </div>
                  </div>

                  <div className="flex space-x-2 ml-4">
                    <Button size="sm" variant="outline" onClick={() => setSelectedStudent(student)}>
                      <Eye className="h-4 w-4 mr-1" />
                      Details
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Student Details Modal */}
      {selectedStudent && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <CardTitle>Student Progress Details</CardTitle>
              <CardDescription>
                {selectedStudent.name} - {selectedStudent.email}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Overview Stats */}
              <div className="grid md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <Award className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-blue-600">{selectedStudent.xp}</p>
                  <p className="text-sm text-gray-600">Total XP</p>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <BookOpen className="h-8 w-8 text-green-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-green-600">{selectedStudent.coursesCompleted}</p>
                  <p className="text-sm text-gray-600">Completed Courses</p>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <TrendingUp className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-purple-600">{selectedStudent.streak}</p>
                  <p className="text-sm text-gray-600">Study Streak</p>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-lg">
                  <Clock className="h-8 w-8 text-orange-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-orange-600">
                    {formatStudyTime(selectedStudent.totalStudyTime)}
                  </p>
                  <p className="text-sm text-gray-600">Study Time</p>
                </div>
              </div>

              {/* Detailed Metrics */}
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3">Academic Performance</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span>Courses Enrolled:</span>
                      <span className="font-medium">{selectedStudent.coursesEnrolled}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Courses Completed:</span>
                      <span className="font-medium">{selectedStudent.coursesCompleted}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Tests Attempted:</span>
                      <span className="font-medium">{selectedStudent.testsAttempted}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Tests Completed:</span>
                      <span className="font-medium">{selectedStudent.testsCompleted}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Average Score:</span>
                      <span className="font-medium">{selectedStudent.averageScore}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Certificates Earned:</span>
                      <span className="font-medium">{selectedStudent.certificatesEarned}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-3">Engagement Metrics</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span>AI Questions Asked:</span>
                      <span className="font-medium">{selectedStudent.aiQuestionsAsked}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Live Classes Attended:</span>
                      <span className="font-medium">{selectedStudent.liveClassesAttended}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Current Streak:</span>
                      <span className="font-medium">{selectedStudent.streak} days</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Join Date:</span>
                      <span className="font-medium">{new Date(selectedStudent.joinDate).toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Last Active:</span>
                      <span className="font-medium">{new Date(selectedStudent.lastActive).toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Plan:</span>
                      <Badge variant="outline" className="capitalize">
                        {selectedStudent.plan}
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>

              <Button variant="outline" onClick={() => setSelectedStudent(null)} className="w-full">
                Close
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
