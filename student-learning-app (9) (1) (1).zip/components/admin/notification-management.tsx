"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Send, Bell, Users, MessageSquare, Calendar, Eye, Trash2 } from "lucide-react"

interface Notification {
  id: string
  title: string
  message: string
  targetAudience: "all" | "free" | "premium" | "pro"
  type: "announcement" | "update" | "promotion" | "reminder"
  priority: "low" | "medium" | "high"
  scheduledDate?: string
  sentDate?: string
  status: "draft" | "scheduled" | "sent"
  readCount: number
  totalRecipients: number
}

export function NotificationManagement() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [selectedNotification, setSelectedNotification] = useState<Notification | null>(null)

  const [formData, setFormData] = useState({
    title: "",
    message: "",
    targetAudience: "all" as "all" | "free" | "premium" | "pro",
    type: "announcement" as "announcement" | "update" | "promotion" | "reminder",
    priority: "medium" as "low" | "medium" | "high",
    scheduledDate: "",
  })

  useEffect(() => {
    // Load notifications from localStorage
    const savedNotifications = JSON.parse(localStorage.getItem("notifications") || "[]")
    if (savedNotifications.length === 0) {
      // Add sample notifications
      const sampleNotifications: Notification[] = [
        {
          id: "1",
          title: "Welcome to EduPlatform!",
          message: "Thank you for joining our learning community. Explore courses and start your journey today!",
          targetAudience: "all",
          type: "announcement",
          priority: "medium",
          sentDate: "2024-01-15T10:00:00Z",
          status: "sent",
          readCount: 245,
          totalRecipients: 300,
        },
        {
          id: "2",
          title: "New Course: Advanced React",
          message: "We've added a new advanced React course with hands-on projects. Check it out now!",
          targetAudience: "premium",
          type: "update",
          priority: "high",
          sentDate: "2024-01-18T14:30:00Z",
          status: "sent",
          readCount: 89,
          totalRecipients: 120,
        },
      ]
      setNotifications(sampleNotifications)
      localStorage.setItem("notifications", JSON.stringify(sampleNotifications))
    } else {
      setNotifications(savedNotifications)
    }
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newNotification: Notification = {
      id: Date.now().toString(),
      ...formData,
      status: formData.scheduledDate ? "scheduled" : "sent",
      sentDate: formData.scheduledDate ? undefined : new Date().toISOString(),
      readCount: 0,
      totalRecipients: getRecipientCount(formData.targetAudience),
    }

    const updatedNotifications = [newNotification, ...notifications]
    setNotifications(updatedNotifications)
    localStorage.setItem("notifications", JSON.stringify(updatedNotifications))

    // Reset form
    setFormData({
      title: "",
      message: "",
      targetAudience: "all",
      type: "announcement",
      priority: "medium",
      scheduledDate: "",
    })
    setShowCreateForm(false)

    alert(formData.scheduledDate ? "Notification scheduled successfully!" : "Notification sent successfully!")
  }

  const getRecipientCount = (audience: string) => {
    // Mock recipient counts
    switch (audience) {
      case "all":
        return 300
      case "free":
        return 180
      case "premium":
        return 90
      case "pro":
        return 30
      default:
        return 0
    }
  }

  const handleDelete = (notificationId: string) => {
    if (confirm("Are you sure you want to delete this notification?")) {
      const updatedNotifications = notifications.filter((n) => n.id !== notificationId)
      setNotifications(updatedNotifications)
      localStorage.setItem("notifications", JSON.stringify(updatedNotifications))
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "sent":
        return "bg-green-100 text-green-800"
      case "scheduled":
        return "bg-blue-100 text-blue-800"
      case "draft":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const stats = {
    total: notifications.length,
    sent: notifications.filter((n) => n.status === "sent").length,
    scheduled: notifications.filter((n) => n.status === "scheduled").length,
    totalReads: notifications.reduce((sum, n) => sum + n.readCount, 0),
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold mb-2">Notification Management</h1>
          <p className="text-gray-600">Send announcements and updates to your students</p>
        </div>
        <Button onClick={() => setShowCreateForm(true)}>
          <Send className="h-4 w-4 mr-2" />
          Create Notification
        </Button>
      </div>

      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Bell className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-sm text-gray-600">Total Sent</p>
                <p className="text-2xl font-bold">{stats.sent}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Calendar className="h-5 w-5 text-orange-500" />
              <div>
                <p className="text-sm text-gray-600">Scheduled</p>
                <p className="text-2xl font-bold">{stats.scheduled}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Eye className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-sm text-gray-600">Total Reads</p>
                <p className="text-2xl font-bold">{stats.totalReads}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-purple-500" />
              <div>
                <p className="text-sm text-gray-600">Avg. Read Rate</p>
                <p className="text-2xl font-bold">
                  {stats.sent > 0 ? Math.round((stats.totalReads / (stats.sent * 300)) * 100) : 0}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Notifications List */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Notifications</CardTitle>
          <CardDescription>Manage your sent and scheduled notifications</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {notifications.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No notifications sent yet</p>
              </div>
            ) : (
              notifications.map((notification) => (
                <div key={notification.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="font-semibold">{notification.title}</h3>
                        <Badge className={getStatusColor(notification.status)}>{notification.status}</Badge>
                        <Badge className={getPriorityColor(notification.priority)}>{notification.priority}</Badge>
                        <Badge variant="outline">{notification.targetAudience}</Badge>
                      </div>

                      <p className="text-gray-600 mb-3 line-clamp-2">{notification.message}</p>

                      <div className="grid md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600">Type</p>
                          <p className="font-medium capitalize">{notification.type}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Recipients</p>
                          <p className="font-medium">{notification.totalRecipients}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Read Count</p>
                          <p className="font-medium">{notification.readCount}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Date</p>
                          <p className="font-medium">
                            {notification.sentDate
                              ? new Date(notification.sentDate).toLocaleDateString()
                              : notification.scheduledDate
                                ? new Date(notification.scheduledDate).toLocaleDateString()
                                : "Draft"}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="flex space-x-2 ml-4">
                      <Button size="sm" variant="outline" onClick={() => setSelectedNotification(notification)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => handleDelete(notification.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Create Notification Form Modal */}
      {showCreateForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <CardTitle>Create New Notification</CardTitle>
              <CardDescription>Send announcements to your students</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Title</label>
                  <Input
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Enter notification title..."
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Message</label>
                  <Textarea
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Enter your message..."
                    rows={4}
                    required
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Target Audience</label>
                    <Select
                      value={formData.targetAudience}
                      onValueChange={(value: "all" | "free" | "premium" | "pro") =>
                        setFormData({ ...formData, targetAudience: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Users (300)</SelectItem>
                        <SelectItem value="free">Free Users (180)</SelectItem>
                        <SelectItem value="premium">Premium Users (90)</SelectItem>
                        <SelectItem value="pro">Pro Users (30)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">Type</label>
                    <Select
                      value={formData.type}
                      onValueChange={(value: "announcement" | "update" | "promotion" | "reminder") =>
                        setFormData({ ...formData, type: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="announcement">Announcement</SelectItem>
                        <SelectItem value="update">Update</SelectItem>
                        <SelectItem value="promotion">Promotion</SelectItem>
                        <SelectItem value="reminder">Reminder</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Priority</label>
                    <Select
                      value={formData.priority}
                      onValueChange={(value: "low" | "medium" | "high") =>
                        setFormData({ ...formData, priority: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">Schedule Date (Optional)</label>
                    <Input
                      type="datetime-local"
                      value={formData.scheduledDate}
                      onChange={(e) => setFormData({ ...formData, scheduledDate: e.target.value })}
                    />
                  </div>
                </div>

                <div className="flex space-x-3">
                  <Button type="submit">
                    <Send className="h-4 w-4 mr-2" />
                    {formData.scheduledDate ? "Schedule Notification" : "Send Now"}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setShowCreateForm(false)
                      setFormData({
                        title: "",
                        message: "",
                        targetAudience: "all",
                        type: "announcement",
                        priority: "medium",
                        scheduledDate: "",
                      })
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}

      {/* View Notification Modal */}
      {selectedNotification && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <CardTitle>Notification Details</CardTitle>
              <div className="flex space-x-2">
                <Badge className={getStatusColor(selectedNotification.status)}>{selectedNotification.status}</Badge>
                <Badge className={getPriorityColor(selectedNotification.priority)}>
                  {selectedNotification.priority}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Title</h3>
                <p>{selectedNotification.title}</p>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Message</h3>
                <p className="whitespace-pre-wrap">{selectedNotification.message}</p>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h3 className="font-semibold mb-2">Target Audience</h3>
                  <p className="capitalize">{selectedNotification.targetAudience}</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Type</h3>
                  <p className="capitalize">{selectedNotification.type}</p>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h3 className="font-semibold mb-2">Recipients</h3>
                  <p>{selectedNotification.totalRecipients}</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Read Count</h3>
                  <p>
                    {selectedNotification.readCount} (
                    {Math.round((selectedNotification.readCount / selectedNotification.totalRecipients) * 100)}%)
                  </p>
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Date</h3>
                <p>
                  {selectedNotification.sentDate
                    ? `Sent: ${new Date(selectedNotification.sentDate).toLocaleString()}`
                    : selectedNotification.scheduledDate
                      ? `Scheduled: ${new Date(selectedNotification.scheduledDate).toLocaleString()}`
                      : "Draft"}
                </p>
              </div>

              <Button variant="outline" onClick={() => setSelectedNotification(null)} className="w-full">
                Close
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
