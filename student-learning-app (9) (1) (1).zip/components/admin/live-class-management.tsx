"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, Plus, Edit, Trash2, Eye, Calendar, Clock, Users, Video } from "lucide-react"
import { mockData } from "@/lib/utils"

export function LiveClassManagement() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStatus, setSelectedStatus] = useState("all")

  const filteredClasses = mockData.liveClasses.filter((liveClass) => {
    const matchesSearch =
      liveClass.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      liveClass.instructor.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = selectedStatus === "all" || liveClass.status === selectedStatus
    return matchesSearch && matchesStatus
  })

  const statuses = ["all", "live", "upcoming", "scheduled", "completed"]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "live":
        return "bg-red-100 text-red-800"
      case "upcoming":
        return "bg-green-100 text-green-800"
      case "scheduled":
        return "bg-blue-100 text-blue-800"
      case "completed":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-2">Live Class Management</h1>
          <p className="text-gray-600">Schedule and manage live classes</p>
        </div>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Schedule Class
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{mockData.liveClasses.length}</div>
            <div className="text-sm text-gray-600">Total Classes</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{mockData.liveClasses.filter((c) => c.status === "live").length}</div>
            <div className="text-sm text-gray-600">Live Now</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">
              {mockData.liveClasses.filter((c) => c.status === "upcoming").length}
            </div>
            <div className="text-sm text-gray-600">Upcoming</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">
              {mockData.liveClasses.reduce((sum, c) => sum + c.students, 0).toLocaleString()}
            </div>
            <div className="text-sm text-gray-600">Total Attendees</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search classes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-3 py-2 border rounded-md"
            >
              {statuses.map((status) => (
                <option key={status} value={status}>
                  {status === "all" ? "All Status" : status.charAt(0).toUpperCase() + status.slice(1)}
                </option>
              ))}
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Classes List */}
      <Card>
        <CardHeader>
          <CardTitle>Live Classes ({filteredClasses.length})</CardTitle>
          <CardDescription>Manage scheduled and ongoing live classes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredClasses.map((liveClass) => (
              <div
                key={liveClass.id}
                className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
              >
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <Badge variant="secondary">{liveClass.subject}</Badge>
                    <Badge className={getStatusColor(liveClass.status)}>{liveClass.status.toUpperCase()}</Badge>
                  </div>

                  <h3 className="text-lg font-semibold mb-1">{liveClass.title}</h3>
                  <p className="text-gray-600 mb-2">by {liveClass.instructor}</p>

                  <div className="flex items-center space-x-6 text-sm text-gray-500">
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-4 w-4" />
                      <span>{liveClass.date}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4" />
                      <span>{liveClass.time}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Users className="h-4 w-4" />
                      <span>{liveClass.students} registered</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Video className="h-4 w-4" />
                      <span>ID: {liveClass.meetingId}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  {liveClass.status === "live" && (
                    <Button size="sm" className="bg-red-500 hover:bg-red-600">
                      <Video className="mr-1 h-3 w-3" />
                      Join
                    </Button>
                  )}
                  <Button size="sm" variant="outline">
                    <Eye className="mr-1 h-3 w-3" />
                    View
                  </Button>
                  <Button size="sm" variant="outline">
                    <Edit className="mr-1 h-3 w-3" />
                    Edit
                  </Button>
                  <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700 bg-transparent">
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
