"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Edit, Trash2, Video, Calendar, Users, Search, BookOpen } from "lucide-react"

interface Lecture {
  id: string
  title: string
  description: string
  subject: string
  instructor: string
  date: string
  time: string
  duration: number
  type: "live" | "recorded"
  maxStudents: number
  enrolledStudents: number
  status: "scheduled" | "ongoing" | "completed" | "cancelled"
  videoUrl?: string
  materials?: string[]
}

export function LectureManagement() {
  const [lectures, setLectures] = useState<Lecture[]>([])
  const [showAddForm, setShowAddForm] = useState(false)
  const [editingLecture, setEditingLecture] = useState<Lecture | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterSubject, setFilterSubject] = useState("all")
  const [filterStatus, setFilterStatus] = useState("all")

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    subject: "",
    instructor: "",
    date: "",
    time: "",
    duration: 60,
    type: "live" as "live" | "recorded",
    maxStudents: 50,
    videoUrl: "",
  })

  useEffect(() => {
    // Load lectures from localStorage
    const savedLectures = JSON.parse(localStorage.getItem("lectures") || "[]")
    if (savedLectures.length === 0) {
      // Add sample lectures
      const sampleLectures: Lecture[] = [
        {
          id: "1",
          title: "Introduction to React Hooks",
          description: "Learn the fundamentals of React Hooks and how to use them effectively",
          subject: "React",
          instructor: "John Smith",
          date: "2024-01-20",
          time: "10:00",
          duration: 90,
          type: "live",
          maxStudents: 50,
          enrolledStudents: 35,
          status: "scheduled",
          materials: ["React Hooks Guide.pdf", "Code Examples.zip"],
        },
        {
          id: "2",
          title: "Advanced JavaScript Concepts",
          description: "Deep dive into closures, prototypes, and async programming",
          subject: "JavaScript",
          instructor: "Sarah Johnson",
          date: "2024-01-18",
          time: "14:00",
          duration: 120,
          type: "recorded",
          maxStudents: 100,
          enrolledStudents: 78,
          status: "completed",
          videoUrl: "https://example.com/video/js-advanced",
        },
      ]
      setLectures(sampleLectures)
      localStorage.setItem("lectures", JSON.stringify(sampleLectures))
    } else {
      setLectures(savedLectures)
    }
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newLecture: Lecture = {
      id: editingLecture ? editingLecture.id : Date.now().toString(),
      ...formData,
      enrolledStudents: editingLecture ? editingLecture.enrolledStudents : 0,
      status: "scheduled",
      materials: [],
    }

    let updatedLectures
    if (editingLecture) {
      updatedLectures = lectures.map((lecture) => (lecture.id === editingLecture.id ? newLecture : lecture))
    } else {
      updatedLectures = [...lectures, newLecture]
    }

    setLectures(updatedLectures)
    localStorage.setItem("lectures", JSON.stringify(updatedLectures))

    // Reset form
    setFormData({
      title: "",
      description: "",
      subject: "",
      instructor: "",
      date: "",
      time: "",
      duration: 60,
      type: "live",
      maxStudents: 50,
      videoUrl: "",
    })
    setShowAddForm(false)
    setEditingLecture(null)
  }

  const handleEdit = (lecture: Lecture) => {
    setFormData({
      title: lecture.title,
      description: lecture.description,
      subject: lecture.subject,
      instructor: lecture.instructor,
      date: lecture.date,
      time: lecture.time,
      duration: lecture.duration,
      type: lecture.type,
      maxStudents: lecture.maxStudents,
      videoUrl: lecture.videoUrl || "",
    })
    setEditingLecture(lecture)
    setShowAddForm(true)
  }

  const handleDelete = (lectureId: string) => {
    if (confirm("Are you sure you want to delete this lecture?")) {
      const updatedLectures = lectures.filter((lecture) => lecture.id !== lectureId)
      setLectures(updatedLectures)
      localStorage.setItem("lectures", JSON.stringify(updatedLectures))
    }
  }

  const filteredLectures = lectures.filter((lecture) => {
    const matchesSearch =
      lecture.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lecture.instructor.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lecture.subject.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesSubject = filterSubject === "all" || lecture.subject === filterSubject
    const matchesStatus = filterStatus === "all" || lecture.status === filterStatus

    return matchesSearch && matchesSubject && matchesStatus
  })

  const subjects = [...new Set(lectures.map((lecture) => lecture.subject))]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "scheduled":
        return "bg-blue-100 text-blue-800"
      case "ongoing":
        return "bg-green-100 text-green-800"
      case "completed":
        return "bg-gray-100 text-gray-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold mb-2">Lecture Management</h1>
          <p className="text-gray-600">Create and manage live and recorded lectures</p>
        </div>
        <Button onClick={() => setShowAddForm(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Lecture
        </Button>
      </div>

      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <BookOpen className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-sm text-gray-600">Total Lectures</p>
                <p className="text-2xl font-bold">{lectures.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Calendar className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-sm text-gray-600">Scheduled</p>
                <p className="text-2xl font-bold">{lectures.filter((l) => l.status === "scheduled").length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Video className="h-5 w-5 text-purple-500" />
              <div>
                <p className="text-sm text-gray-600">Live Classes</p>
                <p className="text-2xl font-bold">{lectures.filter((l) => l.type === "live").length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-orange-500" />
              <div>
                <p className="text-sm text-gray-600">Total Enrolled</p>
                <p className="text-2xl font-bold">{lectures.reduce((sum, l) => sum + l.enrolledStudents, 0)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search lectures..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterSubject} onValueChange={setFilterSubject}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filter by subject" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Subjects</SelectItem>
                {subjects.map((subject) => (
                  <SelectItem key={subject} value={subject}>
                    {subject}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="scheduled">Scheduled</SelectItem>
                <SelectItem value="ongoing">Ongoing</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Lectures List */}
      <div className="grid gap-4">
        {filteredLectures.map((lecture) => (
          <Card key={lecture.id}>
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="text-lg font-semibold">{lecture.title}</h3>
                    <Badge className={getStatusColor(lecture.status)}>{lecture.status}</Badge>
                    <Badge variant="outline">{lecture.type}</Badge>
                  </div>

                  <p className="text-gray-600 mb-3">{lecture.description}</p>

                  <div className="grid md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">Subject</p>
                      <p className="font-medium">{lecture.subject}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Instructor</p>
                      <p className="font-medium">{lecture.instructor}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Date & Time</p>
                      <p className="font-medium">
                        {new Date(lecture.date).toLocaleDateString()} at {lecture.time}
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-600">Enrolled</p>
                      <p className="font-medium">
                        {lecture.enrolledStudents}/{lecture.maxStudents}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex space-x-2 ml-4">
                  <Button size="sm" variant="outline" onClick={() => handleEdit(lecture)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleDelete(lecture.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Add/Edit Form Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <CardTitle>{editingLecture ? "Edit Lecture" : "Add New Lecture"}</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Title</label>
                    <Input
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Subject</label>
                    <Input
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Description</label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={3}
                    required
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Instructor</label>
                    <Input
                      value={formData.instructor}
                      onChange={(e) => setFormData({ ...formData, instructor: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Type</label>
                    <Select
                      value={formData.type}
                      onValueChange={(value: "live" | "recorded") => setFormData({ ...formData, type: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="live">Live</SelectItem>
                        <SelectItem value="recorded">Recorded</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Date</label>
                    <Input
                      type="date"
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Time</label>
                    <Input
                      type="time"
                      value={formData.time}
                      onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Duration (minutes)</label>
                    <Input
                      type="number"
                      value={formData.duration}
                      onChange={(e) => setFormData({ ...formData, duration: Number.parseInt(e.target.value) })}
                      min="30"
                      max="300"
                      required
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Max Students</label>
                    <Input
                      type="number"
                      value={formData.maxStudents}
                      onChange={(e) => setFormData({ ...formData, maxStudents: Number.parseInt(e.target.value) })}
                      min="1"
                      max="500"
                      required
                    />
                  </div>
                  {formData.type === "recorded" && (
                    <div>
                      <label className="block text-sm font-medium mb-1">Video URL</label>
                      <Input
                        type="url"
                        value={formData.videoUrl}
                        onChange={(e) => setFormData({ ...formData, videoUrl: e.target.value })}
                        placeholder="https://..."
                      />
                    </div>
                  )}
                </div>

                <div className="flex space-x-3">
                  <Button type="submit">{editingLecture ? "Update Lecture" : "Create Lecture"}</Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setShowAddForm(false)
                      setEditingLecture(null)
                      setFormData({
                        title: "",
                        description: "",
                        subject: "",
                        instructor: "",
                        date: "",
                        time: "",
                        duration: 60,
                        type: "live",
                        maxStudents: 50,
                        videoUrl: "",
                      })
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
