"use client"

import { useAuth } from "./providers"
import { useEffect } from "react"
import LoginForm from "@/components/auth/login-form"
import Dashboard from "@/components/dashboard/dashboard"
import LoadingScreen from "@/components/common/loading-screen"

export default function Home() {
  const { user, isLoading, initializeApp } = useAuth()

  useEffect(() => {
    // Initialize the app and database on first load
    initializeApp()
  }, [initializeApp])

  if (isLoading) {
    return <LoadingScreen />
  }

  if (!user) {
    return <LoginForm />
  }

  return <Dashboard />
}
