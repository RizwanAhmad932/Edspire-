"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

interface User {
  id: string
  name: string
  email: string
  plan: "free" | "premium" | "pro"
  xp: number
  avatar?: string
  role: "student" | "admin"
  joinDate: string
  lastActive: string
  class?: string
  examTarget?: string
  enrolledCourses?: number
  totalTests?: number
  avgScore?: number
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  isLoading: boolean
  updateUserPlan: (plan: "free" | "premium" | "pro") => void
  updateUser: (userData: Partial<User>) => void
  initializeApp: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function Providers({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check for existing session
    const savedUser = localStorage.getItem("user")
    if (savedUser) {
      setUser(JSON.parse(savedUser))
    }
    setIsLoading(false)
  }, [])

  const initializeApp = async () => {
    try {
      // Initialize database on first load
      const response = await fetch("/api/init-db", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (!response.ok) {
        console.warn("Database initialization may have failed")
      }
    } catch (error) {
      console.error("App initialization error:", error)
    }
  }

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      })

      const data = await response.json()

      if (data.success && data.user) {
        setUser(data.user)
        localStorage.setItem("user", JSON.stringify(data.user))
        return true
      } else {
        // Fallback to mock login for demo
        if (email === "admin" && password === "admin123") {
          const adminUser: User = {
            id: "admin",
            name: "Admin User",
            email: "admin@example.com",
            plan: "pro",
            xp: 5000,
            avatar: "/placeholder.svg?height=40&width=40&text=AD",
            role: "admin",
            joinDate: "2024-01-01",
            lastActive: new Date().toISOString(),
          }
          setUser(adminUser)
          localStorage.setItem("user", JSON.stringify(adminUser))
          return true
        }

        // Regular user mock login
        const mockUser: User = {
          id: "1",
          name: "John Doe",
          email,
          plan: "free",
          xp: 1250,
          avatar: "/placeholder.svg?height=40&width=40&text=JD",
          role: "student",
          joinDate: "2024-01-15",
          lastActive: new Date().toISOString(),
          class: "12th",
          examTarget: "JEE Main",
        }

        setUser(mockUser)
        localStorage.setItem("user", JSON.stringify(mockUser))
        return true
      }
    } catch (error) {
      console.error("Login error:", error)
      return false
    } finally {
      setIsLoading(false)
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("user")
  }

  const updateUserPlan = (plan: "free" | "premium" | "pro") => {
    if (user) {
      const updatedUser = { ...user, plan }
      setUser(updatedUser)
      localStorage.setItem("user", JSON.stringify(updatedUser))
    }
  }

  const updateUser = (userData: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...userData }
      setUser(updatedUser)
      localStorage.setItem("user", JSON.stringify(updatedUser))
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        logout,
        isLoading,
        updateUserPlan,
        updateUser,
        initializeApp,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
