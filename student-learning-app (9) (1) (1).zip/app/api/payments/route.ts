import { type NextRequest, NextResponse } from "next/server"
import { getConnection } from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const userId = formData.get("userId") as string
    const plan = formData.get("plan") as string
    const amount = formData.get("amount") as string
    const upiTransactionId = formData.get("upiTransactionId") as string
    const file = formData.get("screenshot") as File | null

    if (!userId || !plan || !amount) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const connection = await getConnection()

    // Handle file upload (in production, upload to cloud storage)
    let screenshotPath = null
    if (file) {
      screenshotPath = `screenshots/${userId}_${Date.now()}_${file.name}`
    }

    // Create payment record
    await connection.execute(
      `
      INSERT INTO payments (user_id, plan, amount, payment_screenshot, upi_transaction_id, status)
      VALUES (?, ?, ?, ?, ?, 'pending')
    `,
      [userId, plan, Number.parseFloat(amount), screenshotPath, upiTransactionId],
    )

    // Create notification for admin
    await connection.execute(
      `
      INSERT INTO notifications (user_id, title, message, type)
      SELECT id, 'New Payment Submission', 'A user has submitted payment for ${plan} plan', 'info'
      FROM users WHERE role = 'admin'
    `,
    )

    return NextResponse.json({
      success: true,
      message: "Payment submitted successfully. It will be reviewed within 24 hours.",
    })
  } catch (error) {
    console.error("Payment submission error:", error)
    return NextResponse.json({ error: "Failed to submit payment" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")
    const userRole = searchParams.get("userRole")

    const connection = await getConnection()

    let query = `
      SELECT p.*, u.name as user_name, u.email as user_email
      FROM payments p
      JOIN users u ON p.user_id = u.id
    `

    const params: any[] = []

    if (userRole === "student" && userId) {
      query += " WHERE p.user_id = ?"
      params.push(userId)
    }

    query += " ORDER BY p.created_at DESC"

    const [payments] = await connection.execute(query, params)

    return NextResponse.json({
      success: true,
      payments: payments,
    })
  } catch (error) {
    console.error("Payments fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch payments" }, { status: 500 })
  }
}
