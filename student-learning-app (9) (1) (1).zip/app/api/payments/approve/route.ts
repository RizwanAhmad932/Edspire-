import { type NextRequest, NextResponse } from "next/server"
import { getConnection } from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    const { paymentId, action, adminId } = await request.json()

    if (!paymentId || !action || !adminId) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const connection = await getConnection()

    // Get payment details
    const [paymentResult] = await connection.execute("SELECT * FROM payments WHERE id = ?", [paymentId])

    if ((paymentResult as any[]).length === 0) {
      return NextResponse.json({ error: "Payment not found" }, { status: 404 })
    }

    const payment = (paymentResult as any[])[0]

    // Update payment status
    const status = action === "approve" ? "approved" : "rejected"
    await connection.execute("UPDATE payments SET status = ?, approved_at = NOW() WHERE id = ?", [status, paymentId])

    if (action === "approve") {
      // Update user plan
      await connection.execute("UPDATE users SET plan = ? WHERE id = ?", [payment.plan, payment.user_id])

      // Create success notification
      await connection.execute(
        `
        INSERT INTO notifications (user_id, title, message, type)
        VALUES (?, ?, ?, ?)
      `,
        [
          payment.user_id,
          "Payment Approved",
          `Your payment for ${payment.plan} plan has been approved. Welcome to ${payment.plan}!`,
          "success",
        ],
      )
    } else {
      // Create rejection notification
      await connection.execute(
        `
        INSERT INTO notifications (user_id, title, message, type)
        VALUES (?, ?, ?, ?)
      `,
        [
          payment.user_id,
          "Payment Rejected",
          `Your payment for ${payment.plan} plan has been rejected. Please contact support for assistance.`,
          "error",
        ],
      )
    }

    return NextResponse.json({
      success: true,
      message: `Payment ${action}d successfully`,
    })
  } catch (error) {
    console.error("Payment approval error:", error)
    return NextResponse.json({ error: "Failed to process payment" }, { status: 500 })
  }
}
