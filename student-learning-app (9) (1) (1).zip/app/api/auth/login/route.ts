import { type NextRequest, NextResponse } from "next/server"
import { getConnection } from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400 })
    }

    const connection = await getConnection()

    // Find user by email
    const [users] = await connection.execute("SELECT * FROM users WHERE email = ?", [email])

    if ((users as any[]).length === 0) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    const user = (users as any[])[0]

    // In production, you should hash passwords with bcrypt
    // For demo purposes, we're doing plain text comparison
    if (user.password !== password) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    // Update last active timestamp
    await connection.execute("UPDATE users SET last_active = NOW() WHERE id = ?", [user.id])

    // Remove password from response
    const { password: _, ...userWithoutPassword } = user

    return NextResponse.json({
      success: true,
      user: userWithoutPassword,
      message: "Login successful",
    })
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Login failed" }, { status: 500 })
  }
}
