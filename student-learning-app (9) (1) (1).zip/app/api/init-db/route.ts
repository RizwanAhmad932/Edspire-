import { type NextRequest, NextResponse } from "next/server"
import { initializeDatabase, seedDatabase } from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    console.log("Initializing database...")
    const initResult = await initializeDatabase()

    if (!initResult) {
      return NextResponse.json({ error: "Database initialization failed" }, { status: 500 })
    }

    console.log("Seeding database...")
    const seedResult = await seedDatabase()

    if (!seedResult) {
      return NextResponse.json({ error: "Database seeding failed" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Database initialized and seeded successfully",
    })
  } catch (error) {
    console.error("Database initialization error:", error)
    return NextResponse.json({ error: "Database setup failed" }, { status: 500 })
  }
}
