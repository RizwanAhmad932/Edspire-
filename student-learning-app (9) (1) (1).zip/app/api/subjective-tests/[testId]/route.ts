import { type NextRequest, NextResponse } from "next/server"
import { getConnection } from "@/lib/database"

export async function GET(request: NextRequest, { params }: { params: { testId: string } }) {
  try {
    const { testId } = params
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")

    const connection = await getConnection()

    // Get test details
    const [testResult] = await connection.execute(
      `
      SELECT st.*, u.name as creator_name
      FROM subjective_tests st
      LEFT JOIN users u ON st.created_by = u.id
      WHERE st.id = ?
    `,
      [testId],
    )

    if ((testResult as any[]).length === 0) {
      return NextResponse.json({ error: "Test not found" }, { status: 404 })
    }

    const test = (testResult as any[])[0]

    // Get questions
    const [questions] = await connection.execute(
      `
      SELECT * FROM subjective_questions
      WHERE test_id = ?
      ORDER BY question_number
    `,
      [testId],
    )

    // Get user's submission if exists
    let submission = null
    if (userId) {
      const [submissionResult] = await connection.execute(
        `
        SELECT * FROM subjective_submissions
        WHERE test_id = ? AND student_id = ?
      `,
        [testId, userId],
      )

      if ((submissionResult as any[]).length > 0) {
        submission = (submissionResult as any[])[0]

        // Get answers for this submission
        const [answers] = await connection.execute(
          `
          SELECT sa.*, sq.question_text, sq.marks as max_marks
          FROM subjective_answers sa
          JOIN subjective_questions sq ON sa.question_id = sq.id
          WHERE sa.submission_id = ?
          ORDER BY sq.question_number
        `,
          [submission.id],
        )

        submission.answers = answers
      }
    }

    return NextResponse.json({
      success: true,
      test: {
        ...test,
        questions: questions,
        userSubmission: submission,
      },
    })
  } catch (error) {
    console.error("Test fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch test" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { testId: string } }) {
  try {
    const { testId } = params
    const updateData = await request.json()
    const connection = await getConnection()

    // Update test
    await connection.execute(
      `
      UPDATE subjective_tests 
      SET title = ?, subject = ?, class = ?, description = ?, instructions = ?, 
          duration = ?, total_marks = ?, status = ?, start_time = ?, end_time = ?
      WHERE id = ?
    `,
      [
        updateData.title,
        updateData.subject,
        updateData.class,
        updateData.description,
        updateData.instructions,
        updateData.duration,
        updateData.totalMarks,
        updateData.status,
        updateData.startTime,
        updateData.endTime,
        testId,
      ],
    )

    return NextResponse.json({
      success: true,
      message: "Test updated successfully",
    })
  } catch (error) {
    console.error("Test update error:", error)
    return NextResponse.json({ error: "Failed to update test" }, { status: 500 })
  }
}
