import { type NextRequest, NextResponse } from "next/server"
import { getConnection } from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    const { submissionId, evaluatorId, answers, totalScore, feedback } = await request.json()

    if (!submissionId || !evaluatorId || !answers) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const connection = await getConnection()

    // Update individual answer scores and feedback
    for (const answer of answers) {
      await connection.execute(
        `
        UPDATE subjective_answers 
        SET score = ?, feedback = ?, error_analysis = ?
        WHERE id = ?
      `,
        [answer.score, answer.feedback, answer.errorAnalysis || "", answer.id],
      )
    }

    // Update submission
    await connection.execute(
      `
      UPDATE subjective_submissions 
      SET total_score = ?, feedback = ?, status = 'evaluated', evaluated_by = ?, evaluated_at = NOW()
      WHERE id = ?
    `,
      [totalScore, feedback, evaluatorId, submissionId],
    )

    // Get submission details for notification
    const [submissionResult] = await connection.execute(
      `
      SELECT ss.*, st.title, u.name as student_name
      FROM subjective_submissions ss
      JOIN subjective_tests st ON ss.test_id = st.id
      JOIN users u ON ss.student_id = u.id
      WHERE ss.id = ?
    `,
      [submissionId],
    )

    const submission = (submissionResult as any[])[0]

    // Create notification for student
    await connection.execute(
      `
      INSERT INTO notifications (user_id, title, message, type)
      VALUES (?, ?, ?, ?)
    `,
      [
        submission.student_id,
        "Test Evaluated",
        `Your submission for "${submission.title}" has been evaluated. Score: ${totalScore}/${submission.max_score}`,
        "success",
      ],
    )

    // Update XP for student based on score
    const xpGained = Math.floor((totalScore / submission.max_score) * 100)
    await connection.execute("UPDATE users SET xp = xp + ? WHERE id = ?", [xpGained, submission.student_id])

    return NextResponse.json({
      success: true,
      message: "Evaluation completed successfully",
      xpAwarded: xpGained,
    })
  } catch (error) {
    console.error("Evaluation error:", error)
    return NextResponse.json({ error: "Failed to evaluate submission" }, { status: 500 })
  }
}
