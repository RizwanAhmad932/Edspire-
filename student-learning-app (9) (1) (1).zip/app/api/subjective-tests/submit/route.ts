import { type NextRequest, NextResponse } from "next/server"
import { getConnection } from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const testId = formData.get("testId") as string
    const studentId = formData.get("studentId") as string
    const submissionText = formData.get("submissionText") as string
    const file = formData.get("file") as File | null

    if (!testId || !studentId) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const connection = await getConnection()

    // Check if submission already exists
    const [existingSubmission] = await connection.execute(
      "SELECT id FROM subjective_submissions WHERE test_id = ? AND student_id = ?",
      [testId, studentId],
    )

    if ((existingSubmission as any[]).length > 0) {
      return NextResponse.json({ error: "Submission already exists" }, { status: 400 })
    }

    // Get test details
    const [testResult] = await connection.execute("SELECT * FROM subjective_tests WHERE id = ?", [testId])

    if ((testResult as any[]).length === 0) {
      return NextResponse.json({ error: "Test not found" }, { status: 404 })
    }

    const test = (testResult as any[])[0]

    // Handle file upload (in production, you'd upload to cloud storage)
    let filePath = null
    if (file) {
      // For demo purposes, we'll just store the filename
      // In production, upload to AWS S3, Google Cloud Storage, etc.
      filePath = `uploads/${testId}/${studentId}_${Date.now()}_${file.name}`
    }

    // Create submission
    const [submissionResult] = await connection.execute(
      `
      INSERT INTO subjective_submissions (test_id, student_id, submission_file, submission_text, max_score)
      VALUES (?, ?, ?, ?, ?)
    `,
      [testId, studentId, filePath, submissionText, test.total_marks],
    )

    const submissionId = (submissionResult as any).insertId

    // Get questions for auto-evaluation
    const [questions] = await connection.execute(
      "SELECT * FROM subjective_questions WHERE test_id = ? ORDER BY question_number",
      [testId],
    )

    // Perform basic auto-evaluation
    let totalAutoScore = 0
    const answers = JSON.parse((formData.get("answers") as string) || "[]")

    for (let i = 0; i < questions.length; i++) {
      const question = (questions as any[])[i]
      const answer = answers[i] || { text: "", score: 0 }

      // Basic keyword matching for auto-scoring
      const expectedKeywords = JSON.parse(question.expected_keywords || "[]")
      const answerText = answer.text.toLowerCase()

      let keywordsFound = []
      let autoScore = 0

      if (expectedKeywords.length > 0) {
        keywordsFound = expectedKeywords.filter((keyword: string) => answerText.includes(keyword.toLowerCase()))

        // Simple scoring: (keywords found / total keywords) * question marks * 0.6 (60% for auto-scoring)
        autoScore = Math.floor((keywordsFound.length / expectedKeywords.length) * question.marks * 0.6)
      }

      // Generate auto-feedback
      const autoFeedback = generateAutoFeedback(answerText, expectedKeywords, keywordsFound, question.marks)

      await connection.execute(
        `
        INSERT INTO subjective_answers (submission_id, question_id, answer_text, score, max_score, auto_feedback, keywords_found)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `,
        [
          submissionId,
          question.id,
          answer.text,
          autoScore,
          question.marks,
          autoFeedback,
          JSON.stringify(keywordsFound),
        ],
      )

      totalAutoScore += autoScore
    }

    // Update submission with auto score
    await connection.execute(
      "UPDATE subjective_submissions SET total_score = ?, status = 'under_review' WHERE id = ?",
      [totalAutoScore, submissionId],
    )

    // Create notification for teacher
    await connection.execute(
      `
      INSERT INTO notifications (user_id, title, message, type)
      VALUES (?, ?, ?, ?)
    `,
      [
        test.created_by,
        "New Submission Received",
        `A student has submitted answers for "${test.title}". Auto-score: ${totalAutoScore}/${test.total_marks}`,
        "info",
      ],
    )

    return NextResponse.json({
      success: true,
      submissionId: submissionId,
      autoScore: totalAutoScore,
      maxScore: test.total_marks,
      message: "Submission successful! Your answers are being reviewed.",
    })
  } catch (error) {
    console.error("Submission error:", error)
    return NextResponse.json({ error: "Failed to submit answers" }, { status: 500 })
  }
}

function generateAutoFeedback(
  answerText: string,
  expectedKeywords: string[],
  keywordsFound: string[],
  maxMarks: number,
): string {
  const feedback = []

  if (keywordsFound.length === 0) {
    feedback.push("❌ No key concepts identified. Please review the topic and include relevant terminology.")
  } else if (keywordsFound.length < expectedKeywords.length / 2) {
    feedback.push(
      `⚠️ Partial understanding detected. Found ${keywordsFound.length}/${expectedKeywords.length} key concepts.`,
    )
    feedback.push(`Missing concepts: ${expectedKeywords.filter((k) => !keywordsFound.includes(k)).join(", ")}`)
  } else {
    feedback.push(`✅ Good coverage of key concepts (${keywordsFound.length}/${expectedKeywords.length}).`)
  }

  if (answerText.length < 50) {
    feedback.push("📝 Answer seems too brief. Consider providing more detailed explanations.")
  }

  if (answerText.length > 1000) {
    feedback.push("📏 Answer is quite lengthy. Focus on key points for clarity.")
  }

  feedback.push("🔍 This is an automated preliminary assessment. Final evaluation will be done by your instructor.")

  return feedback.join("\n")
}
