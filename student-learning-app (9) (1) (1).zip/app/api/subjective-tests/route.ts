import { type NextRequest, NextResponse } from "next/server"
import { getConnection } from "@/lib/database"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")
    const userRole = searchParams.get("userRole")
    const status = searchParams.get("status")

    const connection = await getConnection()

    let query = `
      SELECT 
        st.*,
        u.name as creator_name,
        COUNT(DISTINCT ss.id) as total_submissions,
        COUNT(DISTINCT sq.id) as total_questions
      FROM subjective_tests st
      LEFT JOIN users u ON st.created_by = u.id
      LEFT JOIN subjective_submissions ss ON st.id = ss.test_id
      LEFT JOIN subjective_questions sq ON st.id = sq.test_id
    `

    const params: any[] = []

    if (userRole === "student") {
      query += ` WHERE st.status = 'published'`
      if (status) {
        query += ` AND st.status = ?`
        params.push(status)
      }
    } else if (userRole === "teacher" || userRole === "admin") {
      if (userRole === "teacher") {
        query += ` WHERE st.created_by = ?`
        params.push(userId)
      }
      if (status) {
        query += userRole === "teacher" ? ` AND st.status = ?` : ` WHERE st.status = ?`
        params.push(status)
      }
    }

    query += ` GROUP BY st.id ORDER BY st.created_at DESC`

    const [tests] = await connection.execute(query, params)

    return NextResponse.json({
      success: true,
      tests: tests,
    })
  } catch (error) {
    console.error("Subjective tests fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch tests" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const testData = await request.json()
    const connection = await getConnection()

    const testId = `subj_test_${Date.now()}`

    // Create the test
    await connection.execute(
      `
      INSERT INTO subjective_tests (id, title, subject, class, description, instructions, duration, total_marks, created_by, status, start_time, end_time)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,
      [
        testId,
        testData.title,
        testData.subject,
        testData.class,
        testData.description,
        testData.instructions,
        testData.duration,
        testData.totalMarks,
        testData.createdBy,
        testData.status || "draft",
        testData.startTime,
        testData.endTime,
      ],
    )

    // Add questions
    if (testData.questions && testData.questions.length > 0) {
      for (let i = 0; i < testData.questions.length; i++) {
        const question = testData.questions[i]
        await connection.execute(
          `
          INSERT INTO subjective_questions (test_id, question_number, question_text, marks, expected_keywords, sample_answer, evaluation_criteria)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `,
          [
            testId,
            i + 1,
            question.text,
            question.marks,
            JSON.stringify(question.keywords || []),
            question.sampleAnswer || "",
            question.criteria || "",
          ],
        )
      }
    }

    return NextResponse.json({
      success: true,
      testId: testId,
      message: "Test created successfully",
    })
  } catch (error) {
    console.error("Test creation error:", error)
    return NextResponse.json({ error: "Failed to create test" }, { status: 500 })
  }
}
