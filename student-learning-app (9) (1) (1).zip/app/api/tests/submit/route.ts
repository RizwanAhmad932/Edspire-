import { type NextRequest, NextResponse } from "next/server"
import { getConnection } from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    const { userId, testId, score, totalQuestions, timeTaken } = await request.json()

    if (!userId || !testId || score === undefined) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const connection = await getConnection()

    // Record test attempt
    await connection.execute(
      `
      INSERT INTO test_attempts (user_id, test_id, score, total_questions, time_taken)
      VALUES (?, ?, ?, ?, ?)
    `,
      [userId, testId, score, totalQuestions, timeTaken],
    )

    // Calculate XP gained (score percentage * 10)
    const xpGained = Math.floor((score / totalQuestions) * 100 * 0.1) * 10

    // Update user XP
    await connection.execute("UPDATE users SET xp = xp + ? WHERE id = ?", [xpGained, userId])

    return NextResponse.json({
      success: true,
      xpGained: xpGained,
      message: "Test submitted successfully",
    })
  } catch (error) {
    console.error("Test submission error:", error)
    return NextResponse.json({ error: "Failed to submit test" }, { status: 500 })
  }
}
