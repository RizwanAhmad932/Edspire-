import { type NextRequest, NextResponse } from "next/server"
import { getConnection } from "@/lib/database"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")

    const connection = await getConnection()

    // Get all tests with user's best scores
    const query = `
      SELECT 
        t.*,
        COUNT(ta.id) as attempts,
        MAX(ta.score) as best_score
      FROM tests t
      LEFT JOIN test_attempts ta ON t.id = ta.test_id AND ta.user_id = ?
      GROUP BY t.id
      ORDER BY t.created_at DESC
    `

    const [tests] = await connection.execute(query, [userId || ""])

    return NextResponse.json({
      success: true,
      tests: tests,
    })
  } catch (error) {
    console.error("Tests fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch tests" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const testData = await request.json()
    const connection = await getConnection()

    const testId = `test_${Date.now()}`

    await connection.execute(
      `
      INSERT INTO tests (id, title, subject, type, difficulty, questions, duration)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `,
      [
        testId,
        testData.title,
        testData.subject,
        testData.type,
        testData.difficulty,
        testData.questions,
        testData.duration,
      ],
    )

    return NextResponse.json({
      success: true,
      testId: testId,
    })
  } catch (error) {
    console.error("Test creation error:", error)
    return NextResponse.json({ error: "Failed to create test" }, { status: 500 })
  }
}
