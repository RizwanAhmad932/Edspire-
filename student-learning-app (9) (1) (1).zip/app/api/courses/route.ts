import { type NextRequest, NextResponse } from "next/server"
import { getConnection } from "@/lib/database"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")

    const connection = await getConnection()

    // Get all courses with enrollment status for the user
    const query = `
      SELECT 
        c.*,
        CASE WHEN uc.user_id IS NOT NULL THEN true ELSE false END as is_enrolled,
        COALESCE(uc.progress, 0) as progress
      FROM courses c
      LEFT JOIN user_courses uc ON c.id = uc.course_id AND uc.user_id = ?
      ORDER BY c.created_at DESC
    `

    const [courses] = await connection.execute(query, [userId || ""])

    return NextResponse.json({
      success: true,
      courses: courses,
    })
  } catch (error) {
    console.error("Courses fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch courses" }, { status: 500 })
  }
}
