import { type NextRequest, NextResponse } from "next/server"
import { getConnection } from "@/lib/database"

export async function POST(request: NextRequest) {
  try {
    const { userId, courseId } = await request.json()

    if (!userId || !courseId) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const connection = await getConnection()

    // Check if already enrolled
    const [existing] = await connection.execute("SELECT id FROM user_courses WHERE user_id = ? AND course_id = ?", [
      userId,
      courseId,
    ])

    if ((existing as any[]).length > 0) {
      return NextResponse.json({ error: "Already enrolled in this course" }, { status: 400 })
    }

    // Enroll user
    await connection.execute("INSERT INTO user_courses (user_id, course_id, progress) VALUES (?, ?, ?)", [
      userId,
      courseId,
      0,
    ])

    // Update course student count
    await connection.execute("UPDATE courses SET students = students + 1 WHERE id = ?", [courseId])

    return NextResponse.json({
      success: true,
      message: "Successfully enrolled in course",
    })
  } catch (error) {
    console.error("Enrollment error:", error)
    return NextResponse.json({ error: "Failed to enroll in course" }, { status: 500 })
  }
}
